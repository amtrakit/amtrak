# amtrak
iText PDF generation 


From at least 2015 - October 2017, Amtrak’s proprietary source code for generating pdf ticket receipts was modified using iText5. Accordingly, the Amtrak Code Base for the Amtrak application is being disclosed, released and licensed to all users under the terms and conditions of sections 6 and 13 of the AGPLv3.

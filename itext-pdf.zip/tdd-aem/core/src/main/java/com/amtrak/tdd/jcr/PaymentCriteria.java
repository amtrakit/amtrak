package com.amtrak.tdd.jcr;

public class PaymentCriteria extends BaseCriteria{
	
	private ServiceCriteria serviceCriteria;
	private String paymentCode;
	
	public PaymentCriteria() {
        // nothing to do.
	}
	public PaymentCriteria(ServiceCriteria serviceCriteria, String paymentCode) {
		super();
		this.serviceCriteria = serviceCriteria;
		this.paymentCode = paymentCode;
	}

	public ServiceCriteria getServiceCriteria() {
		return serviceCriteria;
	}
	public void setServiceCriteria(ServiceCriteria serviceCriteria) {
		this.serviceCriteria = serviceCriteria;
	}
	public String getPaymentCode() {
		return paymentCode;
	}
	public void setPaymentCode(String paymentCode) {
		this.paymentCode = paymentCode;
	}
	public String getOriginStation(){
		return serviceCriteria.getOriginStationCriteria().getStationName();
	}
	public String getOriginDate(){
		return serviceCriteria.getOriginStationCriteria().getDate();
	}
	public String getDestinationStation(){
		return serviceCriteria.getDestinationStationCriteria().getStationName();
	}
	public String getDestinationDate(){
		return serviceCriteria.getDestinationStationCriteria().getDate();
	}


}

package com.amtrak.tdd.sling;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.amtrak.tdd.helper.ImportantInformationHelper;

public class PaymentTypeAdvisoryUse extends WCMUsePojo {
	private static final Logger LOG = LoggerFactory.getLogger(PaymentTypeAdvisoryUse.class);
	private String title;
	private String name;
	private String number;
	private String departureStation;
	private String arrivalStation;
	private String sDate;
	private String eDate;
	private Integer ranking= null;
	private String paymentType;
	private String importantInfo;
	private String publishDate;
	private String excludeTrainName;
	private String excludeTrainNumber;

	@Override
	public void activate() throws Exception {
		title = getProperties().get("infotitle", String.class);
		name = getProperties().get("servicename", String.class);
		number = getProperties().get("servicenumber", String.class);
		departureStation = getProperties().get("depstation", String.class);
		arrivalStation = getProperties().get("arrivestation", String.class);
		sDate = getProperties().get("startdate", String.class);
		eDate = getProperties().get("enddate", String.class);
		publishDate = getProperties().get("publishDate", String.class);
		paymentType = getProperties().get("paymenttype", String.class);	
		ranking = getProperties().get("rank", Integer.class);	
		importantInfo = getProperties().get("impinfo", String.class);
		excludeTrainName = getProperties().get("trainnameexclude", String.class);
		excludeTrainNumber = getProperties().get("trainnumberexclude", String.class);
		

	}

	public String getSDate() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat;
			inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
			Date fdat = inputFormat.parse(sDate);
			sDate = sdf.format(fdat);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
		return sDate;
	}

	public String getEDate() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat;
			inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
			Date fdat = inputFormat.parse(eDate);
			eDate = sdf.format(fdat);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}

		return eDate;
	}

	public String getPublishDate() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat;
			inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
			Date fdat = inputFormat.parse(publishDate);
			publishDate = sdf.format(fdat);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
		return publishDate;
	}

	public Integer getRanking() {
			return ranking;
	}
	public String getPaymentType() {
		return paymentType;
	}

	public String getImportantInfo() {
		return importantInfo;
	}

	public String getName() {
		return name;
	}

	public String getTitle() {
		return title;
	}

	public String getNumber() {
		return number;
	}

	public String getDepartureStation() {
		return departureStation;
	}

	public String getArrivalStation() {
		return arrivalStation;
	}
	public String getExcludeTrainName() {
		excludeTrainName = ImportantInformationHelper.changeExcludeOption(excludeTrainName);
		return excludeTrainName;
	}
	public String getExcludeTrainNumber() {
		excludeTrainNumber = ImportantInformationHelper.changeExcludeOption(excludeTrainNumber);
		return excludeTrainNumber;
	}

}

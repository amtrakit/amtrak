package com.amtrak.tdd.jcr;

public enum StationType {

	ORIGIN,
	DESTINATION;
	
}

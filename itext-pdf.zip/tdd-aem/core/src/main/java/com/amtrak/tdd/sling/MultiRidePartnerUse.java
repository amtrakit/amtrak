package com.amtrak.tdd.sling;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

public class MultiRidePartnerUse extends WCMUsePojo {
	private static final Logger LOG = LoggerFactory.getLogger(MultiRidePartnerUse.class);
	private String title;
	private String partner;
	private String partnerstation;
	private String sharedpartner;
	private String amtrakstation;
	private String publishDate;

	@Override
	public void activate() throws Exception {
		title = getProperties().get("infotitle", String.class);
		partner = getProperties().get("partner", String.class);
		partnerstation = getProperties().get("partnerstation", String.class);
		sharedpartner = getProperties().get("sharedpartner", String.class);
		amtrakstation = getProperties().get("amtrakstation", String.class);
		publishDate = getProperties().get("publishDate", String.class);
	}

	public String getPublishDate() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat;
			inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
			Date fdat = inputFormat.parse(publishDate);
			publishDate = sdf.format(fdat);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
		return publishDate;
	}

	public String getPartner() {
		return partner;
	}

	public String getTitle() {
		return title;
	}

	public String getPartnerstation() {
		return partnerstation;
	}

	public String getSharedpartner() {
		return sharedpartner;
	}
	public String getAmtrakstation() {
		return amtrakstation;
	}

}
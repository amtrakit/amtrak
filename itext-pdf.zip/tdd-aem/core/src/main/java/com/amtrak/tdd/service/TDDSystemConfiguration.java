package com.amtrak.tdd.service;

import java.io.InputStream;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.SystemConfiguration;
import org.apache.commons.configuration.XMLConfiguration;
import org.slf4j.LoggerFactory;


public class TDDSystemConfiguration {

	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(TDDSystemConfiguration.class);

    /** Name of XML Configuration File for HTML Generation. */
    private static final String HTML_XML_CONFIGURATION = "TDDXMLConfiguration.xml";
    /** HashMap to store configurations. **/
	private static final HashMap<String, Configuration> configTable = new HashMap<>();
	/** HashMap configuration key. **/
	private static final String COMPOSITE = "CompositeConfig";
	/** SINGLETON. */
	private static final TDDSystemConfiguration SINGLETON = new TDDSystemConfiguration(); 

    /** Name of XML Configuration File for HTML Generation. */
    private static final String JUNIT_XML_CONFIGURATION = "TDDJUNITConfiguration.xml";

    /** Name of Properties Configuration File for PRINT Generation. */
    private static final String PRINT_PROPERTIES_CONFIGURATION = "tddcustom.properties";

    /** Composite Configuration. **/
	private final CompositeConfiguration tddConfiguration = new CompositeConfiguration();
	
	
	static {
		// Store all configurations
		CompositeConfiguration compositeConfiguration = new CompositeConfiguration();
		// InputStream for the Server
		XMLConfiguration machineXmlConfiguration = new XMLConfiguration() ;
		// InputStream for the MachineResources file
		InputStream machineInputStream = null;
		try {
			// Read the MachineResources XML file first if present
			String machineName = "TDDMachineResources-" + InetAddress.getLocalHost().getHostName() + ".xml";
			machineInputStream = TDDSystemConfiguration.class.getClassLoader().getResourceAsStream(machineName);
			machineXmlConfiguration.load(machineInputStream);
		}
		catch (Exception e) {
       		LOG.error("Exception : MachineResources file not loaded..", e);
		}
		
		try {
			// Store the server system configuration
			compositeConfiguration.addConfiguration(new SystemConfiguration());
			// Add the Machine Configuration
			if (machineInputStream != null) {
				compositeConfiguration.addConfiguration(machineXmlConfiguration);
			}
			// Place holder for the TDDXML Configuration
			XMLConfiguration xmlConfiguration = new XMLConfiguration() ;
			// Read the TDD XML Configuration
			InputStream xmlInputStream = TDDSystemConfiguration.class.getClassLoader().getResourceAsStream(HTML_XML_CONFIGURATION);
			// Load the Functional XML Configuration (TDDXMLConfiguration.xml)
			xmlConfiguration.load(xmlInputStream);
			xmlConfiguration.setValidating(true);
			compositeConfiguration.addConfiguration(xmlConfiguration);
			configTable.put(COMPOSITE, compositeConfiguration);
		}
		catch (Exception e) {
       		LOG.error("Exception : Unable to load XML Configuration.", e);
		}
	}

    /**
	 * GenerateHTMLPropertiesHandler constructor comment.
	 */
	private TDDSystemConfiguration() {
	}
	
	public static TDDSystemConfiguration getInstance() {
		return SINGLETON;
	}

	/**
	 * Public method to load the SYSTEM and MACHINE configuration.  Called ONCE from the servlet context listener.
	 * @return XMLConfiguration
	 */
	public static void loadSystemConfiguration() {
		// Load the System Properties first
		SINGLETON.tddConfiguration.addConfiguration(new SystemConfiguration());
		
		// Load this Machine Properties if present - these will override all subsequent configuration
		try {
			String machineName = "TDDMachineResources-" + InetAddress.getLocalHost().getHostName() + ".xml";
			XMLConfiguration machineConfig = loadXMLConfiguration(machineName);
			if (machineConfig != null) {
				LOG.info("loadXMLConfiguration - " + machineName + " loaded");
				SINGLETON.tddConfiguration.addConfiguration(machineConfig);
			}
		}
		catch (Exception e) {
      		LOG.error("Exception : Error occured during HTML processing. PNRNumber: ", e);
		}
	}
	
	/**
	 * Method to load TDDXMLConfiguration.xml.  Called ONCE from servlet context listener.
	 */
	public static void loadXMLConfiguration() {
		XMLConfiguration xmlConfig = loadXMLConfiguration(HTML_XML_CONFIGURATION);
		if (xmlConfig != null) {
			LOG.info("loadXMLConfiguration - " + HTML_XML_CONFIGURATION + " loaded");
			SINGLETON.tddConfiguration.addConfiguration(xmlConfig);
		}
	}

	/**
	 * Method to load TDDJUNITConfiguration.xml.  Called ONCE from servlet context listener.
	 */
	public static void loadJUNITConfiguration() {
		CompositeConfiguration config = (CompositeConfiguration)configTable.get(COMPOSITE);
		XMLConfiguration xmlConfig = loadXMLConfiguration(JUNIT_XML_CONFIGURATION);
		if (xmlConfig != null) {
			LOG.info("loadXMLConfiguration - " + JUNIT_XML_CONFIGURATION + " loaded");
			config.addConfiguration(xmlConfig);
		}
	}

	/**
	 * Method to load tddcustom.properties.  Called ONCE from servlet context listener.
	 */
	public static void loadPrintPropertiesConfiguration() {
		PropertiesConfiguration propConfig = loadPropertiesConfiguration(PRINT_PROPERTIES_CONFIGURATION);
		if (propConfig != null) {
			LOG.info("loadPrintPropertiesConfiguration - " + PRINT_PROPERTIES_CONFIGURATION + " loaded");
			SINGLETON.tddConfiguration.addConfiguration(propConfig);
		}
	}

	
	/**
	 * Method to check if a String/Boolean property exists
	 * @param property
	 * @return boolean
	 */
	public static boolean doesPropertyExist(String property) {
		CompositeConfiguration config = (CompositeConfiguration)configTable.get(COMPOSITE);
		String value = config.getString(property);
		if (value != null) 
			return true;
		
		return false;
	}
	
	public static void setBooleanProperty(String property, boolean deliveryEnabled) {
		CompositeConfiguration config = (CompositeConfiguration)configTable.get(COMPOSITE);
		config.setProperty(property, Boolean.toString(deliveryEnabled));
	}
	
	
	/**
	 * Returns a String property from configuration.
	 * @param propertyName
	 * @return configuration value String
	 */
	public static String getStringProperty(String propertyName) {
		CompositeConfiguration config = (CompositeConfiguration)configTable.get(COMPOSITE);
		return config.getString(propertyName);
	}

	/**
	 * Returns a Integer property from configuration.
	 * @param propertyName
	 * @return configuration value int
	 */
	public static int getIntegerProperty(String propertyName) {
		CompositeConfiguration config = (CompositeConfiguration)configTable.get(COMPOSITE);
		return config.getInt(propertyName);
	}
	
	/**
	 * Returns a Boolean property from configuration.
	 * @param propertyName
	 * @return configuration value boolean
	 */
	public static boolean getBooleanProperty(String propertyName) {
		CompositeConfiguration config = (CompositeConfiguration)configTable.get(COMPOSITE);
		return config.getBoolean(propertyName);
	}
	
	/**
	 * Returns a Boolean property from configuration.
	 * @param propertyName
	 * @return configuration value boolean
	 */
	public static boolean getBooleanProperty(String propertyName, boolean defaultValue) {
		CompositeConfiguration config = (CompositeConfiguration)configTable.get(COMPOSITE);
		return config.getBoolean(propertyName, defaultValue);
	}

	/**
	 * Returns a String list property from configuration.
	 * @param propertyName
	 * @return configuration value List<String>
	 */
	public static List<String> getStringListProperty(String propertyName) {
		CompositeConfiguration config = (CompositeConfiguration)configTable.get(COMPOSITE);
		String[] list = config.getStringArray(propertyName);
		return Arrays.asList(list);
	}

	/**
	 * Returns a String array property from configuration.
	 * @param propertyName
	 * @return configuration value String[]
	 */
	public static String[] getStringArrayProperty(String propertyName) {
		CompositeConfiguration config = (CompositeConfiguration)configTable.get(COMPOSITE);
		return config.getStringArray(propertyName);
	}


	/**
	 * Loads a XMLConfiguration 
	 * @param configuration
	 * @return XMLConfiguration or NULL
	 */
	private static XMLConfiguration loadXMLConfiguration(String configuration) {
		InputStream xmlInputStream = TDDSystemConfiguration.class.getClassLoader().getResourceAsStream(configuration);
		try {
			XMLConfiguration xmlConfiguration = new XMLConfiguration() ;
			xmlConfiguration.load(xmlInputStream);
			xmlConfiguration.setValidating(true);
			return xmlConfiguration;
		}
		catch (Exception e) {
			LOG.error("Unable to load XML Configuration:", e);
		}
		
		return null;
	}
	
	/**
	 * Loads a XMLConfiguration 
	 * @param configuration
	 * @return XMLConfiguration or NULL
	 */
	private static PropertiesConfiguration loadPropertiesConfiguration(String configuration) {
		InputStream xmlInputStream = TDDSystemConfiguration.class.getClassLoader().getResourceAsStream(configuration);
		try {
			PropertiesConfiguration xmlConfiguration = new PropertiesConfiguration() ;
			xmlConfiguration.load(xmlInputStream);
			return xmlConfiguration;
		}
		catch (Exception e) {
			LOG.error("Unable to load Properties Configuration:",e);
		}
		
		return null;
	}

	
}
package com.amtrak.tdd.jcr;

import java.util.List;
import org.apache.sling.api.resource.ResourceResolver;
import com.day.cq.search.QueryBuilder;

public interface SalesReceiptService {

	
    public List SearchCQForSalesReceiptContent(ResourceResolver resourceResolver,QueryBuilder builder,List<BaseCriteria> rdetails);

}

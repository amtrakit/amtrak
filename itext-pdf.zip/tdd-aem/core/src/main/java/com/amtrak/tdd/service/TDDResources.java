/**
 * THIS PROGRAM IS CONFIDENTIAL AND PROPRIETARY TO AMTRAK AND 
 * MAY NOT BE REPRODUCED, PUBLISHED OR DISCLOSED TO OTHERS WITHOUT AUTHORIZATION.
 * COPYRIGHT � AMTRAK.  THIS WORK IS UNPUBLISHED.
 */

package com.amtrak.tdd.service;

/**
 * Fields used by the TDD EJB classes.  These will become configurable in the future.
 * @author 90000781
 *
 */
public class TDDResources {

	/**
	 * Constructor
	 */
	private TDDResources(){
        // nothing to do.
	}
	
	
	// Fields and text used in the email receipts.
	public static final String purchaseSummary = "Total Charged by Amtrak";
	public static final String creditCardRefund = "Total Refunded to Credit Card";
	public static final String eVoucherRefund = "Total eVoucher Dollar Value";
	public static final String creditCardCharged = "Total Charged to Credit Card";
	public static final String payInPerson = "Total to be Paid in Person";
	public static final String totalPaid = "Total paid";
	public static final String totalDesc = "Total";
	public static final String totalCharged = "Total Charged";
	public static final String totalEvoucherDollarValue = "Total eVoucher Dollar Value";	
	public static final String totalRefunded = "Total Refunded";
	
	public static final String revisedTripDetails = "Revised Trip Details";
	public static final String cancelledTripDetails = "Cancelled Trip Details";

	// Frutiger Font
	public static final String FRUTIGER_ROMAN = "FrutigerLT-Roman";
	
	// HTML for the boiler plate receipt mail
	public static final String BOILER_PLATE_HTML = 
			"<HTML><HEAD></HEAD><BODY>" + 
			"Dear Amtrak Customer,<BR><BR>" +
			"Thank you for choosing Amtrak.<BR>" +        
			"Your travel documents are attached. Please print and bring them with valid identification to show the conductor aboard the train.<BR><BR>" +       
			"ADOBE&reg; PDF&reg; DOCUMENT<BR>" + 
			"You will need an Adobe PDF reader (free from Adobe at <a href='http://get.adobe.com/reader/'>http://get.adobe.com/reader/</a>) to read the attached document.<BR><BR>" +
			"IMPORTANT POLICIES<BR><BR>" +  
			"<ul type='circle'><li><a href='http://www.amtrak.com/servlet/ContentServer?c=Page&pagename=am%2FLayout&cid=1241267362242'>Refund/Exchange Policy</a></li>" +       
			"<li><a href='http://www.amtrak.com/servlet/ContentServer?c=Page&pagename=am%2FLayout&cid=1241267382692'>Passenger Identification</a></li>" +
			"<li><a href='http://www.amtrak.com/servlet/ContentServer?c=Page&pagename=am%2FLayout&cid=1241267362251'>Baggage Policy</a></li>" +
			"<li><a href='http://www.amtrak.com/servlet/ContentServer?c=Page&pagename=am%2FLayout&cid=1241267382715'>Smoking Policy</a></li></ul>" +
			"Questions? <a href='http://www.amtrak.com/servlet/ContentServer?c=Page&pagename=am%2FLayout&cid=1237608364155'>Contact us online</a> or call 1-800-USA-RAIL (1-800-872-7245).<BR>" +      
    		"</BODY></HTML>"; 
	
	public static final String BOILER_PLATE_HTML_CCJPA = 
			"<HTML><HEAD></HEAD><BODY>" + 
			"Dear Amtrak Customer,<BR><BR>" +
			"Thank you for choosing Amtrak.<BR>" +        
			"Your travel documents are attached. Please print and bring them with valid identification to show the conductor aboard the train.<BR><BR>" +       
			"ADOBE&reg; PDF&reg; DOCUMENT<BR>" + 
			"You will need an Adobe PDF reader (free from Adobe at <a href='http://get.adobe.com/reader/'>http://get.adobe.com/reader/</a>) to read the attached document.<BR><BR>" +
			"IMPORTANT POLICIES<BR><BR>" +  
			"<ul type='circle'><li><a href='http://www.amtrak.com/servlet/ContentServer?c=Page&pagename=am%2FLayout&cid=1241267362242'>Refund/Exchange Policy</a></li>" +       
			"<li><a href='http://www.amtrak.com/servlet/ContentServer?c=Page&pagename=am%2FLayout&cid=1241267382692'>Passenger Identification</a></li>" +
			"<li><a href='http://www.amtrak.com/servlet/ContentServer?c=Page&pagename=am%2FLayout&cid=1241267362251'>Baggage Policy</a></li>" +
			"<li><a href='http://www.amtrak.com/servlet/ContentServer?c=Page&pagename=am%2FLayout&cid=1241267382715'>Smoking Policy</a></li></ul>" +
			"Questions? <a href='http://www.amtrak.com/servlet/ContentServer?c=Page&pagename=am%2FLayout&cid=1237608364155'>Contact us online</a> or call 1-877-974-3322.<BR>" +      
    		"</BODY></HTML>";
	
	// Email subject lines for each type of email
	public static final String EVOUCHER_EMAIL_SUBJECT = "Amtrak eVoucher Information";
	public static final String RECEIPT_TD_DD_EMAIL_SUBJECT = "Amtrak: eTicket for Your Upcoming Trip";
	public static final String RECEIPT_CR_DR_EMAIL_SUBJECT = "Amtrak: Travel Receipt";
	
	
}

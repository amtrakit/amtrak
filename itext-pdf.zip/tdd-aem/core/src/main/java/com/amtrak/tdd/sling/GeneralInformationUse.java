package com.amtrak.tdd.sling;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

public class GeneralInformationUse extends WCMUsePojo {
	private static final Logger LOG = LoggerFactory.getLogger(GeneralInformationUse.class);
	private String title;
	private String sDate;
	private String eDate;
	private Integer ranking = null;
	private String importantInfo;
	private String publishDate;

	@Override
	public void activate() throws Exception {
		title = getProperties().get("infotitle", String.class);
		sDate = getProperties().get("startdate", String.class);
		ranking = getProperties().get("rank", Integer.class);
		eDate = getProperties().get("enddate", String.class);
		importantInfo = getProperties().get("impinfo", String.class);
		publishDate = getProperties().get("publishDate", String.class);

	}

	public String getSDate() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat;
			inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
			Date fdat = inputFormat.parse(sDate);
			sDate = sdf.format(fdat);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
		return sDate;
	}

	public String getEDate() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat;
			inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
			Date fdat = inputFormat.parse(eDate);
			eDate = sdf.format(fdat);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}

		return eDate;
	}

	public String getPublishDate() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat;
			inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
			Date fdat = inputFormat.parse(publishDate);
			publishDate = sdf.format(fdat);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
		return publishDate;
	}

	public Integer getRanking() {
		return ranking;
	}

	public String getImportantInfo() {
		return importantInfo;
	}

	public String getTitle() {
		return title;
	}

}

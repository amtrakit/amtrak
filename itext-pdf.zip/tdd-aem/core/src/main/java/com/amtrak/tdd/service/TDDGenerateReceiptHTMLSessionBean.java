/**
 * THIS PROGRAM IS CONFIDENTIAL AND PROPRIETARY TO AMTRAK AND 

 * MAY NOT BE REPRODUCED, PUBLISHED OR DISCLOSED TO OTHERS WITHOUT AUTHORIZATION.  

 * COPYRIGHT � AMTRAK.  THIS WORK IS UNPUBLISHED.


 */
package com.amtrak.tdd.service;

import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.lang3.StringUtils;


import org.slf4j.LoggerFactory;

import com.amtrak.mulesoft.schema._2016._03._07.EVoucherInfo2;
import com.amtrak.mulesoft.schema._2016._03._07.FormOfPayment3;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.EVouchers;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment;
import com.amtrak.mulesoft.schema._2016._03._07.ObjectFactory;
import com.amtrak.mulesoft.schema._2016._03._07.Passenger;
import com.amtrak.mulesoft.schema._2016._03._07.PassengerName;
import com.amtrak.mulesoft.schema._2016._03._07.Payment3;
import com.amtrak.mulesoft.schema._2016._03._07.PaymentInfo3;
import com.amtrak.mulesoft.schema._2016._03._07.PaymentSummary2;
import com.amtrak.mulesoft.schema._2016._03._07.Payments3;
import com.amtrak.mulesoft.schema._2016._03._07.Segment4;
import com.amtrak.tdd.servlets.JCRService;


/**
 * Generate Receipt HTML Session Bean
 * Will generate HTML for a receipt request (TD/DD/CR/DR) using the information in the TDDBookingInfo
 */


public class TDDGenerateReceiptHTMLSessionBean {

    /**
     * Default constructor. 
     */
    public TDDGenerateReceiptHTMLSessionBean() {
        // TODO Auto-generated constructor stub
    }
        
    // Create the logger.
    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(TDDGenerateReceiptHTMLSessionBean.class);
    
	private  MultiRideDataHolder multiRideType = null;
		
	String[] orgStationCode = new String[60];
	String[] desStationCode = new String[60];
	String[] orgStationCity = new String[60];
	String[] desStationCity = new String[60];
	String[] orgStationState = new String[60];
	String[] desStationState = new String[60];
	String[] orgStationStreet = new String[60];
	String[] desStationStreet = new String[60];
	String tripStartDate = null;
	String tripStartDateFooter = null;
	String tktType = null;
	String orgSttCode = null;;
	String desSttCode = null;
	String orgCity = null;
	String desCity = null;
	String orgStreet = null;
	String desStreet = null;
	String PNRNumber = null;
	int bxForRoundTrip = 0;
	int endOfPage = 650;
	int bxFrmTop = 0;
	boolean newPageFlg = false;
	int pageNum = 1;
	boolean rndTripFlg = false;
	int rtnOnBox = 0;
	boolean autoTrain = false;
	int orgStreetLength = 14;
	int psgrNameLength = 21;
	int routeNameLength = 20;
	int trainOrgDesLength = 32;
	int desCityLength = 22;
	int orgCityLength = 22;
	int psgrTypeLen = 22;
	int rbdDescLength = 45;
	int endorsementLength = 54;
	List<String> tripSequence = new ArrayList<String>();
	
	boolean feeElement = true;
	List<String> formOfPayment = new ArrayList<String>();
	List<String> impInfoList = new ArrayList<String>();
	int noOfLogicalTrips = 0;
	List<BigInteger> psgrToBeDisplayed = new ArrayList<BigInteger>();
	List<BigInteger> psgrToBeDisplayedForEndorsements = new ArrayList<BigInteger>();
	float expressDeliveryFee = 0;
	
	int noOfTickets = 0;
	float eVoucherTotalFare = 0;
	float serviceFee = 0;

	boolean totalRefundedFlg = false;

	boolean reservationCanceled = false;

	// Is this is bulk fare booking
	boolean isBulkFare = false;
	
	//is this CCJPA request
	boolean isCCJPA = false;

	// PaymentInfo
	PaymentInfo3 paymentInfo2 = (new ObjectFactory()).createPaymentInfo3();
	// List of eVouchers from the request.
	EVouchers eVouchers = (new ObjectFactory()).createFormatSendPsgrNotificationRQFormatSendPsgrNotificationEVouchers();
	// String to hold the HTML as it is generated.
	private String HTML = "";
	// String to hold the request receipt type
	private String receiptType = "";

	private static final String SPACE = " ";
	// Utility Class
	TDDHelperFunctions tddCommonFunctions = new TDDHelperFunctions();

	// XMLConfiguration
	XMLConfiguration xmlConfiguration;

		
    /**
     * Public method to generate the HTML for the requested receipt.  All the request 
     * details are stored in the TDDBookingInfo object.
     * @param bookingInfo TDDBookingInfo
     * @return String generated HTML
     * @throws TDDGenerateReceiptHTMLException
     */
    public String generateHTML(JCRService jcrService, TDDBookingInfo bookingInfo) {

    	try {
    		LOG.info("inside method generateHTML(bookingInfo)");
    		LOG.debug("generateHTML(bookingInfo)" + bookingInfo.toString());

        	// Initialize all global variables
    		initializeGlobalVariables();
    		
    		// Retrieve the FormatRequest from the bookingInfo
    		FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ = bookingInfo.getBookingRequest();   		
    		ElapsedTime elapsedTime = new ElapsedTime("TDD *** generatedHTML: PNR: " + bookingInfo.getBookingPNRNumber());

    		// Is this is bulk fare booking
    		this.isBulkFare = TDDBookingUtils.isBulkFarePlan(formatSendPsgrNotificationRQ);
    		this.multiRideType =  new MultiRideDataHolder(formatSendPsgrNotificationRQ);
    		
    		//Added to check CCJPA request
    		this.isCCJPA = TDDBookingUtils.isCCJPARequest(formatSendPsgrNotificationRQ);
    		
			LOG.info("generateHTML: " + bookingInfo.getBookingPNRNumber() + " : "+ bookingInfo.getOperationType());

			
			// Is this a TD or DD receipt request
    		if (bookingInfo.getOperationType().equals(TDDConstants.DOCUMENT_REQUEST) || 
    				bookingInfo.getOperationType().equals(TDDConstants.DOCUMENT_RECEIPT_REQUEST)) {
    			// Determine the receipt type required
				if (tddCommonFunctions.isOriginalReceiptRequired(formatSendPsgrNotificationRQ)) {
					// Set the receipt type
					receiptType = bookingInfo.getReceiptType();
					// Set up the trip receipt values
					kindOfTrip(formatSendPsgrNotificationRQ);
					// Prepare ticket type details
					createTicketTypeForDuplicateReceipt(formatSendPsgrNotificationRQ);
					LOG.debug("Generate a dynamic receipt");
	            	prepareNonPurchaseReceipt(jcrService,bookingInfo); 
				}
				else {
					LOG.debug("Generate a static receipt");
					prepareBoilerPlate();
				}
    		}
    		// Is this a CR request
    		else if (bookingInfo.getOperationType().equals(TDDConstants.CANCEL_REFUND)) {
    			prepareNonPurchaseReceipt(jcrService,bookingInfo);
    		}
    		// Is this a DR request
    		else if (bookingInfo.getOperationType().equals(TDDConstants.DUPLICATE_RECEIPT_REQUEST)) {
    			// Set up the trip receipt values
    			kindOfTrip(formatSendPsgrNotificationRQ);
    			// Prepare ticket type details
    			createTicketTypeForDuplicateReceipt(formatSendPsgrNotificationRQ);
    			prepareNonPurchaseReceipt(jcrService,bookingInfo);
    		}
			
    		elapsedTime.stop();
    		LOG.debug(elapsedTime.toString());	

    		LOG.info("exiting generateHTML(bookingInfo)");	

    		return HTML;
                
    	}catch (Exception e) {
       		LOG.error("Exception : Error occured during HTML processing. PNRNumber: "+bookingInfo.getBookingPNRNumber(), e);
       		return null;
    	}
    }

	/**
	 * Method to initialize all the global variables in this SessionBean to ensure the values used
	 * in the previous request will not be re-used.
	 */
    private void initializeGlobalVariables() {

		LOG.debug(this.getClass().getName(),"entering method initializeGlobalVariables");


    	orgStationCode = new String[60];
    	desStationCode = new String[60];
    	orgStationCity = new String[60];
    	desStationCity = new String[60];
    	orgStationState = new String[60];
    	desStationState = new String[60];
    	orgStationStreet = new String[60];
    	desStationStreet = new String[60];
    	tripStartDate = null;
    	tripStartDateFooter = null;
    	tktType = null;
    	orgSttCode = null;;
    	desSttCode = null;
    	orgCity = null;
    	desCity = null;
    	orgStreet = null;
    	desStreet = null;
    	PNRNumber = null;
    	bxForRoundTrip = 0;
    	endOfPage = 650;
    	bxFrmTop = 0;
    	newPageFlg = false;
    	pageNum = 1;
    	rndTripFlg = false;
    	rtnOnBox = 0;
    	autoTrain = false;
    	orgStreetLength = 14;
    	psgrNameLength = 23;
    	routeNameLength = 20;
    	trainOrgDesLength = 32;
    	desCityLength = 22;
    	orgCityLength = 22;
    	psgrTypeLen = 22;
    	rbdDescLength = 45;
    	endorsementLength = 54;
    	tripSequence = new ArrayList<String>();
    	
    	feeElement = true;
    	formOfPayment = new ArrayList<String>();
    	impInfoList = new ArrayList<String>();
    	noOfLogicalTrips = 0;
    	psgrToBeDisplayed = new ArrayList<BigInteger>();
    	psgrToBeDisplayedForEndorsements = new ArrayList<BigInteger>();
    	expressDeliveryFee = 0;
    	
    	noOfTickets = 0;
    	eVoucherTotalFare = 0;
    	serviceFee = 0;

    	totalRefundedFlg = false;

    	reservationCanceled = false;
    	
    	isBulkFare = false;
    	
    	// PaymentInfo
    	paymentInfo2 = (new ObjectFactory()).createPaymentInfo3();
    	// List of eVouchers from the request.
    	eVouchers = (new ObjectFactory()).createFormatSendPsgrNotificationRQFormatSendPsgrNotificationEVouchers();
    	// String to hold the HTML as it is generated.
    	HTML = "";
    	// String to hold the request receipt type
    	receiptType = "";

		LOG.debug(this.getClass().getName(), "exiting method initializeGlobalVariables");

     }

    /**
	 * Method to process a duplicate receipt request.
	 * @param formatSendPsgrNotificationRQ
	 * @throws ParseException
	 */
	private void prepareNonPurchaseReceipt(JCRService jcrService, TDDBookingInfo bookingInfo) throws ParseException {
		
		LOG.debug(this.getClass().getName(),"entering  prepareNonPurchaseReceipt(TDDBookingInfo bookingInfo)");
		
		paymentInfo2 = bookingInfo.getBookingRequest().getFormatSendPsgrNotification().getPaymentInfo();
		receiptType = bookingInfo.getReceiptType();
		tddCommonFunctions.identifyReceiptType(bookingInfo.getBookingRequest());
		reservationCanceled = bookingInfo.getReservationCanceled();
		
		//Heading Changes (Travel Summary). Only Receipt will be sent as part of the email.
		prepareHTMLHeader();
		prepareReceiptHeading(bookingInfo.getOperationType());
		prepareReceiptHeadingDetails(bookingInfo);
		
		prepareReservationNumberDetails(bookingInfo.getBookingRequest());		    
		prepareReceipt(jcrService,bookingInfo.getBookingRequest());

		LOG.debug(this.getClass().getName(),"exiting  prepareNonPurchaseReceipt(TDDBookingInfo bookingInfo)");

	}

	private String getReceiptHeadingText(String operationType) {

		LOG.debug(this.getClass().getName(),"entering  getReceiptHeadingText(String operationType)");
		
		String receiptHeading = TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.headers.default");
		if (operationType.equals(TDDConstants.DUPLICATE_RECEIPT_REQUEST)) 
			receiptHeading = TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.headers.duplicate");
		else if (operationType.equals(TDDConstants.CANCEL_REFUND))
			receiptHeading = TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.headers.cancelRefund");

		if(receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE))
			receiptHeading = TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.headers.amountDue");

		LOG.debug(this.getClass().getName(),"exiting  getReceiptHeadingText(String operationType)");
		return receiptHeading;
	}

	/**
	 * Method to add the Duplicate Receipt Heading to the HTML string
	 */
	private void prepareReceiptHeading(String operationType){		

		LOG.debug(this.getClass().getName(),"entering  prepareReceiptHeading(String operationType)");
		HTML += "<div class=\"container\">";
		HTML += "<div class=\"LeftDiv1\">";
		HTML += "<span class=\"ReceiptLiteral\">" + getReceiptHeadingText(operationType) + "</span>";
		HTML += "</div>";
		HTML += "<div class=\"RightDiv1\">";
		HTML += "<img style=\"margin-top:-3px;\" src=\"https://www.amtrak.com/images/amtrak_logo_rcpt.png\">";
		HTML += "</div>";
		HTML += "</div>";
		
		LOG.debug(this.getClass().getName(),"exiting  prepareReceiptHeading(String operationType)");
	}

	/**
	 * Method to add the Boiler Plate Receipt HTML to the HTML string
	 */
	private void prepareBoilerPlate(){	
		LOG.debug(this.getClass().getName(),"entering  prepareBoilerPlate()");
		if(isCCJPA){
			HTML = TDDResources.BOILER_PLATE_HTML_CCJPA;
		}else{
			HTML = TDDResources.BOILER_PLATE_HTML;
		}
		LOG.debug(this.getClass().getName(),"exiting  prepareBoilerPlate()");	}

	/**
	 * Method to set parameters required to build the HTML
	 * @param formatSendPsgrNotificationRQ
	 * @throws ParseException
	 */
	private void kindOfTrip(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ) throws ParseException {

		LOG.debug(this.getClass().getName(), "entering kindOfTrip(formatSendPsgrNotificationRQ)");	

		//Format RQ
    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();    	
    	List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
		int logTripCount = 0;
		int segCount=0;
		String trainNumber = null;
		String orgTrainCity = null;
		String desTrainCity = null;
		String trainDate = null;
		for (Iterator j = logicalTripListRQ.iterator(); j.hasNext(); )  { 
			LOG.debug(this.getClass().getName(), "entering kindOfTrip logicalTripListRQ Start **");	
			boolean expDelFeeFlg = false;
			boolean serviceFeeFlg = false;
			List segmentsList  = ((FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip)j.next()).getSegments().getSegment();
			for (Iterator i = segmentsList.iterator(); i.hasNext(); )  {        			
    			Segment segment = new Segment();
    			segment = (Segment) i.next();
				if(segment.getTickets() != null){
					LOG.debug(this.getClass().getName(),"entering kindOfTrip Tickets  **");	
			
					List<Ticket> ticketList = segment.getTickets().getTicket();	
    				for (Iterator itr = ticketList.iterator(); itr.hasNext(); )  {        			
    		    		Ticket ticket = new Ticket();
    		    		ticket = (Ticket) itr.next(); 		    		    		
    		    		if(ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null &&
    		    				ticket.getPricingItem().getFarePlans().getFarePlan().get(0) != null){	    		    			
    		    			if("EXDL".equalsIgnoreCase(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode())){
	    		    			//Store Express Delivery Fee Amount
	    		    			expressDeliveryFee = ticket.getPricingItem().getTariff().getRailFare().floatValue();
	    		    			expDelFeeFlg = true;		  
    		    			}else if("FEE".equalsIgnoreCase(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().substring(0, 3))){
	    		    			//Store Service Fee Amount
	    		    			serviceFeeFlg = true;		  
    		    			}
    		    		}
    				}
				}
	    		if(!expDelFeeFlg && !serviceFeeFlg){
					LOG.debug(this.getClass().getName(),"entering expDelFeeFlg FALSE*********");	
	    	
	    			if(logTripCount == 0 && segCount == 0){
	    				//TDD3
	    				tripStartDate = (this.multiRideType.isValid() == false)?TDDDateUtils.convertDateToMMM_dd_yyyy(segment.getDepartureDateTime()): "";
	    				tripStartDateFooter = (this.multiRideType.isValid() == false)?TDDDateUtils.convertDateToMMM_dd_yyyy(segment.getDepartureDateTime()): "";
	    			}
	    			
	    			//TDD3 - the date conversion method convertDateToMMMddyyyy below takes care of null values, but the check is provided below to make it explicit.
					XMLGregorianCalendar depDateTime = (!this.multiRideType.isValid())? segment.getDepartureDateTime(): null;
					String trainNumberDetailsStr = (!this.multiRideType.isValid())?segment.getTrainDetails().getTrainNumber().toString():"";					
		
	    			
	    			if(trainNumber != null && trainNumberDetailsStr.equals(trainNumber)
		    				 && segment.getOrigin().getAddress().getCity().equalsIgnoreCase(orgTrainCity) &&
		    				segment.getDestination().getAddress().getCity().equalsIgnoreCase(desTrainCity) &&
		    				TDDDateUtils.convertDateToMMM_dd_yyyy(depDateTime).equals(trainDate)){
	    				//Duplicate segment - Do nothing
	    			}else{	
	    				//TDD3
		    			trainNumber = (!this.multiRideType.isValid())?segment.getTrainDetails().getTrainNumber().toString():"";
		    			trainDate = (!this.multiRideType.isValid())? TDDDateUtils.convertDateToMMM_dd_yyyy(segment.getDepartureDateTime()):"";
		    			if(segment.getOrigin().getAddress() != null)
		    				orgTrainCity = segment.getOrigin().getAddress().getCity().toUpperCase();
		    			else
		    				orgTrainCity = null;
		    			if(segment.getDestination().getAddress() != null)
		    				desTrainCity = segment.getDestination().getAddress().getCity().toUpperCase();
		    			else
		    				desTrainCity = null;
		    			
		    			if(orgStationCode[logTripCount] == null && desStationCode[logTripCount] == null){
		    				tripSequence.add(segment.getOrigin().getCode());
		    				tripSequence.add(segment.getDestination().getCode());
		    				orgStationCode[logTripCount] = segment.getOrigin().getCode();
		    				desStationCode[logTripCount] = segment.getDestination().getCode();
		    				if(segment.getOrigin().getAddress() != null){
			    				orgStationCity[logTripCount] = segment.getOrigin().getAddress().getCity();
			    				orgStationState[logTripCount] = segment.getOrigin().getAddress().getState();
			    				orgStationStreet[logTripCount] = segment.getOrigin().getAddress().getStreet2();
		    				}else{
		    					orgStationCity[logTripCount] = null;
			    				orgStationState[logTripCount] = null;
			    				orgStationStreet[logTripCount] = null;
		    				}
		    				if(segment.getDestination().getAddress() != null){
			    				desStationCity[logTripCount] = segment.getDestination().getAddress().getCity();				    				
			    				desStationState[logTripCount] = segment.getDestination().getAddress().getState();			    				
			    				desStationStreet[logTripCount] = segment.getDestination().getAddress().getStreet2();
		    				}else{
		    					desStationCity[logTripCount] = null;
		    					desStationState[logTripCount] = null;
		    					desStationStreet[logTripCount] = null;
		    				}	    				
		    			}else{
		    				if(desStationCode[logTripCount].equals(segment.getOrigin().getCode())){
		    					tripSequence.add(segment.getDestination().getCode());
		    					desStationCode[logTripCount] = segment.getDestination().getCode();
		    					if(segment.getDestination().getAddress() != null){
				    				desStationCity[logTripCount] = segment.getDestination().getAddress().getCity();				    				
				    				desStationState[logTripCount] = segment.getDestination().getAddress().getState();			    				
				    				desStationStreet[logTripCount] = segment.getDestination().getAddress().getStreet2();
			    				}else{
			    					desStationCity[logTripCount] = null;
			    					desStationState[logTripCount] = null;
			    					desStationStreet[logTripCount] = null;
			    				}
		    				}else{
		    					//If there is dis-continuation in Cities, it means Multi-Cities 
		    					++logTripCount;	
		    					orgStationCode[logTripCount] = segment.getOrigin().getCode();
			    				desStationCode[logTripCount] = segment.getDestination().getCode();
			    				if(segment.getOrigin().getAddress() != null){
				    				orgStationCity[logTripCount] = segment.getOrigin().getAddress().getCity();
				    				orgStationState[logTripCount] = segment.getOrigin().getAddress().getState();
				    				orgStationStreet[logTripCount] = segment.getOrigin().getAddress().getStreet2();
			    				}else{
			    					orgStationCity[logTripCount] = null;
				    				orgStationState[logTripCount] = null;
				    				orgStationStreet[logTripCount] = null;
			    				}
			    				if(segment.getDestination().getAddress() != null){
				    				desStationCity[logTripCount] = segment.getDestination().getAddress().getCity();				    				
				    				desStationState[logTripCount] = segment.getDestination().getAddress().getState();			    				
				    				desStationStreet[logTripCount] = segment.getDestination().getAddress().getStreet2();
			    				}else{
			    					desStationCity[logTripCount] = null;
			    					desStationState[logTripCount] = null;
			    					desStationStreet[logTripCount] = null;
			    				}
		    				}
		    			}
		    			if(segment.getTrainDetails().getRouteName() != null && "AUTO TRAIN".equalsIgnoreCase(segment.getTrainDetails().getRouteName())){
		    				autoTrain = true;
		    			}
		    			++segCount;
	    			}//End of Else
	    		}//	    			
			}//End of Segment Iterator				
			if(!expDelFeeFlg){	    	
				++logTripCount;
				++noOfLogicalTrips;
			}
	     }//End of Logical Iterator		
		LOG.debug(this.getClass().getName(),"exiting kindOfTrip(formatSendPsgrNotificationRQ)");	
	}
	
	/**
	 * Method to prepare the ticket types
	 * @param formatSendPsgrNotificationRQ
	 */
	private void createTicketTypeForDuplicateReceipt(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){

		LOG.debug(this.getClass().getName(),"entering createTicketTypeForDuplicateReceipt(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");	

		orgSttCode = orgStationCode[0];
		orgCity = orgStationCity[0]+", "+orgStationState[0];
		orgStreet = orgStationStreet[0];
		for(int i=0; i< orgStationCode.length; i++){
			if(orgStationCode[i]!= null && orgStationCode[i+1]!= null){
				if(desStationCode[i].equals(orgStationCode[i+1])){
					if(orgStationCode[i+2]== null){
						if(desStationCode[i+1].equals(orgStationCode[0])){
							//Round-Trip
							tktType = TDDSystemConfiguration.getStringProperty("reservationNumberDetails.tripType.roundTrip");
							desSttCode = desStationCode[0];
							desCity = desStationCity[0]+", "+desStationState[0];
							desStreet = desStationStreet[0];
							rtnOnBox = i+2;
							break;
						}else{
							//Multi-City
							tktType = TDDSystemConfiguration.getStringProperty("reservationNumberDetails.tripType.multiCity");
							desSttCode ="MULTIPLE CITIES";
							break;
						}
					}
				}else{
					//Multi-City
					tktType = TDDSystemConfiguration.getStringProperty("reservationNumberDetails.tripType.multiCity");
					desSttCode ="MULTIPLE CITIES";
					break;
				}
			}else{
				if(i==0 && orgStationCode[i].equals(desStationCode[i])){						
					//Round-Trip
					rndTripFlg = true;
					tktType = TDDSystemConfiguration.getStringProperty("reservationNumberDetails.tripType.roundTrip");
					desSttCode = desStationCode[i];
					desCity = desStationCity[i]+", "+desStationState[i];
					desStreet = desStationStreet[i];
					break;
				}else{
					//One-Way
					tktType = TDDSystemConfiguration.getStringProperty("reservationNumberDetails.tripType.oneWay");
					desSttCode = desStationCode[i];
					desCity = desStationCity[i]+", "+desStationState[i];
					desStreet = desStationStreet[i];
					break;
				}
			}
		}
		
		if("Multi-City Trip".equals(tktType)){
			orgSttCode = orgSttCode +"-"+desSttCode;
			desSttCode="";
			orgCityLength = 44;
		}
		if("Round-Trip".equals(tktType) && noOfLogicalTrips == 1){
			for (Iterator<String> trip = tripSequence.iterator(); trip.hasNext(); )  {
	    		String stnCode = trip.next().toString();		    		 		
				int frstIndex = tripSequence.indexOf(stnCode);
				int lastIndex = tripSequence.lastIndexOf(stnCode);
				if(frstIndex == lastIndex){						
					//Format RQ
			    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();    	
			    	List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
					for (Iterator<LogicalTrip> j = logicalTripListRQ.iterator(); j.hasNext(); )  { 
						List<Segment> segmentsList  = ((FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip)j.next()).getSegments().getSegment();
						for (Iterator<Segment> i = segmentsList.iterator(); i.hasNext(); )  {        			
			    			Segment4 segment = new Segment4();
			    			segment = (Segment4) i.next();				    			
			    			if(segment.getDestination().getCode().equals(stnCode)){
			    				desSttCode = segment.getDestination().getCode();
				    			desCity = segment.getDestination().getAddress().getCity()+", "+ segment.getDestination().getAddress().getState();
				    			desStreet = segment.getDestination().getAddress().getStreet2();
				    			break;
			    			}
						}//End of Segment Iterator
				     }//End of LogicalTrip Iterator
				}
			}
		}
		LOG.debug(this.getClass().getName(),"exiting createTicketTypeForDuplicateReceipt(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");	

	}
	
	private void prepareHTMLHeader(){	
		LOG.debug(this.getClass().getName(),"prepareHTMLHeader");	
	
		HTML ="<html><head><title>Dynamically Generated HTML</title>";
	    
	    HTML += "<style TYPE=\"text/css\">";
	    HTML += "body{font-family:verdana; width:612px;margin-top:45px;margin-right:30px;margin-bottom:20px;margin-left:30px;}";
        HTML += "div.ReceiptsBody{width:612px;margin-top:0px;margin-right:30px;margin-bottom:20px;margin-left:30px;}";
        //TDD2 changes the bulleted list should align with the table edge
        HTML += "ul{padding:8px;margin:8px;}";

        HTML += "span.ReceiptLiteral{font-size:11.0pt;color:#CC0000;font-weight:bold;}";
        HTML += "span.ReceiptInfoLeft{font-size:11.0pt;color:#000000;margin-top:5px;display:block;}";
        
        HTML += "span.ReceiptInfoRight{font-size:10.0pt;color:#333333; margin-left:56px;margin-top:3px;display:block;}";

        HTML += "span.ResFromAndTo{font-weight:bold;font-size:13.0pt;color:#333333;margin-top:10px;display:block;}";
        HTML += "span.ResDate{font-size:11.0pt;color:#333333;margin-top:5px;display:block;}";

        HTML += "span.ResNumber{font-size:18.0pt;color:#003E89;display:block;font-weight:bold;}";
        HTML += "div.Instructions{font-size:11.0pt;color:#333333;margin-top:25px;display:block;border:1px solid #666666;text-align:left;padding:3px;}";
        HTML += "span.InstructionsInfo{line-height:17px;}";

        HTML += "span.BillingHeading{font-size:14.0pt;color:#003E89;margin-top:25px;display:block;}";
        HTML += "div.BillingInfoBox{margin-bottom:5px;margin-top:5px;display:block;border:1px solid #666666;}";
        HTML += "div.BillingMainBox{font-size:11.0pt;color:#333333;display:block;width:100%;}";
		HTML += "span.BillDispBlock{display:block;margin-top:5px;vertical-align:top;}";

		HTML += "span.BillingBodyBox{font-size:11.0pt;color:#333333;margin-top:5px;display:block; padding-right:5px; padding-left:5px;}";

		HTML += "span.HorizontalRule{width:100%;color:#666666;margin-bottom:-14px;}";
		HTML += "div.BillingInfo{font-size:11.0pt;color:#333333;margin-top:5px;display:block;border:1px solid #666666; padding-top:8px; padding-bottom:8px; padding-right:5px; padding-left:5px;}";
		
		HTML += "div.BillingContainerInnerDivColor {overflow:auto;background-color:#FFD7B3;}";
		HTML += "div.BillingContainerInnerDiv {overflow:auto;}";
		
		HTML += "span.BillingInfoLeft{font-size:11.0pt;color:#333333;display:block;margin-top:3px;}";
        HTML += "span.BillingInfoRight{font-size:11.0pt;color:#333333; word-spacing:20px; display:block;font-weight:bold;}";
        HTML += "div.BillingTotal{text-align: right;line-height:2;background-color:#CBE4F1;font-size:11.0pt;color:#333333; display:block;font-weight:bold;}";
		HTML += "span.BillingTotalAlign{display:block;margin-right:5px;}";
        
        HTML += "div.Endorsements{margin-top:10px; margin-bottom:8px;padding-right:5px; padding-left:5px;}";
        HTML += "span.EndorsementHeading{display:block;font-size:10.0pt;color:#5C5C5C;font-weight:bold}";
        HTML += "span.EndorsementDetails{display:block;font-size:9.0pt;color:#333333;margin-top:5px;}";
		
		HTML += ".BillingContainer {overflow-y:auto;clear:both; }";
		HTML += ".BillingLeftDiv1 {width: 68%;float:left;text-align: left;padding-left:5px;padding-top:8px;padding-bottom:8px;}";
        HTML += ".BillingRightDiv1 {width: 30%;float:right;text-align: right;padding-right:5px;padding-top:8px;padding-bottom:8px;}";
        
        //Multiride css
        HTML +="td.BillinInfoTotalStaticText {	min-width:40px;	width:40px;border:0px;padding:0px;display:block}";
        HTML +="td.BillinInfoTotalValue {min-width:90px; width:90px;border:0px;padding:0px;display:block;}";
        HTML +="div.BillinInfoDivTotalStaticText{color:#333333;text-align:left;font-weight:bold}";
        HTML +="div.BillinInfoDivTotalValue{color:#333333;text-align:right;font-weight:bold;margin-right:5px}";
        
        //TDD2 changes
		HTML += "div.ChangeSummaryContainer{background-color:#CBE4F1; line-height:2;font-size:11.0pt;color:#333333;font-weight:bold;}";
		HTML += "div.ChangeSummaryAlignLeft{float: left; text-align:right;width: 450px; overflow: auto;}";
        HTML += "div.ChangeSummaryAlignRight{margin-left: 450px; margin-right:5px;text-align:right;}";
        
        HTML += "span.ChangeSummaryTripDetails{display:block;font-size:10.0pt;color:#5C5C5C;margin-top:5px;display:block;padding-right:5px; padding-left:5px;}";      
        //TDD2
		HTML += "span.ChangeSummaryHeading{font-size:14.0pt;color:#003E89;margin-top:25px;display:block;border-color:white}";
		//TDD2
		HTML += "span.ChangeSummaryTrainInfo{width:600px;font-weight:bold;font-size:11.0pt;color:#333333;margin-top:5px;display:block;padding-right:5px; padding-left:5px;}";
		HTML += "div.ChangeSummaryBox{margin-top:5px;display:block;border:1px solid #666666;}";
		HTML += "div.ChangeSummaryMainBox{font-size:11.0pt;color:#333333;margin-top:8px;display:block;}";

		HTML += "span.ChangeSummaryDepart{font-size:10.0pt;color:#333333;display:block;margin-top:3px;padding-right:5px; padding-left:5px;}";
		HTML += "span.ChangeSummaryLeft{font-size:10.0pt;color:#333333;display:block;margin-top:5px;}";
        HTML += "span.ChangeSummaryRight{font-size:10.0pt;color:#333333; display:block;margin-top:5px;font-weight:bold;}";

        HTML += "span.ChangeSummaryTotalLeft{font-size:11.0pt;color:#333333;display:block;margin-top:5px;}";
        HTML += "span.ChangeSummaryTotalRight{font-size:11.0pt;color:#333333; display:block;margin-top:5px;font-weight:bold;}";

        HTML += "div.ChangeSummaryTotal{text-align: right;line-height:2;background-color:#CBE4F1;font-size:11.0pt;color:#333333; display:block;font-weight:bold;}";
        HTML += "span.ChangeSummaryAlign{display:block;margin-right:5px;}";

		HTML += "div.ChangeSummarySubTotalContainer{overflow:auto;background-color:#E0FFFF; line-height:2;font-size:11.0pt;font-weight:bold;}";
		HTML += "div.ChangeSummarySubTotalContainerWhiteBackGround{overflow:auto;line-height:2;font-size:11.0pt;font-weight:bold;}";
		HTML += "div.ChangeSummarySubTotalAlignLeft{float: left; text-align:right;width: 450px; }";
        HTML += "div.ChangeSummarySubTotalAlignRight{margin-left: 450px; margin-right:5px;text-align:right; }";
        
        HTML += "div.ChangeSummaryPenaltiesContainer{overflow:auto;line-height:1.5;margin-bottom:6px;font-size:11.0pt;font-weight:bold;}";
        HTML += "div.ChangeSummaryPenaltiesLeft{float: left; text-align:left;width: 450px; margin-left:5px;}";
        HTML += "div.ChangeSummaryPenaltiesRight{margin-left: 450px; margin-right:5px;text-align:right; }";

		HTML += "span.TicketTermsAndConditionsHeading{font-size:14.0pt;color:#003E89;margin-top:25px;display:block;margin-bottom:8px;}";
		HTML += "span.TicketTermsAndConditionsList{margin-top:10px;font-size:10.0pt;color:#333333;}";
		
		//Multiride changes
		HTML += "span.PassengersHeading{font-size:14.0pt;color:#003E89;margin-top:25px;display:block;}";
		HTML += "span.PassengerNameList{font-size:11.0pt;margin-top:5px;display:block;margin-bottom:8px;padding-top:10px;border-style:solid;border-width:1px;padding-bottom:10px;padding-right:5px;padding-left:5px;color:#333333;}";
		
		HTML += "span.ImportantInformationHeading{font-size:14.0pt;color:#003E89;margin-top:25px;display:block;margin-bottom:8px;}";
		HTML += "span.ImportantInformationList{margin-top:10px;font-size:10.0pt;color:#333333;}";

        HTML += ".container {overflow-y:auto;clear:both;}";
        HTML += ".LeftDiv1 {width: 64%;float:left;text-align: left;}";
        HTML += ".RightDiv1 {width: 35%;float:right;text-align: right;}";
        
        HTML += ".LeftDiv2 {width: 61%;float:left;text-align: left;}";
        HTML += ".RightDiv2 {width: 38%;float:right;text-align: left;}";
        HTML += ".fontBold{font-weight:bold;}";

    
	    HTML += "</style>";
	    
	    HTML += "</head>";
	    HTML += "<body>";
	    HTML += "<table><tbody><tr><td>";
	    HTML += "<div class=\"ReceiptsBody\">";  
	}
	
	

	/**
	 * Method to add the Receipt Heading details to the HTML string
	 * @throws ParseException
	 */
	private void prepareReceiptHeadingDetails(TDDBookingInfo bookingInfo) throws ParseException {		

		LOG.debug(this.getClass().getName(),"entering prepareReceiptHeadingDetails(TDDBookingInfo bookingInfo)");	

		HTML += "<div class=\"container\">";
			HTML += "<div class=\"LeftDiv2\" style=\"margin-top:5px;\">";						
				HTML += "<span class=\"ReceiptInfoLeft\">";
				HTML += TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.purchasedDate[@text]") + SPACE
						+ TDDDateUtils.convertDateToFormat(bookingInfo.getOriginalPurchaseDateTime(), TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.purchasedDate[@dateFormat]")) 
								+ SPACE + TDDConstants.PACIFIC_TIMEZONE + "</span>";
				if(bookingInfo.getModifiedPurchaseDateTime() != null){
					HTML += "<span class=\"ReceiptInfoLeft\">";
					HTML += TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.modifiedDate[@text]") + SPACE 
						+ TDDDateUtils.convertDateToFormat(bookingInfo.getModifiedPurchaseDateTime(), TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.modifiedDate[@dateFormat]"))
							+ SPACE + TDDConstants.PACIFIC_TIMEZONE +"</span>";
				}
				//TDD2 if it is cancel than change text
				if(this.receiptType.equals(TDDConstants.CANCEL_REFUND)){
					HTML += "<span class=\"ReceiptInfoLeft\">" + TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.thankYouText") + 
					"</span>";
				}else{		
					String thankYou = TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.thankYouPurchaseText");
					String retainText = TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.retainText");
					String printCarryText = TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.printCarryText"); 
					HTML += "<span class=\"ReceiptInfoLeft\">" + thankYou + "<ol><li>" + retainText + "</li>" +
									"<li>" + printCarryText + "</li></ol>" + 
							"</span>";
				}

			HTML += "</div>";
			HTML += "<div class=\"RightDiv2\" style=\"margin-top:10px;\">";
				if(bookingInfo.getMerchantID() != null){
					HTML += "<span class=\"ReceiptInfoRight\">" + TDDSystemConfiguration.getStringProperty("receiptHeaderDetails.merchantID") + bookingInfo.getMerchantID()+"</span>";
				}
				HTML += "<span class=\"ReceiptInfoRight\">60 Massachusetts Avenue</span>";
				HTML += "<span class=\"ReceiptInfoRight\">Washington, DC 20002</span>";				
				HTML += "<span class=\"ReceiptInfoRight\">800-USA-RAIL</span>";				
				HTML += "<span class=\"ReceiptInfoRight\">Amtrak.com</span>";
			HTML += "</div>";
		HTML += "</div>";

		LOG.debug(this.getClass().getName(),"exiting prepareReceiptHeadingDetails(TDDBookingInfo bookingInfo)");	
	}

	/**
	 * Method to add the reservation number section to the HTML string
	 * @param formatSendPsgrNotificationRQ
	 */
	private void prepareReservationNumberDetails(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){	

		LOG.debug(this.getClass().getName(),"entering prepareReservationNumberDetails(formatSendPsgrNotificationRQ)");	

		HTML += "<div></div>";
	    HTML += "<div class=\"container\" style=\"margin-top:15px;\">";
		HTML += "<span class=\"ResNumber\">" + TDDSystemConfiguration.getStringProperty("reservationNumberDetails.header") + SPACE + tddCommonFunctions.getPNRLocator(formatSendPsgrNotificationRQ)+"</span>";
		
		if(!receiptType.equals(TDDConstants.CANCEL_REFUND)){
			HTML += "<span class=\"ResFromAndTo\">"+reservationFromAndTo()+"</span>";
			String reservationCreationDate = this.multiRideType.isValid()?this.multiRideType.getDateHeaderText().toUpperCase():getReservationCreationDate(formatSendPsgrNotificationRQ);
			HTML += "<span class=\"ResDate\">" + reservationCreationDate + "</span>";
		}
		
		HTML += "</div>";

		LOG.debug(this.getClass().getName(),"exiting prepareReservationNumberDetails(formatSendPsgrNotificationRQ)");	

	}

	/**
	 * Method to add the From and To information to the HTML String
	 * @return String
	 */
	private String reservationFromAndTo(){

		LOG.debug(this.getClass().getName(),"entering reservationFromAndTo()");	

		String tripInfo = "";
		
		if(this.multiRideType.isValid()){
			tktType =  this.multiRideType.getRideTypeTextHTML();
		}
		
		if(desCity != null){
			tripInfo = orgCity +" - "+ desCity+" ("+tktType+")";
		}else{
			tripInfo = orgCity +" - ("+tktType+")";
		}

		LOG.debug(this.getClass().getName(),"exiting reservationFromAndTo()");	

		return tripInfo;
	}
	
	/**
	 * Method to get the reservation creation date in the format MMMMM d, yyyy
	 * @param formatSendPsgrNotificationRQ
	 * @return String
	 */
	private String getReservationCreationDate(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ) {

		LOG.debug(this.getClass().getName(),"entering getReservationCreationDate(formatSendPsgrNotificationRQ)");	

		SimpleDateFormat sdf = new SimpleDateFormat ( "MMMMM d, yyyy" ) ;
	    SimpleDateFormat sdfAct = new SimpleDateFormat("yyyy-MM-dd");
        String sDate = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getBookingInfo().getPNRCreationDate().toString(); 
        try {
            java.util.Date dtDate = new Date();
            dtDate = sdfAct.parse(sDate);
            sDate = sdf.format(dtDate).toUpperCase();
	      } catch (ParseException e) {
	  		LOG.error("Parse Exception : Error occured in getReservationCreationDate: ", e);
	      }  

		LOG.debug(this.getClass().getName(),"exiting getReservationCreationDate(formatSendPsgrNotificationRQ)");	

        return sDate;
	}

	/**
	 * Method to comeplete the receipt HTML.  Adds the following sections
	 *  - Instruction Details (If EVouchers present)
	 *  - Billing Heading
	 *  - eVouchers Heading (If EVouchers present)
	 *  - Purchase/Change Summary Heading
	 *  - Purchase/Change Summary Details
	 *  - Important Information Heading
	 * @param formatSendPsgrNotificationRQ
	 * @throws ParseException
	 */
	public void prepareReceipt(JCRService jcrService,FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ) throws ParseException {	
		//Point 1: Except Even Exchange all others will have Billing Information
		//Point 2: Except Purchase Summary all others from Point 1, will have Original Fare

		LOG.debug(this.getClass().getName(),"entering prepareReceipt(formatSendPsgrNotificationRQ)");	

		LOG.debug(this.getClass().getName(),"receiptType ** "+receiptType);	
		if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getEVouchers() != null){
			prepareInstructionDetails();
		}
	    prepareBillingHeading(receiptType);
	    prepareEVouchersHeading(formatSendPsgrNotificationRQ);
	    preparePurchaseOrChangeSummaryHeading(formatSendPsgrNotificationRQ, receiptType);
	    preparePurchaseOrChangeSummaryDetails(formatSendPsgrNotificationRQ, receiptType);
	    // TDD2
	    preparePassengerNameList(formatSendPsgrNotificationRQ);

	    prepareImportantInformationHeading(jcrService,receiptType);
	    HTML += "</div></td></tr></tbody></table>";
	    HTML += "</BODY></HTML>";

		LOG.debug(this.getClass().getName(),"exiting prepareReceipt(formatSendPsgrNotificationRQ)");	

	}

	
	/*
	 * Generates HTML content for the list of passengers for
	 * Purchase, Cancel and Exchange email receipts. 
	 */
	
	//TDD2
	private void preparePassengerNameList(FormatSendPsgrNotificationRQ request){
		String passengerHeader = TDDSystemConfiguration.getStringProperty("summarySectionDetails.passengersHeader");
		HTML += "<span class=\"PassengersHeading\">" + passengerHeader + "</span>";
		HTML += "<div>";
		HTML += "<span class=\"PassengerNameList\"> ";
		HTML += this.getCommaDelimitedPassengerList(request);
		HTML += "</span>";
		HTML += "</div>";

	}
	
	
	
	private void prepareImportantInformationHeading(JCRService jcrService, String receiptType){
		
		String importantInformationHeader = TDDSystemConfiguration.getStringProperty("importantInformation.header");
		if(this.multiRideType.isValid()){
			this.prepareImportantInformationHeadingForMultiRide(jcrService);
		}else{	
			if(receiptType.equals(TDDConstants.CANCEL_REFUND)){
	            if(jcrService != null){
	            	this.impInfoList = jcrService.getRefundReceiptImportantInformation(tktType);
	            }

				HTML += "<div>";
				HTML += "<span class=\"ImportantInformationHeading\">" + importantInformationHeader + "</span>";
				
				HTML += "<span class=\"HorizontalRule\"><hr></span>";
				HTML += "<span class=\"ImportantInformationList\">";
				HTML += "<ul>";	
				if (!impInfoList.isEmpty()) {
					for(String impInfo : impInfoList){
						HTML += "<li>"+impInfo+"</li>";
					}
				}
				HTML += "</ul>";
				HTML += "</span>";
				HTML += "</div>";
			}else{
	            if(jcrService != null){
	            	this.impInfoList = jcrService.getSalesReceiptImportantInformation(tktType);
	            }

				HTML += "<div>";
					HTML += "<span class=\"ImportantInformationHeading\">" + importantInformationHeader + "</span>";
					HTML += "<span class=\"HorizontalRule\"><hr></span>";
					HTML += "<span class=\"ImportantInformationList\">";
						HTML += "<ul>";
						if (!impInfoList.isEmpty()) {
							for(String impInfo : impInfoList){
								HTML += "<li>"+impInfo+"</li>";
							}
						}
						HTML += "</ul>";
					HTML += "</span>";
				HTML += "</div>";
			}
		}
	}
	
	private void prepareImportantInformationHeadingForMultiRide(JCRService jcrService){
		String importantInformationHeader = TDDSystemConfiguration.getStringProperty("importantInformation.header");
	
		if(receiptType.equals(TDDConstants.DOWNGRADE_REFUND) || receiptType.equals(TDDConstants.CANCEL_REFUND)){
            if(jcrService != null){
            	this.impInfoList = jcrService.getRefundReceiptImportantInformation(tktType);
            }
			HTML += "<div>";
			HTML += "<span class=\"ImportantInformationHeading\">" + importantInformationHeader + "</span>";
			HTML += "<span class=\"HorizontalRule\"><hr></span>";
			HTML += "<span class=\"ImportantInformationList\">";
			HTML += "<ul>";			
			if (!impInfoList.isEmpty()) {
				for(String impInfo : impInfoList){
					HTML += "<li>"+impInfo+"</li>";
				}
			}
			HTML += "</ul>";
			HTML += "</span>";
			HTML += "</div>";
		}else{
            if(jcrService != null){
            	this.impInfoList = jcrService.getSalesReceiptImportantInformation(tktType);
            }

			HTML += "<div>";
			HTML += "<span class=\"ImportantInformationHeading\">" + importantInformationHeader + "</span>";
			HTML += "<span class=\"HorizontalRule\"><hr></span>";
			HTML += "<span class=\"ImportantInformationList\">";
			HTML += "<ul>";			
			if (!impInfoList.isEmpty()) {
				for(String impInfo : impInfoList){
					HTML += "<li>"+impInfo+"</li>";
				}
			}
			HTML += "</ul>";
			HTML += "</span>";
			HTML += "</div>";
		}
	}
	
	
	
	/**
	 * Method to add the Instruction Details to the HTML string
	 */
	private void prepareInstructionDetails(){	

		LOG.debug(this.getClass().getName(),"entering prepareInstructionDetails()");	

		HTML += "<div class=\"Instructions\">";
	    HTML += "<span class=\"InstructionsInfo\">Your transaction has resulted in a credit. We have created an eVoucher (electronic voucher) showing this credit.";
		HTML += " This eVoucher is redeemable for future travel and in some cases may also have refund value.";
		if(isCCJPA){
			HTML += " For more information, including conditions for use, go to <a href=\"http://www.amtrak.com/evoucher\">www.amtrak.com/evoucher</a> or call 877-974-3322.</span>";
		}else{
			HTML += " For more information, including conditions for use, go to <a href=\"http://www.amtrak.com/evoucher\">www.amtrak.com/evoucher</a> or call 800-USA-RAIL.</span>";
		}
		HTML += "</div>";

		LOG.debug(this.getClass().getName(),"exiting prepareInstructionDetails()");	

	}
	
	/**
	 * Method to add the Billing Heading to the HTML string, the billing heading is comprised of
	 * the address of the payee along with the Billing type and the amount. If the payment type
	 * is of Purchase or Upgrade exchange, the total is displayed inline with the payment type.
	 * <p>
	 * Billing information is not present for payments of type Even Exchange.
	 * <p>
	 * The logic below is divided into four sections.
	 * <ol>
	 * <li> The first block checks if the billing address or credit card details 
	 * is present in the credit card and adds the address <i>once</i> if found </li>
	 * <li> The second block scans for all the credit cards for the user
	 *  and adds the card type and total in alternate colors </li>
	 * <li> The third block scans for all the different kinds of payments done and
	 * lists them with payment type and total amount <code>(e.g: Gift Certificate  100$)</code>
	 * </li>
	 * <li> The last block checks if the type is of purchase or upgrade and formats the total 
	 * displayed.
	 * </li>
	 * </ol>
	 * 
	 * @param formatSendPsgrNotificationRQ
	 * @param receiptType
	 */
	private void prepareBillingHeading(String receiptType){

		LOG.debug(this.getClass().getName(),"entering prepareBillingHeading(formatSendPsgrNotificationRQ,receiptType)");	

		String totalHeading = TDDSystemConfiguration.getStringProperty("billingInformation.total");
		String HTMLHEADER = "";
		String HTMLBODY = "";
		String HTMLFOOTER = "";
		

		LOG.info(this.getClass().getName(),"receiptType.equals(EVEN_EXCHANGE) ** "+receiptType.equals(TDDConstants.EVEN_EXCHANGE));	
		//Except Even Exchange all others will have Billing Information		
		if(!receiptType.equals(TDDConstants.EVEN_EXCHANGE)){
			
			Payments3 payments2 = (new ObjectFactory()).createPayments3();
			PaymentSummary2 paySummary = (new ObjectFactory()).createPaymentSummary2();
			payments2 = paymentInfo2.getPayments();
			List<Payment3> payment2List = payments2.getPayment();
			paySummary = payments2.getPaymentSummary();
			
			
			
			HTMLHEADER += "<div>";
			HTMLHEADER += "<span class=\"BillingHeading\">" + TDDSystemConfiguration.getStringProperty("billingInformation.heading") + "</span>";
			HTMLHEADER += "</div>";
			HTMLHEADER += "<div class=\"BillingInfoBox\">";
				HTMLHEADER += "<div class=\"BillingMainBox\">";
				
				float totalFare = 0;
				int i =0;
				String billingBackGrdColor = "";
				boolean addressAddedForCreditCard = false;
				boolean hasMultipleFormsOfPayment =  this.isPaymentOfMultipleForms(payment2List);
							
				boolean creditCardFound = false;
				//Credit Card address should be shown only once. Even though there might be multiple credit cards,
				//address is always assumed to be same in ARROW.
				for (Iterator<Payment3> paymt2Itr = payment2List.iterator(); paymt2Itr.hasNext(); )  {
					Payment3 paymt2 = (Payment3) paymt2Itr.next();
					FormOfPayment3 formOfPayment2 =(new ObjectFactory()).createFormOfPayment3();
					formOfPayment2 = paymt2.getFormOfPayment();
					
						//Total Amount for this form of payment
						totalFare = totalFare + Math.abs(paymt2.getAmount().floatValue());
						
						//This Block is for Billing Address & Credit Card Details
						if(formOfPayment2.getCard() != null && formOfPayment2.getCard().getName()!=null && !creditCardFound){
								++i;
								billingBackGrdColor = prepareIBillingBackgroundColor(i);
								//This is the address block
								HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
								HTMLBODY += "<table style=\"width: 100%; border-collapse: collapse;\">";
									HTMLBODY += "<tr>";
										HTMLBODY += "<td style=\"width: 100%; border: 0pt none; padding: 0pt;\">";		
									HTMLBODY += "<span class=\"BillingBodyBox\">";
										HTMLBODY += "<span class=\"BillDispBlock\">"+formOfPayment2.getCard().getName()+"</span>";
										if(formOfPayment2.getCard().getBillingAddress() != null){
											if(formOfPayment2.getCard().getBillingAddress().getStreet1() != null){
												HTMLBODY += "<span class=\"BillDispBlock\">"+formOfPayment2.getCard().getBillingAddress().getStreet1()+"</span>";
											}
											if(formOfPayment2.getCard().getBillingAddress().getStreet2() != null){
												HTMLBODY += "<span class=\"BillDispBlock\">"+formOfPayment2.getCard().getBillingAddress().getStreet2()+"</span>";
											}
											if(formOfPayment2.getCard().getBillingAddress().getCity() != null){
												HTMLBODY += "<span class=\"BillDispBlock\">"+formOfPayment2.getCard().getBillingAddress().getCity()+", "+formOfPayment2.getCard().getBillingAddress().getState()+" "+formOfPayment2.getCard().getBillingAddress().getZipCode()+"</span>";
											}
											addressAddedForCreditCard = true;
										}
									HTMLBODY += "</span>";
									
									HTMLBODY += "</td>";
									HTMLBODY += "</tr>";
								HTMLBODY += "</table>";
								HTMLBODY += "<span class=\"HorizontalRule\"><hr style=\"clear:left;float:left;width:100%;height:1px;border:0;margin:0!important;margin:0 0 -14px 0;padding:0;color:#B0B0B0;background-color:#BFBFBF;top:0;\" /></span>";
								HTMLBODY += "</div>";
								creditCardFound = true;
						}						
							
						//Alternate Payments should have different background color						
						if(formOfPayment2.getCard() != null ){
							formOfPayment.add(TDDConstants.CREDIT_CARD);
							++i;
							billingBackGrdColor = prepareIBillingBackgroundColor(i);
							HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
								HTMLBODY += "<table style=\"width: 100%; border-collapse: collapse;\">";
									HTMLBODY += "<tr>";
										HTMLBODY += this.formatHTMLTableRowForPurchaseOrUpgrade(receiptType);
										//TDD2 add address block here if it is of type downgrade.
										
											if(receiptType.equals(TDDConstants.DOWNGRADE_REFUND) && !addressAddedForCreditCard){
												HTMLBODY += "<div class=\"BillingContainerInnerDivColor\">";
												HTMLBODY += "<table style=\"width: 100%; border-collapse: collapse;\">";
												HTMLBODY += "<tbody>";
												HTMLBODY += "<tr>";
												HTMLBODY += "<span class=\"BillingBodyBox\">";
												String userName = formOfPayment2.getCard().getName();
												HTMLBODY += "<span class=\"BillDispBlock\">" + (userName == null?"": userName) + "</span>";
												if(formOfPayment2.getCard().getBillingAddress() != null){
													if(formOfPayment2.getCard().getBillingAddress().getStreet1() != null){
														HTMLBODY += "<span class=\"BillDispBlock\">"+formOfPayment2.getCard().getBillingAddress().getStreet1()+"</span>";
													}
													if(formOfPayment2.getCard().getBillingAddress().getStreet2() != null){
														HTMLBODY += "<span class=\"BillDispBlock\">"+formOfPayment2.getCard().getBillingAddress().getStreet2()+"</span>";
													}
													if(formOfPayment2.getCard().getBillingAddress().getCity() != null){
														HTMLBODY += "<span class=\"BillDispBlock\">"+formOfPayment2.getCard().getBillingAddress().getCity()+", "+formOfPayment2.getCard().getBillingAddress().getState()+" "+formOfPayment2.getCard().getBillingAddress().getZipCode()+"</span>";
													}
												}
												    HTMLBODY += "</tr>";
													HTMLBODY += "</tbody>";
												    HTMLBODY += "</table>";
													HTMLBODY += "</span>";
													HTMLBODY += "</div>";
													HTMLBODY += "</div>";
											  }
											
												HTMLBODY += "<div class=\"BillingLeftDiv1\">";			
												String cardDebitOrCredit = TDDSystemConfiguration.getStringProperty("billingInformation.purchase");
												if(!receiptType.equals(TDDConstants.PURCHASE_SUMMARY)){
													if(receiptType.equals(TDDConstants.DOWNGRADE_REFUND) || receiptType.equals(TDDConstants.CANCEL_REFUND)){
														cardDebitOrCredit = TDDSystemConfiguration.getStringProperty("billingInformation.credit");
													}
												}
													String cardNum = formOfPayment2.getCard().getCardNumber().length() <= 4 ? formOfPayment2.getCard().getCardNumber() : formOfPayment2.getCard().getCardNumber().substring(formOfPayment2.getCard().getCardNumber().length() - 4);
													HTMLBODY += "<span class=\"BillingInfoLeft\"><span class=\"fontBold\">"+formOfPayment2.getCard().getRemarks().getRemark().get(0).getText()+"</span> ending in "+cardNum+" ("+cardDebitOrCredit+")"+"</span>";
													if(formOfPayment2.getCard().getAuthorizationCode() != null){
														HTMLBODY += "<span class=\"BillingInfoLeft\">" + TDDSystemConfiguration.getStringProperty("billingInformation.authorization") + SPACE + formOfPayment2.getCard().getAuthorizationCode()+ "</span>";
													}
												HTMLBODY += "</div>";
												HTMLBODY += "<div class=\"BillingRightDiv1\">";
												//TDD2 if the receipt type is Purchase or downgrade and type is card
													if(isPurchaseOrUpgradeType() && !hasMultipleFormsOfPayment){
														HTMLBODY += this.formatHTMLForTotalText("Total", tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), this.isBulkFare));
													}else{
														HTMLBODY += "<span class=\"BillingInfoRight\">" + tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), this.isBulkFare) +"</span>";
													}
												HTMLBODY += "</div>";										
										HTMLBODY += "</td>";
									HTMLBODY += "</tr>";
								HTMLBODY += "</table>";
								HTMLBODY += "<span class=\"HorizontalRule\"><hr style=\"clear:left;float:left;width:100%;height:1px;border:0;margin:0!important;margin:0 0 -14px 0;padding:0;color:#B0B0B0;background-color:#BFBFBF;top:0;\" /></span>";
							HTMLBODY += "</div>";
						}
				}
				for (Iterator<Payment3> paymt2Itr = payment2List.iterator(); paymt2Itr.hasNext(); )  {
					Payment3 paymt2 = (Payment3) paymt2Itr.next();
					FormOfPayment3 formOfPayment2 =(new ObjectFactory()).createFormOfPayment3();
					formOfPayment2 = paymt2.getFormOfPayment();
					
						//Total Amount for this form of payment
						totalFare = totalFare + Math.abs(paymt2.getAmount().floatValue());
						
						if(formOfPayment2.getEVoucher() != null){
							formOfPayment.add(TDDConstants.EVOUCHER);
							++i;
							billingBackGrdColor = prepareIBillingBackgroundColor(i);
							HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
									HTMLBODY += this.formatHTMLTableForPurchaseOrUpgrade(receiptType);
									HTMLBODY += "<tr>";
										HTMLBODY += this.formatHTMLTableRowForPurchaseOrUpgrade(receiptType);
												HTMLBODY += "<div class=\"BillingLeftDiv1\">";
													String voucherNumber = formOfPayment2.getEVoucher().getEVoucherNumber();
													if(StringUtils.isNotBlank(voucherNumber) && StringUtils.startsWithIgnoreCase(voucherNumber, "T")){
														HTMLBODY += "<span class=\"BillingInfoLeft\">"+"Transportation Voucher";
													}
													else{
													HTMLBODY += "<span class=\"BillingInfoLeft\">"+formOfPayment2.getEVoucher().getRemarks().getRemark().get(0).getText();												
													
													if(formOfPayment2.getEVoucher().getName()!= null){
														HTMLBODY += " "+formOfPayment2.getEVoucher().getName();
													}	
													}
													if(formOfPayment2.getEVoucher().getEVoucherNumber()!= null){
														HTMLBODY += " #"+voucherNumber;
													}
													HTMLBODY +="</span>";												
												HTMLBODY += "</div>";
												HTMLBODY += "<div class=\"BillingRightDiv1\">";
												//TDD2 if the payment is of type cash
												if(isPurchaseOrUpgradeType() && !hasMultipleFormsOfPayment){
													HTMLBODY += this.formatHTMLForTotalText("Total", tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare));
												}else{
													HTMLBODY += "<span class=\"BillingInfoRight\">" + tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare) +"</span>";
												}
												HTMLBODY += "</div>";									
										HTMLBODY += "</td>";
									HTMLBODY += "</tr>";
								HTMLBODY += "</table>";				
							HTMLBODY += "</div>";
						}
						
						//This Block is for Cash Details
						else if(formOfPayment2.getCash() != null){
							if(Float.floatToRawIntBits(paymt2.getAmount().floatValue()) > 0 || Float.floatToRawIntBits(paymt2.getAmount().floatValue()) < 0 ){		
								formOfPayment.add(TDDConstants.CASH);
								++i;
								billingBackGrdColor = prepareIBillingBackgroundColor(i);
								HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
									HTMLBODY += this.formatHTMLTableForPurchaseOrUpgrade(receiptType);
											HTMLBODY += "<tr>";
											HTMLBODY += this.formatHTMLTableRowForPurchaseOrUpgrade(receiptType);
													HTMLBODY += "<div class=\"BillingLeftDiv1\">";							
														HTMLBODY += "<span class=\"BillingInfoLeft\">"+formOfPayment2.getCash().getRemarks().getRemark().get(0).getText()+"</span>";
													HTMLBODY += "</div>";
													HTMLBODY += "<div class=\"BillingRightDiv1\">";
														//TDD2 if the payment is of type cash
													if(isPurchaseOrUpgradeType() && !hasMultipleFormsOfPayment){
															HTMLBODY += this.formatHTMLForTotalText("Total", tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare));
														}else{
															HTMLBODY += "<span class=\"BillingInfoRight\">" +  tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare) +"</span>";
														}
													HTMLBODY += "</div>";									
											HTMLBODY += "</td>";
										HTMLBODY += "</tr>";
									HTMLBODY += "</table>";
								HTMLBODY += "</div>";
							}
						}
						
						else if(formOfPayment2.getCheck() != null){
							formOfPayment.add(TDDConstants.CHECK);
							++i;
							billingBackGrdColor = prepareIBillingBackgroundColor(i);
							HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
							HTMLBODY += this.formatHTMLTableForPurchaseOrUpgrade(receiptType);
							
									HTMLBODY += "<tr>";
										HTMLBODY += this.formatHTMLTableRowForPurchaseOrUpgrade(receiptType);
													HTMLBODY += "<div class=\"BillingLeftDiv1\">";							
													HTMLBODY += "<span class=\"BillingInfoLeft\">"+formOfPayment2.getCheck().getRemarks().getRemark().get(0).getText();
													if(formOfPayment2.getCheck().getCheckNumber() != null){
														HTMLBODY += " #"+formOfPayment2.getCheck().getCheckNumber();
													}
													HTMLBODY +="</span>";												
												HTMLBODY += "</div>";
												HTMLBODY += "<div class=\"BillingRightDiv1\">";
													//TDD2 is payment of type check merge amount
													if(isPurchaseOrUpgradeType() && !hasMultipleFormsOfPayment){
														HTMLBODY += this.formatHTMLForTotalText("Total", tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare));
													}else{
														HTMLBODY += "<span class=\"BillingInfoRight\">" +  tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare) +"</span>";
													}
												HTMLBODY += "</div>";										
										HTMLBODY += "</td>";
									HTMLBODY += "</tr>";
								HTMLBODY += "</table>";
							HTMLBODY += "</div>";
						}
						
						else if(formOfPayment2.getExchange() != null){					
							if("Exchange Paper Tickets".equalsIgnoreCase(formOfPayment2.getExchange().getRemarks().getRemark().get(0).getText())){
								formOfPayment.add(TDDConstants.EXCHANGE);
								++i;
								billingBackGrdColor = prepareIBillingBackgroundColor(i);
								HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
									HTMLBODY += this.formatHTMLTableForPurchaseOrUpgrade(receiptType);
								
										HTMLBODY += "<tr>";
											HTMLBODY += this.formatHTMLTableRowForPurchaseOrUpgrade(receiptType);
													HTMLBODY += "<div class=\"BillingLeftDiv1\">";							
														HTMLBODY += "<span class=\"BillingInfoLeft\">"+formOfPayment2.getExchange().getRemarks().getRemark().get(0).getText();
														if(formOfPayment2.getExchange().getTicketNumber().getTicketNumber() != null){
															HTMLBODY += " #"+formOfPayment2.getExchange().getTicketNumber().getTicketNumber();
														}
														HTMLBODY +="</span>";	
													HTMLBODY += "</div>";
													HTMLBODY += "<div class=\"BillingRightDiv1\">";
													//TDD2 is payment if of type exchange - upgrade exchange
													if(isPurchaseOrUpgradeType() && !hasMultipleFormsOfPayment){
														HTMLBODY += this.formatHTMLForTotalText("Total", tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare));
													}else{
														HTMLBODY += "<span class=\"BillingInfoRight\">" + tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare) +"</span>";
													}
													HTMLBODY += "</div>";									
											HTMLBODY += "</td>";
										HTMLBODY += "</tr>";
									HTMLBODY += "</table>";
								HTMLBODY += "</div>";
							}else{
								totalFare = totalFare - Math.abs(paymt2.getAmount().floatValue());
							}
						}
						else if(formOfPayment2.getNAPNEAP() != null){
							formOfPayment.add(TDDConstants.NAPNEAP);						
							++i;
							billingBackGrdColor = prepareIBillingBackgroundColor(i);
							HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
								HTMLBODY += this.formatHTMLTableForPurchaseOrUpgrade(receiptType);
							
									HTMLBODY += "<tr>";
										HTMLBODY += this.formatHTMLTableRowForPurchaseOrUpgrade(receiptType);
												HTMLBODY += "<div class=\"BillingLeftDiv1\">";							
													HTMLBODY += "<span class=\"BillingInfoLeft\">"+formOfPayment2.getNAPNEAP().getRemarks().getRemark().get(0).getText();
													if(formOfPayment2.getNAPNEAP().getPassNumber() != null){
														HTMLBODY += " #"+formOfPayment2.getNAPNEAP().getPassNumber();
													}
													HTMLBODY +="</span>";
												HTMLBODY += "</div>";
												HTMLBODY += "<div class=\"BillingRightDiv1\">";
													//TDD2 if the payment is of type NAPEAP
													if(isPurchaseOrUpgradeType() && !hasMultipleFormsOfPayment){
														HTMLBODY += this.formatHTMLForTotalText("Total", tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare));
													}else{
														HTMLBODY += "<span class=\"BillingInfoRight\">" +  tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare) +"</span>";
													}
												HTMLBODY += "</div>";									
										HTMLBODY += "</td>";
									HTMLBODY += "</tr>";
								HTMLBODY += "</table>";
							HTMLBODY += "</div>";
						}
						else if(formOfPayment2.getMiscChargeOrder() != null){
							formOfPayment.add(TDDConstants.MISCORDER);
							++i;
							billingBackGrdColor = prepareIBillingBackgroundColor(i);
							HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
								HTMLBODY += this.formatHTMLTableForPurchaseOrUpgrade(receiptType);
							
									HTMLBODY += "<tr>";
										HTMLBODY += this.formatHTMLTableRowForPurchaseOrUpgrade(receiptType);
												HTMLBODY += "<div class=\"BillingLeftDiv1\">";							
													HTMLBODY += "<span class=\"BillingInfoLeft\">"+formOfPayment2.getMiscChargeOrder().getRemarks().getRemark().get(0).getText();
													if(formOfPayment2.getMiscChargeOrder().getMCONumber() != null){
														HTMLBODY += " #"+formOfPayment2.getMiscChargeOrder().getMCONumber();
													}
													HTMLBODY +="</span>";
												HTMLBODY += "</div>";
												HTMLBODY += "<div class=\"BillingRightDiv1\">";
													//TDD2 if the payment is of type  Misc
													if(isPurchaseOrUpgradeType() && !hasMultipleFormsOfPayment){
														HTMLBODY += this.formatHTMLForTotalText("Total", tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare));
													}else{
														HTMLBODY += "<span class=\"BillingInfoRight\">" +  tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare) +"</span>";
													}
												HTMLBODY += "</div>";									
										HTMLBODY += "</td>";
									HTMLBODY += "</tr>";
								HTMLBODY += "</table>";
							HTMLBODY += "</div>";
						}
						else if(formOfPayment2.getPassRider() != null){
							formOfPayment.add(TDDConstants.PASSRIDER);
							++i;
							billingBackGrdColor = prepareIBillingBackgroundColor(i);
							HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
								HTMLBODY += this.formatHTMLTableForPurchaseOrUpgrade(receiptType);
							
									HTMLBODY += "<tr>";
										HTMLBODY += this.formatHTMLTableRowForPurchaseOrUpgrade(receiptType);
												HTMLBODY += "<div class=\"BillingLeftDiv1\">";							
													HTMLBODY += "<span class=\"BillingInfoLeft\">"+formOfPayment2.getPassRider().getRemarks().getRemark().get(0).getText();
													if(formOfPayment2.getPassRider().getPassNumber() != null){
														HTMLBODY += " #"+formOfPayment2.getPassRider().getPassNumber();
													}
													HTMLBODY +="</span>";
												HTMLBODY += "</div>";
												HTMLBODY += "<div class=\"BillingRightDiv1\">";
													//TDD2 if the payment is of type Rider
													if(isPurchaseOrUpgradeType() && !hasMultipleFormsOfPayment){
														HTMLBODY += this.formatHTMLForTotalText("Total", tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare));
														
													}else{
														HTMLBODY += "<span class=\"BillingInfoRight\">" +  tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare) + "</span>";
													}
												HTMLBODY += "</div>";									
										HTMLBODY += "</td>";
									HTMLBODY += "</tr>";
								HTMLBODY += "</table>";
							HTMLBODY += "</div>";
						}
						else if(formOfPayment2.getOthers() != null){
							if(!"PD".equals(formOfPayment2.getOthers().getCode())){
								formOfPayment.add(TDDConstants.OTHERS);
								++i;
								billingBackGrdColor = prepareIBillingBackgroundColor(i);
								HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
									HTMLBODY += this.formatHTMLTableForPurchaseOrUpgrade(receiptType);
								
										HTMLBODY += "<tr>";
											HTMLBODY += this.formatHTMLTableRowForPurchaseOrUpgrade(receiptType);
													HTMLBODY += "<div class=\"BillingLeftDiv1\">";							
														HTMLBODY += "<span class=\"BillingInfoLeft\">"+formOfPayment2.getOthers().getRemarks().getRemark().get(0).getText();
														if(formOfPayment2.getOthers().getNumber() != null){
															HTMLBODY += " #"+formOfPayment2.getOthers().getNumber();
														}
														HTMLBODY +="</span>";
													HTMLBODY += "</div>";
													HTMLBODY += "<div class=\"BillingRightDiv1\">";
														//TDD2 if the payment is of type other
														if(isPurchaseOrUpgradeType() && !hasMultipleFormsOfPayment){
															HTMLBODY += this.formatHTMLForTotalText("Total", tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare));
														}else{
															HTMLBODY += "<span class=\"BillingInfoRight\">" + tddCommonFunctions.getTotalAmountFormat(Math.abs(paymt2.getAmount().floatValue()), isBulkFare) +"</span>";
														}
													HTMLBODY += "</div>";									
											HTMLBODY += "</td>";
										HTMLBODY += "</tr>";
									HTMLBODY += "</table>";
								HTMLBODY += "</div>";
							}
						}
					//}//End of If condition to check for Amount > 0
				}//End of For Loop				
				
				//If Upgrade and Payment Due > 0
				if(paySummary.getPaymentDue() != null && paySummary.getPaymentDue().floatValue() > 0){
					HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
						HTMLBODY += "<table style=\"width: 100%; border-collapse: collapse;\">";
							HTMLBODY += "<tr>";
								HTMLBODY += "<td style=\"width: 100%; border: 0pt none; padding: 0pt;\">";									
										HTMLBODY += "<div class=\"BillingLeftDiv1\">";			
											HTMLBODY += "<span class=\"BillingInfoLeft fontBold\">Payment Due</span></span>";
											HTMLBODY += "<span class=\"BillingInfoLeft\">Change requested - balance due and will be paid in person.</span>";
										HTMLBODY += "</div>";
										HTMLBODY += "<div class=\"BillingRightDiv1\">";
											HTMLBODY += "<span class=\"BillingInfoRight\"></span>";												
										HTMLBODY += "</div>";										
								HTMLBODY += "</td>";
							HTMLBODY += "</tr>";
						HTMLBODY += "</table>";
					HTMLBODY += "</div>";
					totalFare = totalFare + Math.abs(paySummary.getPaymentDue().floatValue());
				}//End of Upgrade and Payment Due > 0	

				
				//This is to prepare the Total Heading depending on situation
				if(receiptType.equals(TDDConstants.PURCHASE_SUMMARY) || formOfPayment.size() > 1){
					totalHeading = "Total";
				}else{
					if(paySummary.getPaymentDue() != null && paySummary.getPaymentDue().floatValue() > 0){
						totalHeading = TDDResources.totalDesc;
					}else if(formOfPayment.size() == 1){
						if(formOfPayment.contains(TDDConstants.EVOUCHER)){						
							if(receiptType.equals(TDDConstants.DOWNGRADE_REFUND) || receiptType.equals(TDDConstants.CANCEL_REFUND)){
								totalHeading = TDDResources.totalEvoucherDollarValue;
							}else if(receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE)){
								totalHeading = TDDResources.totalPaid;
							}else{
								totalHeading = TDDResources.totalDesc;
							}
						}else if(formOfPayment.contains(TDDConstants.CREDIT_CARD)){
							if(receiptType.equals(TDDConstants.DOWNGRADE_REFUND) || receiptType.equals(TDDConstants.CANCEL_REFUND)){
								totalHeading = TDDResources.creditCardRefund;
							}else if(receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE)){
								totalHeading = TDDResources.creditCardCharged;
							}else{
								totalHeading = TDDResources.totalDesc;
							}
						}else if(formOfPayment.contains(TDDConstants.CASH)){
							if(receiptType.equals(TDDConstants.DOWNGRADE_REFUND) || receiptType.equals(TDDConstants.CANCEL_REFUND)){
								totalHeading = "Total Refunded";
							}else if(receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE)){
								totalHeading = TDDResources.totalPaid;
							}else{
								totalHeading = TDDResources.totalDesc;
							}
						}
					}else if(formOfPayment.size() > 1 && (receiptType.equals(TDDConstants.CANCEL_REFUND) || receiptType.equals(TDDConstants.DOWNGRADE_REFUND))){
						totalHeading = TDDResources.totalRefunded;
					}else{
						totalHeading = TDDResources.totalDesc;
					}					
				}//End of else	
				
				/**
				 * Block(4): Print the Summary row if needed, summary is needed if the payment is of multiple forms of payment or if
				 * the receiptType is not of type "Purchase" or "Upgrade"
				 **/
				if(!(receiptType.equals(TDDConstants.PURCHASE_SUMMARY) || receiptType.equals(TDDConstants.UPGRADE_NEW_MONEY) || 
												receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE)) || hasMultipleFormsOfPayment){
					HTMLFOOTER += "</div>";
					HTMLFOOTER += "<div class=\"ChangeSummaryContainer\">";
					 	HTMLFOOTER += "<div class=\"ChangeSummaryAlignLeft\">"+totalHeading+"</div>";						
					 	if(paySummary.getPaymentDue() != null && paySummary.getPaymentDue().floatValue() >= 0)
					 		HTMLFOOTER += "<div class=\"ChangeSummaryAlignRight\"><span>" + tddCommonFunctions.getTotalAmountFormat(paySummary.getPaymentDue().floatValue(), isBulkFare) + "</span>";// TDD2 removed </div>
					 	else if(paySummary.getPaidAmt() != null && paySummary.getPaidAmt().floatValue() >= 0)
					 		HTMLFOOTER += "<div class=\"ChangeSummaryAlignRight\"><span>" + tddCommonFunctions.getTotalAmountFormat(paySummary.getPaidAmt().floatValue(), isBulkFare) + "</span>";// TDD2 removed </div>
					 	else if(paySummary.getRefundAmt() != null && paySummary.getRefundAmt().floatValue() >= 0)
					 		HTMLFOOTER += "<div class=\"ChangeSummaryAlignRight\"><span>" + tddCommonFunctions.getTotalAmountFormat(paySummary.getRefundAmt().floatValue(), isBulkFare) + "</span>";// TDD2 removed </div>
					HTMLFOOTER += "</div>";
					HTMLFOOTER += "</div>";
			
				}else{
					HTMLFOOTER += "</div>";
				}
				
			if(HTMLBODY !=null && !HTMLBODY.isEmpty()){
				HTML+= HTMLHEADER + HTMLBODY +   HTMLFOOTER + "</div>";
			}			
		}
		LOG.debug(this.getClass().getName(),"exiting prepareBillingHeading(formatSendPsgrNotificationRQ,receiptType)");	
	}
	

	/*
	 * This takes care of a corner case we have today with Exchange receipts. TDD
	 * processes only Exchange receipts which have the comment as "Exchange Paper Tickets"
	 * and for other cases (case "Exchange") the processing is ignored. When we have more than one
	 * forms of payment - for example credit and exchange receipts, and we have the above described case.
	 * 
	 * The payment is considered to be a single payment scenario (due to the bug above)
	 *  and total summary row is displayed. 
	 *  This should not be done to maintain consistency with existing layout.
	 *  
	 */

	private boolean isPaymentOfMultipleForms(List<Payment3> payment2List) {
		/* Hack since this needs to be removed when we decide how to deal
		 * with tickets that have the value "Exchange" sent instead of "Exchange paper tickets"
	    */
		for (Iterator paymt2Itr = payment2List.iterator(); paymt2Itr.hasNext(); )  {
			Payment3 paymt2 = (Payment3) paymt2Itr.next();
			FormOfPayment3 formOfPayment2 =(new ObjectFactory()).createFormOfPayment3();
			formOfPayment2 = paymt2.getFormOfPayment();
			// This is a corner case 
			if(formOfPayment2.getExchange() != null && 
					"Exchange".equals(formOfPayment2.getExchange().getRemarks().getRemark().get(0).getText())){
				//If it is an exchange and size is more than one then
				return !(payment2List.size() > 0);		
			}
		}
		
		//If it is not of exchange type check the payment size to determine if
		//it is of multiple forms.
		return payment2List.size() > 1;
	}
	
	/*
	 * TDD2 requirement to have the listing of the Total text to be displayed next
	 * to the dollar value for receipts of type Purchase and Upgrade types.
	 * 
	 * The below method checks for this condition and returns true if it matches.
	 *  
	 */

	private boolean isPurchaseOrUpgradeType(){
		return (receiptType.equals(TDDConstants.PURCHASE_SUMMARY) || receiptType.equals(TDDConstants.UPGRADE_NEW_MONEY) 
																  || receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE));
	}
	
	/*
	 * Historically this method was placed to align the total text if repeated
	 * across multiple rows. The fix was to place this in a seperate column
	 * in table with fixed layout.
	 * 
	 * The requirement change in Multiride release wanted the <code>Total</code>
	 * text to be removed and displayed only once.
	 * 
	 * As a fallback, the old code has been replaced since placing it in a new
	 * column is no longer required. 
	 */
	
	private String formatHTMLForTotalText(String prefix, String value){
		String htmlText = "<span class=\"BillingInfoRight\">" + "Total" + "    " + value +"</span>";
		return htmlText;		
	}
	
	
	String formatHTMLTableForPurchaseOrUpgrade(String receiptType){
		String tableFormat = "";
		if(receiptType.equals(TDDConstants.PURCHASE_SUMMARY) || receiptType.equals(TDDConstants.UPGRADE_NEW_MONEY)
															 || receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE)){
			tableFormat = "<table style=\"table-layout:fixed;width:610px;border-collapse:collapse\">";
		}else{
			tableFormat = "<table style=\"width: 100%; border-collapse: collapse;\">";
		}
		
		return tableFormat;
	}
	
	/*
	 * Historically this method was placed to align the total text if repeated
	 * across multiple rows. The fix was to put the <code>Total</code> text and
	 * <code>Value</code> in two seperate columns with fixed spacing.
	 * 
	 * The requirement change in Multiride release wanted the <code>Total</code>
	 * text  and <code>value</code> to be removed and displayed only once.
	 * 
	 * As a fallback, the old code has been replaced since placing it in a new
	 * column is no longer required. 
	 */
	
	String formatHTMLTableRowForPurchaseOrUpgrade(String receiptType){
		String tableFormat = "<td style=\"width: 100%; border: 0pt none; padding: 0pt;\">";
		
		return tableFormat;
	}
	

	/**
	 * Method to add the EVoucher Heading to the HTML string
	 * @param formatSendPsgrNotificationRQ
	 * @param receiptType
	 */
	private void prepareEVouchersHeading(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){

		LOG.debug(this.getClass().getName(),"entering prepareEVouchersHeading(formatSendPsgrNotificationRQ,receiptType)");	

		String totalHeading = TDDResources.totalEvoucherDollarValue;
		
		String HTMLHEADER = "";
		String HTMLBODY = "";
		String HTMLFOOTER = "";
		
			HTMLHEADER += "<div>";
			HTMLHEADER += "<span class=\"BillingHeading\">eVouchers Created</span>";
			HTMLHEADER += "</div>";
			HTMLHEADER += "<div class=\"BillingInfoBox\">";
				HTMLHEADER += "<div class=\"BillingMainBox\">";
				
				String billingBackGrdColor = "";
				
				if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getEVouchers() != null){
					eVouchers = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getEVouchers();
					List<EVoucherInfo2> eVoucherList = eVouchers.getEVoucher();
					for (Iterator<EVoucherInfo2> eVoucListItr = eVoucherList.iterator(); eVoucListItr.hasNext(); )  {
						EVoucherInfo2 eVoucherInfo2 = (EVoucherInfo2) eVoucListItr.next();
						
						if(eVoucherInfo2.getEVoucherIssuedToName() != null){
							HTMLBODY += "<div>";
							HTMLBODY += "<span class=\"HorizontalRule\"><hr style=\"clear:left;float:left;width:100%;height:1px;border:0;margin:0!important;margin:0 0 -14px 0;padding:0;color:#B0B0B0;background-color:#BFBFBF;top:0;\" /></span>";
							HTMLBODY += "<span class=\"BillingBodyBox\">";
								HTMLBODY += "<span class=\"BillDispBlock\">"+eVoucherInfo2.getEVoucherIssuedToName()+"</span>";							
							HTMLBODY += "</span>";
							HTMLBODY += "<span class=\"HorizontalRule\"><hr style=\"clear:left;float:left;width:100%;height:1px;border:0;margin:0!important;margin:0 0 -14px 0;padding:0;color:##666666;background-color:#BFBFBF;top:0;\" /></span>";						
							HTMLBODY += "</div>";
						}
						
						try{
							HTMLBODY += "<div class=\""+billingBackGrdColor+"\">";
								HTMLBODY += "<table style=\"width: 100%; border-collapse: collapse;\">";
									HTMLBODY += "<tr>";
										HTMLBODY += "<td style=\"width: 100%; border: 0pt none; padding: 0pt;\">";		
												HTMLBODY += "<div class=\"BillingLeftDiv1\">";
													HTMLBODY += "<span class=\"BillingInfoLeft\" style=\"font-weight:bold;\">eVoucher "+eVoucherInfo2.getEVoucherNbr()+"</span>";
													
													HTMLBODY += "<span class=\"BillingInfoLeft\">Issued "+TDDDateUtils.convertDateToMMddyy(eVoucherInfo2.getEVoucherIssueDt());
													if(eVoucherInfo2.getEVoucherRefAmt() != null )
														HTMLBODY +="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Refundable Amount:"+tddCommonFunctions.getTotalAmountFormat(Math.abs(eVoucherInfo2.getEVoucherRefAmt().floatValue()), isBulkFare)+"</span>";
													else
														HTMLBODY +="</span>";
													
													HTMLBODY += "<span class=\"BillingInfoLeft\">Expires "+TDDDateUtils.convertDateToMMddyy(eVoucherInfo2.getEVoucherExpDt());
													if(eVoucherInfo2.getEVoucherRefExpDt() != null )
														HTMLBODY +="&nbsp;&nbsp;&nbsp;&nbsp;Expires:"+ TDDDateUtils.convertDateToMMddyy(eVoucherInfo2.getEVoucherRefExpDt())+"</span>";
													else
														HTMLBODY +="</span>";
												HTMLBODY += "</div>";
												HTMLBODY += "<div class=\"BillingRightDiv1\">";
													HTMLBODY += "<span class=\"BillingInfoRight\">"+tddCommonFunctions.getTotalAmountFormat(Math.abs(eVoucherInfo2.getEVoucherAmt().floatValue()), isBulkFare)+"</span>";
												HTMLBODY += "</div>";									
										HTMLBODY += "</td>";
									HTMLBODY += "</tr>";
								HTMLBODY += "</table>";
							HTMLBODY += "</div>";
							eVoucherTotalFare = eVoucherTotalFare + Math.abs(eVoucherInfo2.getEVoucherAmt().floatValue());
						}catch(Exception e){
				       		LOG.error("Exception : Error occured during prepareEVouchersHeading processing.", e);
						}
					}
				}//End of Evoucher If condition	
	
					HTMLFOOTER += "</div>";
					HTMLFOOTER += "<div class=\"ChangeSummaryContainer\">";
					HTMLFOOTER += "<div class=\"ChangeSummaryAlignLeft\">"+totalHeading+"</div>";						
					HTMLFOOTER += "<div class=\"ChangeSummaryAlignRight\"><span>" + tddCommonFunctions.getTotalAmountFormat(eVoucherTotalFare, isBulkFare) + "</span></div>";	
					HTMLFOOTER += "</div>";
			
			if(HTMLBODY !=null && !HTMLBODY.isEmpty()){
				HTML+= HTMLHEADER+HTMLBODY+HTMLFOOTER + "</div>";
			}
			LOG.debug(this.getClass().getName(),"exiting prepareEVouchersHeading");	
	}
	
	/**
	 * Method to add the Purchase/Change Summary Header to the HTML string
	 * @param formatSendPsgrNotificationRQ
	 * @param receiptType
	 */
	private void preparePurchaseOrChangeSummaryHeading(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ, String receiptType){

		LOG.debug(this.getClass().getName(),"entering preparePurchaseOrChangeSummaryHeading(formatSendPsgrNotificationRQ,receiptType)");	

		//TDD2
		String ticketNumber = this.getFirstTicketNumber(formatSendPsgrNotificationRQ);
		boolean skipTicketNumber = "".equals(ticketNumber)? true: false;
		String ticketNumberContent = SPACE + TDDSystemConfiguration.getStringProperty("summarySectionDetails.ticketNumber") + SPACE + ticketNumber;

		HTML += "<div><span class=\"ChangeSummaryHeading\">";
		if(receiptType.equals(TDDConstants.PURCHASE_SUMMARY)){
			HTML += TDDSystemConfiguration.getStringProperty("summarySectionDetails.purchaseSummary");
	    }else{
			HTML += TDDSystemConfiguration.getStringProperty("summarySectionDetails.changeSummary");
	    }	
		
		HTML += skipTicketNumber?"":ticketNumberContent + "</span></div>";		

		LOG.debug(this.getClass().getName(),"exiting preparePurchaseOrChangeSummaryHeading(formatSendPsgrNotificationRQ,receiptType)");	

	}
	
	/**
	 * Method to add the Purchase/Change Summary Details to the HTML string
	 * @param formatSendPsgrNotificationRQ
	 * @param receiptType
	 * @throws ParseException
	 */
	private void preparePurchaseOrChangeSummaryDetails(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ, String receiptType) throws ParseException {

		LOG.debug(this.getClass().getName(),"entering preparePurchaseOrChangeSummaryDetails(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ, String receiptType)");	

		String totalHeading = "Total";

		float orgAmountPaid = 0;
		float unLiftedTktAMt = 0;
		float grandTotal = 0;
		Payments3 payments2 = (new ObjectFactory()).createPayments3();
		PaymentSummary2 paySummary = (new ObjectFactory()).createPaymentSummary2();
		if(paymentInfo2 !=null && paymentInfo2.getPayments() != null){
			payments2 = paymentInfo2.getPayments();
			paySummary = payments2.getPaymentSummary();
		}
		int noOfSegments = 0;
		
		HTML += "<div class=\"ChangeSummaryBox\">";
		HTML += "<div class=\"ChangeSummaryMainBox\">";
		
		// If this is NOT a PURCHASE_SUMMARY receipt
		if(!receiptType.equals(TDDConstants.PURCHASE_SUMMARY)){
			//Unlifted Ticket Amount is Original AMount Paid
			if(paySummary.getUnliftedTktAmt() != null || paySummary.getLiftedTktAmt() != null){
				//Display Original Amount Paid
				if(paySummary.getUnliftedTktAmt() != null && paySummary.getLiftedTktAmt() != null)
					orgAmountPaid = Math.abs(paySummary.getLiftedTktAmt().floatValue()) + Math.abs(paySummary.getUnliftedTktAmt().floatValue());
				else if(paySummary.getUnliftedTktAmt() != null && paySummary.getLiftedTktAmt() == null)
					orgAmountPaid = Math.abs(paySummary.getUnliftedTktAmt().floatValue());
				else if(paySummary.getUnliftedTktAmt() == null && paySummary.getLiftedTktAmt() != null)
					orgAmountPaid = Math.abs(paySummary.getLiftedTktAmt().floatValue());
				HTML += "<div class=\"ChangeSummaryPenaltiesContainer\">";
					HTML += "<div class=\"ChangeSummaryPenaltiesLeft\" style=\"font-weight:bold;\">";
						HTML += "Original Amount Paid";
					HTML += "</div>";
					HTML += "<div class=\"ChangeSummaryPenaltiesRight\">";
						HTML += tddCommonFunctions.getTotalAmountFormat(orgAmountPaid, isBulkFare);
					HTML += "</div>";
				HTML += "</div>";
				HTML += "<span class=\"HorizontalRule\"><hr style=\"clear:left;float:left;width:100%;height:1px;border:0;margin:0!important;margin:0 0 -14px 0;padding:0;color:##666666;background-color:#BFBFBF;top:0;\" /></span>";
				if(paySummary.getUnliftedTktAmt() != null )
					unLiftedTktAMt = paySummary.getUnliftedTktAmt().floatValue();
			}
			
			if(paySummary.getLiftedTktAmt() != null && paySummary.getLiftedTktAmt().floatValue() > 0){
				HTML += "<div class=\"ChangeSummaryPenaltiesContainer\">";
					HTML += "<div class=\"ChangeSummaryPenaltiesLeft\">";
						HTML += "Travel Amount Used";
					HTML += "</div>";
					HTML += "<div class=\"ChangeSummaryPenaltiesRight\">";
						HTML += "("+tddCommonFunctions.getTotalAmountFormat(paySummary.getLiftedTktAmt().floatValue(), isBulkFare)+")";
					HTML += "</div>";
				HTML += "</div>";
			
				HTML += "<div class=\"ChangeSummarySubTotalContainer\">";
					HTML += "<div class=\"ChangeSummarySubTotalAlignLeft\">";
						HTML += "Subtotal";
					HTML += "</div>";
					HTML += "<div class=\"ChangeSummarySubTotalAlignRight\"><span>";
						if(paySummary.getUnliftedTktAmt() != null)
								HTML += tddCommonFunctions.getTotalAmountFormat(paySummary.getUnliftedTktAmt().floatValue(), isBulkFare);
						else
								HTML += "$0.00";
					HTML += "</span></div>";
				HTML += "</div>";
				HTML += "<span class=\"HorizontalRule\"><hr style=\"clear:left;float:left;width:100%;height:1px;border:0;margin:0!important;margin:0 0 -14px 0;padding:0;color:##666666;background-color:#BFBFBF;top:0;\" /></span>";
			}
			
			boolean NonRefundOrForfeitAmtPresent = false;
			if(paySummary.getNonRefundableDeliveryFee() != null && paySummary.getNonRefundableDeliveryFee().floatValue() > 0){
				displayFees("Ticket Delivery Fee", paySummary.getNonRefundableDeliveryFee().floatValue());
				grandTotal = grandTotal - Math.abs(paySummary.getNonRefundableDeliveryFee().floatValue());
				NonRefundOrForfeitAmtPresent = true;
			}
			if(paySummary.getForfeitAmt() != null && paySummary.getForfeitAmt().floatValue() > 0){
				displayFees("Cancellation Penalty", paySummary.getForfeitAmt().floatValue());
				grandTotal = grandTotal - Math.abs(paySummary.getForfeitAmt().floatValue());
				NonRefundOrForfeitAmtPresent = true;
			}
			if(NonRefundOrForfeitAmtPresent){
				if(paySummary.getAvailableTktAmt() != null){
					HTML += "<div class=\"ChangeSummarySubTotalContainer\">";
						HTML += "<div class=\"ChangeSummarySubTotalAlignLeft\">";
							HTML += "Subtotal";
						HTML += "</div>";
						HTML += "<div class=\"ChangeSummarySubTotalAlignRight\"><span>";
							HTML += tddCommonFunctions.getTotalAmountFormat(paySummary.getAvailableTktAmt().floatValue(), isBulkFare);
						HTML += "</span></div>";
					HTML += "</div>";
				}
			}
			HTML += "<span class=\"HorizontalRule\"><hr style=\"clear:left;float:left;width:100%;height:1px;border:0;margin:0!important;margin:0 0 -14px 0;padding:0;color:##666666;background-color:#BFBFBF;top:0;\" /></span>";
		}
		
		//If PaymentDue is >0 then do not show any information with respect to segments. Show only PaymentSummary Details.
		if(paySummary.getPaymentDue() == null || paySummary.getPaymentDue().floatValue() < 0){
			if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary() !=null ){
				LOG.debug(this.getClass().getName(),"receiptType *************** "+receiptType);	
				if(receiptType.equals(TDDConstants.DOWNGRADE_REFUND) || receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE) || receiptType.equals(TDDConstants.UPGRADE_NEW_MONEY)){				
					HTML += "<span class=\"ChangeSummaryTripDetails\">"+TDDResources.revisedTripDetails+"</span>";
				}else if(receiptType.equals(TDDConstants.CANCEL_REFUND)){
					HTML += "<span class=\"ChangeSummaryTripDetails\">"+TDDResources.cancelledTripDetails+"</span>";
				}
				
				//Format RQ
		    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();    	
		    	List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
				String trainNumber = null;
				String orgTrainCity = null;
				String desTrainCity = null;
				String trainDate = null;

				List<Integer> segNumberList = new ArrayList<Integer>();
				for (Iterator<LogicalTrip> j = logicalTripListRQ.iterator(); j.hasNext(); )  { 					
					Map rbdMap = new HashMap();
					Map rbdPriceMap = new HashMap();
					List<String> rbdArryList = new ArrayList();
					boolean expDelFeeFlg = false;
					boolean serviceFeeFlg = false;
					List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment> segmentsList  = ((FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip)j.next()).getSegments().getSegment();
					for (Iterator i = segmentsList.iterator(); i.hasNext(); )  {        			
						++noOfSegments;
						Segment segment = new Segment();
		    			segment = (Segment) i.next();	
		    			if(segment.getTickets() != null){
		    			List<Ticket> ticketList = segment.getTickets().getTicket();	
		    				for (Iterator itr = ticketList.iterator(); itr.hasNext(); )  {        			
		    		    		Ticket ticket = new Ticket();
		    		    		ticket = (Ticket) itr.next(); 		    		    		
		    		    		if(ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null &&
		    		    				ticket.getPricingItem().getFarePlans().getFarePlan().get(0) != null) {
		    		    			if(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().equalsIgnoreCase(TDDConstants.EXPRESS_DELIVERY_FEE)){
			    		    			//Store Express Delivery Fee Amount
			    		    			expressDeliveryFee = ticket.getPricingItem().getTariff().getRailFare().floatValue();
			    		    			expDelFeeFlg = true;		  
		    		    			}else if(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().substring(0, 3).equalsIgnoreCase(TDDConstants.SERVICE_FEE)){			    		    					
			    		    			//Store Service Fee Amount
			    		    			serviceFeeFlg = true;		  
		    		    			}
		    		    		}
		    				}
		    			}
		    			//In case of BUS or other transport RouteName might be NULL
		    			if(!expDelFeeFlg && !serviceFeeFlg){
	    					if(segment.getTrainDetails().getRouteName() == null || !"SELF TRANSFER".equals(segment.getTrainDetails().getRouteName())){	
	    						//TDD3 - depDateTime and train number details can be null if this is of type multiride, even though the below method 
	    						//convertDateToMMddyyyy takes care
	    						//of null inputs the code below is listed to make this behavior explicit.
	    						XMLGregorianCalendar depDateTime = (!this.multiRideType.isValid())? segment.getDepartureDateTime(): null;
	    						String trainNumberDetailsStr = (!this.multiRideType.isValid())?segment.getTrainDetails().getTrainNumber().toString():"";					
		    					if(trainNumber != null && trainNumberDetailsStr.equals(trainNumber)
				    					 && segment.getOrigin().getName().equalsIgnoreCase(orgTrainCity) &&
				    					 segment.getDestination().getName().equalsIgnoreCase(desTrainCity) &&
				    					TDDDateUtils.convertDateToMMM_dd_yyyy(depDateTime).equals(trainDate)){
				    				//Duplicate segment - Do nothing
				    				rbdDescriptionForReceipts(segment, rbdMap, rbdPriceMap, rbdArryList, formatSendPsgrNotificationRQ);
				    				segNumberList.add(segment.getSegmentNumber().intValue());
				    		}else{	
				    				if(rbdMap.size() > 0 || psgrToBeDisplayedForEndorsements.size() > 0){
				    					float subtotal = 0;
										for (Iterator<String> rbdDesc = rbdArryList.iterator(); rbdDesc.hasNext(); )  {  
											String desc = (String) rbdDesc.next();
											String individualFare = tddCommonFunctions.getTotalAmountFormat(Float.valueOf(rbdPriceMap.get(desc).toString()), isBulkFare);
											subtotal = subtotal + Math.abs(Float.valueOf(rbdPriceMap.get(desc).toString()));
											HTML += "<div class=\"BillingContainer\">";
											HTML += "<div class=\"BillingLeftDiv1\">";
												if(((Long)(rbdMap.get(desc))).longValue() > 1)
													HTML += "<span class=\"ChangeSummaryLeft\">"+rbdMap.get(desc)+" " +desc+"S</span>";
												else
													HTML += "<span class=\"ChangeSummaryLeft\">"+rbdMap.get(desc)+" " +desc+"</span>";
											HTML += "</div>";
											HTML += "<div class=\"BillingRightDiv1\">";
												HTML += "<span class=\"ChangeSummaryRight\">"+individualFare+"</span>";
											HTML += "</div>";
											HTML += "</div>";								
											
											rbdMap.remove(desc);
											rbdPriceMap.remove(desc);
										}
										if(psgrToBeDisplayedForEndorsements.size() > 0){
											//Display Passenger Endorsements
											displaySegmentEndorsements(formatSendPsgrNotificationRQ, segNumberList);
											psgrToBeDisplayedForEndorsements.clear();
											segNumberList.clear();
										}
										HTML += "<div class=\"ChangeSummarySubTotalContainer\">";
											HTML += "<div class=\"ChangeSummarySubTotalAlignLeft\">";
												HTML += "Subtotal";
											HTML += "</div>";
											HTML += "<div class=\"ChangeSummarySubTotalAlignRight\">";
												HTML += tddCommonFunctions.getTotalAmountFormat(subtotal, isBulkFare);									
											HTML += "</div>";
										HTML += "</div>";
										grandTotal = grandTotal + subtotal;
				    					rbdMap.clear();
				    					rbdPriceMap.clear();
				    					rbdArryList.clear();
				    				}
				    				//TDD3: For multiride the train number and date will be empty
				    				trainNumber = (!this.multiRideType.isValid())?segment.getTrainDetails().getTrainNumber().toString(): "";
				    				trainDate = (!this.multiRideType.isValid())?TDDDateUtils.convertDateToMMM_dd_yyyy(segment.getDepartureDateTime()): "";
				    				
				    				if(segment.getOrigin() != null && segment.getOrigin().getName() != null){
				    						orgTrainCity = segment.getOrigin().getName().toUpperCase();		    				
			    					}else{
			    						orgTrainCity = null;
			    					}
			    					if(segment.getDestination() != null && segment.getDestination().getName() != null){
			    						desTrainCity = segment.getDestination().getName().toUpperCase();			    			
			    					}else{
			    						desTrainCity = null;
				    				}
				    				String orgCity = null;
				    				String desCity = null;
				    				if(orgTrainCity != null){
				    					int commaIndex = orgTrainCity.indexOf(",");
				    					if(commaIndex != -1){
				    						orgCity = orgTrainCity.substring(0,commaIndex);
				    					}else{
				    						orgCity = orgTrainCity;
				    					}
				    					if(segment.getOrigin().getAddress() != null && segment.getOrigin().getAddress().getState() != null){
				    						orgCity = orgCity +", "+segment.getOrigin().getAddress().getState();
				    					}
				    				}
				    				
				    				if(desTrainCity != null){
				    					int commaIndex = desTrainCity.indexOf(",");
				    					if(commaIndex != -1){
				    						desCity = desTrainCity.substring(0,commaIndex);
				    					}else{
				    						desCity = desTrainCity;
				    					}
				    					if(segment.getDestination().getAddress() != null && segment.getDestination().getAddress().getState() != null){
				    						desCity = desCity +", "+segment.getDestination().getAddress().getState();
				    					}
				    				}
				    				
				    				//TDD3
				    				if(!this.multiRideType.isValid()){
				    					HTML += "<span class=\"ChangeSummaryTrainInfo\">Train "+trainNumber+": "+ orgCity +" - "+ desCity+"</span>";
					    				HTML += "<span class=\"ChangeSummaryDepart\">Depart "+TDDDateUtils.getDateTimeForReceipts(segment.getDepartureDateTime())+"</span>";
				    				}else{//For Multiride type
				    					HTML += "<span class=\"ChangeSummaryTrainInfo\">"+ orgCity + " - " + desCity + "</span>";
				    					HTML += "<span class=\"ChangeSummaryDepart\">Valid Travel Period:"+ " " + this.multiRideType.getDateHeaderText()+"</span>";
				    				}
				    				
				    				
				    				rbdDescriptionForReceipts(segment, rbdMap, rbdPriceMap, rbdArryList, formatSendPsgrNotificationRQ);	
				    				segNumberList.add(segment.getSegmentNumber().intValue());
				    			}
		    				}
		    			}
					}//End of Segment Iterator					
					
					if(rbdMap.size() > 0 || psgrToBeDisplayedForEndorsements.size() > 0){
						float subtotal = 0;
						
						for (Iterator rbdDesc = rbdArryList.iterator(); rbdDesc.hasNext(); )  {  
							String desc = (String) rbdDesc.next();
							subtotal = subtotal + Math.abs(Float.valueOf(rbdPriceMap.get(desc).toString()));
							String individualFare = tddCommonFunctions.getTotalAmountFormat(Float.valueOf(rbdPriceMap.get(desc).toString()), isBulkFare);
							HTML += "<div class=\"BillingContainer\">";
							HTML += "<div class=\"BillingLeftDiv1\">";
							String purchaseTxt = "";
							
								if(this.multiRideType.isValid()){
									//For Even exchange, upgrade and downgrade exchange use static text for accomodation details
									if(receiptType.equals(TDDConstants.EVEN_EXCHANGE) || receiptType.equals(TDDConstants.DOWNGRADE_REFUND) 
																						|| receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE)
																						|| receiptType.equals(TDDConstants.UPGRADE_NEW_MONEY)){
										purchaseTxt = "1 UNRESERVED COACH SEAT";
									}else{
										if(this.multiRideType.isMonthly()){
											purchaseTxt = "1 MONTHLY TICKET";
										}else{
											purchaseTxt = "1" + " " + this.multiRideType.getRideTypeTextHTML().toUpperCase();
										}
									}
								
									HTML += "<span class=\"ChangeSummaryLeft\">" + purchaseTxt + "</span>";
								}else{
									if(((Long)(rbdMap.get(desc))).longValue() > 1)
										HTML += "<span class=\"ChangeSummaryLeft\">"+rbdMap.get(desc)+" " +desc+"S</span>";
									else
										HTML += "<span class=\"ChangeSummaryLeft\">"+rbdMap.get(desc)+" " +desc+"</span>";
							
								}
							HTML += "</div>";
							HTML += "<div class=\"BillingRightDiv1\">";
								HTML += "<span class=\"ChangeSummaryRight\">"+individualFare+"</span>";
							HTML += "</div>";
							HTML += "</div>";
							
							rbdMap.remove(desc);
							rbdPriceMap.remove(desc);
						}
						if(psgrToBeDisplayedForEndorsements.size() > 0){
							//Display Passenger Endorsements
							displaySegmentEndorsements(formatSendPsgrNotificationRQ, segNumberList);
							psgrToBeDisplayedForEndorsements.clear();
							segNumberList.clear();
						}
						HTML += "<div class=\"ChangeSummarySubTotalContainer\">";
							HTML += "<div class=\"ChangeSummarySubTotalAlignLeft\">";
								HTML += "Subtotal";
							HTML += "</div>";
							HTML += "<div class=\"ChangeSummarySubTotalAlignRight\"><span>";
								HTML += tddCommonFunctions.getTotalAmountFormat(subtotal, isBulkFare);
							HTML += "</span></div>";
						HTML += "</div>";
						
						grandTotal = grandTotal + subtotal;
						rbdMap.clear();
						rbdPriceMap.clear();
						rbdArryList.clear();
					}
			     }//End of LogicalTrip Iterator
			}
			
			//Reservation Canceled
			if(noOfSegments == 0 && reservationCanceled){
				HTML += "<div class=\"BillingContainerInnerDivColor\">";
				HTML += "<table style=\"width: 100%; border-collapse: collapse;\">";
					HTML += "<tr>";
							HTML += "<td style=\"width: 100%; border: 0pt none; padding: 0pt;\">";	
								HTML += "<div class=\"BillingLeftDiv1\">";							
									HTML += "<span class=\"BillingInfoLeft\">Reservation Canceled</span>";
								HTML += "</div>";
								HTML += "<div class=\"BillingRightDiv1\">";
									HTML += "<span class=\"BillingInfoRight\"></span>";
								HTML += "</div>";									
							HTML += "</td>";
						HTML += "</tr>";
					HTML += "</table>";
				HTML += "</div>";
			}
		}//End of checking PaymentDue.
	
		//Show Penalties or Refunds in case of ChangeSummary
		if(!receiptType.equals(TDDConstants.PURCHASE_SUMMARY)){
			
			//Show Positive Express Delivery Fee. If Express Delivery Fee,Show like subtotal.
			expressDeliveryFee();
			
			if(paySummary.getNewTktAmt() != null && paySummary.getNewTktAmt().floatValue() > 0){
				HTML += "<div class=\"ChangeSummarySubTotalContainer\">";
					HTML += "<div class=\"ChangeSummarySubTotalAlignLeft\">";
						HTML += "Revised Fare";
					HTML += "</div>";
					HTML += "<div class=\"ChangeSummarySubTotalAlignRight\"><span>";
						//At this point of time, grandTotal should be equal to Revised Fare
						HTML += tddCommonFunctions.getTotalAmountFormat(paySummary.getNewTktAmt().floatValue(), isBulkFare);
					HTML += "</span></div>";
				HTML += "</div>";
			}
			if(unLiftedTktAMt > 0)
			{
				grandTotal = unLiftedTktAMt - grandTotal;
			}
			//Show Evoucher Amount			
			if(eVoucherTotalFare > 0 && receiptType.equals(TDDConstants.CANCEL_REFUND)){
				displayFees("eVoucher", eVoucherTotalFare);				
				totalHeading = TDDResources.totalRefunded;
				totalRefundedFlg = true;
			}else if(formOfPayment.contains(TDDConstants.EVOUCHER) && eVoucherTotalFare > 0 && 
					(receiptType.equals(TDDConstants.UPGRADE_NEW_MONEY) || receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE))){
				//Do not show Evoucher on Upgrade Exchange
			}
			else if(paySummary.getNewTktAmt() != null && paySummary.getNewTktAmt().floatValue() > 0 && 
					((paySummary.getRefundAmt() != null && paySummary.getRefundAmt().floatValue() > 0) || 
							(paySummary.getEVoucherAmt() != null && paySummary.getEVoucherAmt().floatValue() > 0))){
				//New ticket amount > 0 && either refundamt > 0 or evoucher amount > 0
				if(eVoucherTotalFare > 0){
					displayFees("eVoucher", eVoucherTotalFare);
				}
				totalHeading = TDDResources.totalRefunded;
				totalRefundedFlg = true;
			}				
			
			if(paySummary.getRefundFee() != null && paySummary.getRefundFee().floatValue() > 0){
				displayFees("Refund Fee", paySummary.getRefundFee().floatValue());
				grandTotal = grandTotal - Math.abs(paySummary.getRefundFee().floatValue());
			}
		}//End of Change Summary Penalties
		else{
			//Show Positive Express Delivery Fee. If Express Delivery Fee,Show like subtotal.
			expressDeliveryFee();	
			
			if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getFees() != null && formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getFees().getFee() != null
	   				 && formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getFees().getFee().size() > 0) {
				com.amtrak.mulesoft.schema._2016._03._07.Fee2 fee = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getFees().getFee().get(0);
	   		   		serviceFee = fee.getAmount().floatValue();
			}
			//Show service Fee If exists
			showServiceFee();
		}
		
		//This is to prepare the Total Heading depending on situation
		if(receiptType.equals(TDDConstants.PURCHASE_SUMMARY)){
			totalHeading = TDDResources.purchaseSummary;
		}else{
			if(paySummary.getPaymentDue() != null && paySummary.getPaymentDue().floatValue() > 0){
				totalHeading = TDDResources.payInPerson;
			}else if(formOfPayment.size() == 1){
				if(formOfPayment.contains(TDDConstants.EVOUCHER)){						
					if(receiptType.equals(TDDConstants.DOWNGRADE_REFUND) || receiptType.equals(TDDConstants.CANCEL_REFUND)){
						totalHeading = "Total refunded to eVoucher";
					}else if(receiptType.equals(TDDConstants.UPGRADE_NEW_MONEY)){
						totalHeading = "Total paid by eVoucher";
					}else if(receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE)){						
						totalHeading = TDDResources.totalPaid;
					}else{
						totalHeading = TDDResources.totalDesc;
					}
				}else if(formOfPayment.contains(TDDConstants.CREDIT_CARD)){
					if(receiptType.equals(TDDConstants.DOWNGRADE_REFUND) || receiptType.equals(TDDConstants.CANCEL_REFUND)){
						totalHeading = TDDResources.creditCardRefund;
					}else if(receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE)){
						totalHeading = TDDResources.creditCardCharged;
					}else{
						totalHeading = TDDResources.totalDesc;
					}
				}else if(formOfPayment.contains(TDDConstants.CASH)){
					if(receiptType.equals(TDDConstants.DOWNGRADE_REFUND) || receiptType.equals(TDDConstants.CANCEL_REFUND)){
						totalHeading = "Total Refunded";
					}else if(receiptType.equals(TDDConstants.UPGRADE_AMOUNT_DUE)){
						totalHeading = TDDResources.totalPaid;
					}else{
						totalHeading = TDDResources.totalDesc;
					}
				}
			}else if(formOfPayment.size() > 1 && (receiptType.equals(TDDConstants.CANCEL_REFUND) || receiptType.equals(TDDConstants.DOWNGRADE_REFUND))){
				totalHeading = TDDResources.totalRefunded;
			}else{
				totalHeading = TDDResources.totalDesc;
			}
		}//End of else			
		
		//For Even Exchange Grand Total Should always be zero
		if(receiptType.equals(TDDConstants.EVEN_EXCHANGE)){
			grandTotal = 0;
			if(!totalRefundedFlg){
				totalHeading = TDDResources.totalCharged;
			}else{
				totalHeading = TDDResources.totalRefunded;
			}
		}else{				
			if(paySummary.getPaymentDue() != null && paySummary.getPaymentDue().floatValue() >= 0)
				grandTotal = paySummary.getPaymentDue().floatValue();
		 	else if(paySummary.getPaidAmt() != null && paySummary.getPaidAmt().floatValue() >= 0)
				grandTotal = paySummary.getPaidAmt().floatValue();
		 	else if(paySummary.getRefundAmt() != null && paySummary.getRefundAmt().floatValue() >= 0)
		 		grandTotal = paySummary.getRefundAmt().floatValue();
		}
		HTML += "<div class=\"ChangeSummaryContainer\">";
			HTML += "<div class=\"ChangeSummaryAlignLeft\">";
				HTML += totalHeading;
			HTML += "</div>";
			HTML += "<div class=\"ChangeSummaryAlignRight\"><span>";
				HTML += tddCommonFunctions.getTotalAmountFormat(grandTotal, isBulkFare); 
			HTML += "</span></div>";
		HTML += "</div>";
		HTML += "<div>";
		//TDD2 HTML four div's for alignment
		HTML += "</div></div></div>";

		LOG.debug(this.getClass().getName(),"exiting preparePurchaseOrChangeSummaryDetails(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ, String receiptType)");	

	}
	/**
	 * Method to set the Billing Background color
	 * @param i
	 * @return String
	 */
	private String prepareIBillingBackgroundColor(int i){
		LOG.debug(this.getClass().getName(),"entering prepareIBillingBackgroundColor(i)");	

		String billingBackGrdColor = "";
		if(i%2 == 1){
			billingBackGrdColor = "BillingContainerInnerDivColor";
		}else{
			billingBackGrdColor = "BillingContainerInnerDiv";
		}

		LOG.debug(this.getClass().getName(),"exiting prepareIBillingBackgroundColor(i)");	

		return billingBackGrdColor;
	}
	
	/**
	 * Method to add the Fees to the HTML string
	 * @param name
	 * @param price
	 */
	private void displayFees(String name, Float price){	
		LOG.debug(this.getClass().getName(),"entering displayFees(name, price)");	
		LOG.debug(this.getClass().getName(),"displayFees(name, price)" + name + " : " + price.toString());	

		HTML += "<div class=\"ChangeSummaryPenaltiesContainer\">";
			HTML += "<div class=\"ChangeSummaryPenaltiesLeft\">";
				HTML += name;
			HTML += "</div>";
			HTML += "<div class=\"ChangeSummaryPenaltiesRight\">";
				HTML += "("+tddCommonFunctions.getTotalAmountFormat(price, isBulkFare)+")";
			HTML += "</div>";
		HTML += "</div>";

		LOG.debug(this.getClass().getName(),"exiting displayFees(name, price)");	

	}	
	
	/**
	 * Method to prepare the RDB Description fields
	 * @param segment
	 * @param rbdMap
	 * @param rbdPriceMap
	 * @param rbdArryList
	 * @param formatSendPsgrNotificationRQ
	 */
	private void rbdDescriptionForReceipts(Segment segment, Map rbdMap, Map rbdPriceMap, List<String> rbdArryList, FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){

		LOG.debug(this.getClass().getName(),"entering rbdDescriptionForReceipts(segment,rbdMap,rbdPriceMap,rbdArrayList,formatSendPsgrNotificationRQ)");	

	    List<Ticket> ticketList = segment.getTickets().getTicket();	
		float tktFare = 0;  
		float accomTktFare = 0;
		float totalFare = 0;
		float totalFareForNoOfUnitsConsidered = 0;
		
		boolean accomFlg = false;
		boolean railFareFlg = false;
		boolean totalFlg = false;
		for (Iterator<Ticket> j = ticketList.iterator(); j.hasNext(); )  {        			
    		Ticket ticket = new Ticket();
    		ticket = (Ticket) j.next(); 
    		if(ticket.getPricingItem().getTariff().getRailFare().floatValue() > 0 && ticket.getPricingItem().getTariff().getAccomCharge().floatValue() > 0){
    			accomFlg = true;
    			railFareFlg = true;
    			totalFareForNoOfUnitsConsidered += Math.abs(ticket.getPricingItem().getTariff().getRailFare().floatValue());
    			totalFareForNoOfUnitsConsidered += Math.abs(ticket.getPricingItem().getTariff().getAccomCharge().floatValue());
    		}else if(ticket.getPricingItem().getTariff().getRailFare().floatValue() > 0 ){
    			railFareFlg = true;
    			totalFareForNoOfUnitsConsidered += Math.abs(ticket.getPricingItem().getTariff().getRailFare().floatValue());
    		}else if(ticket.getPricingItem().getTariff().getAccomCharge().floatValue() > 0){
    			accomFlg = true;
    			totalFareForNoOfUnitsConsidered += Math.abs(ticket.getPricingItem().getTariff().getAccomCharge().floatValue());
    		}else if(ticket.getPricingItem().getTariff().getTotalFare().floatValue() > 0){
    			totalFlg = true;
    		}
		}
		
		//Get Endorsement for this passenger		
		noOfTickets = ticketList.size();	
		float railFare = 0f;		
		if(!accomFlg && !railFareFlg && !totalFlg){
			String rbDesc = segment.getClassOfService().getRBDDescription();
			if(rbdMap.containsKey(rbDesc)){
				long units = segment.getClassOfService().getNumberOfUnits().longValue();
	    		units = units + (Long) rbdMap.get(rbDesc);
	    		rbdMap.put(rbDesc, units);	
			}else{
				rbdMap.put(rbDesc, segment.getClassOfService().getNumberOfUnits().longValue());
				rbdArryList.add(rbDesc);
				rbdPriceMap.put(rbDesc, 0);
			}
		}else if(!accomFlg && !railFareFlg && segment.getSeatingAssignment() != null){
			String rbDesc = segment.getClassOfService().getRBDDescription();
			if(rbdMap.containsKey(rbDesc)){
				long units = segment.getClassOfService().getNumberOfUnits().longValue();
	    		units = units + (Long) rbdMap.get(rbDesc);
	    		rbdMap.put(rbDesc, units);	
			}else{
				rbdMap.put(rbDesc, segment.getClassOfService().getNumberOfUnits().longValue());
				rbdArryList.add(rbDesc);
				rbdPriceMap.put(rbDesc, 0);
			}
		}else{
			boolean noOfUnitsConsidered = false;
			for (Iterator i = ticketList.iterator(); i.hasNext(); )  {				
		    		Ticket ticket = new Ticket();
		    		ticket = (Ticket) i.next(); 
		    	if(!noOfUnitsConsidered){
		    		tktFare = 0; 
		    		accomTktFare = 0;
		    		BigInteger pasNum = new BigInteger("0");
		    		if(ticket.getPsgrAssociations() != null){
		    			pasNum = ticket.getPsgrAssociations().getPsgrAssociation().get(0);
		    		}
		    		String endMentText = displayEndorsementForRBDDescription(formatSendPsgrNotificationRQ, segment.getSegmentNumber().intValue(), pasNum);
		    		String endMnt = (endMentText != null ? (endMentText+" ") : "")+"RAIL FARE";
		    		String rbDesc = segment.getClassOfService().getRBDDescription();
		    		if(accomFlg && railFareFlg){
		    			//Do nothing
		    		}else if(accomFlg || railFareFlg){
		    			endMnt = rbDesc;
		    		}
				    if(ticket.getPricingItem().getTariff().getRailFare().floatValue() > 0 && ticket.getPricingItem().getTariff().getAccomCharge().floatValue() > 0){								
						if(rbdMap.containsKey(endMnt)){
							tktFare = Float.valueOf(rbdPriceMap.get(endMnt).toString()) + Math.abs(ticket.getPricingItem().getTariff().getRailFare().floatValue());
							railFare = railFare + tktFare;
							long units = 1;
				    		units = units + (Long) rbdMap.get(endMnt);
				    		rbdMap.put(endMnt, units);
				    		rbdPriceMap.put(endMnt, tktFare);	
						}else{
							tktFare = Math.abs(ticket.getPricingItem().getTariff().getRailFare().floatValue());					
							railFare = railFare + tktFare;
							rbdMap.put(endMnt, (long)1);
							rbdPriceMap.put(endMnt, tktFare);
							rbdArryList.add(endMnt);					
						}
						
						if(rbdMap.containsKey(rbDesc)){
							accomTktFare = Float.valueOf(rbdPriceMap.get(rbDesc).toString())  + Math.abs(ticket.getPricingItem().getTariff().getAccomCharge().floatValue());
							long units = 1;
				    		units = units + (Long) rbdMap.get(rbDesc);
				    		rbdMap.put(rbDesc, units);	
				    		rbdPriceMap.put(rbDesc, accomTktFare);	
						}else{
							accomTktFare = Math.abs(ticket.getPricingItem().getTariff().getAccomCharge().floatValue());					
							rbdMap.put(rbDesc, (long)1);
							rbdArryList.add(rbDesc);
							rbdPriceMap.put(rbDesc, accomTktFare);
						}				
					}else if(ticket.getPricingItem().getTariff().getRailFare().floatValue() > 0 ){
						if(rbdMap.containsKey(endMnt)){
							tktFare = Float.valueOf(rbdPriceMap.get(endMnt).toString()) + Math.abs(ticket.getPricingItem().getTariff().getRailFare().floatValue());
							railFare = railFare + tktFare;
							long units = 1;
				    		units = units + (Long) rbdMap.get(endMnt);
				    		rbdMap.put(endMnt, units);
				    		rbdPriceMap.put(endMnt, tktFare);	
						}else{
							tktFare = Math.abs(ticket.getPricingItem().getTariff().getRailFare().floatValue());	
							railFare = railFare + tktFare;
							rbdMap.put(endMnt, (long)1);
							rbdPriceMap.put(endMnt, tktFare);
							rbdArryList.add(endMnt);
						}				
					}else if(ticket.getPricingItem().getTariff().getAccomCharge().floatValue() > 0){
						if(rbdMap.containsKey(rbDesc)){
							accomTktFare = Float.valueOf(rbdPriceMap.get(rbDesc).toString())  + Math.abs(ticket.getPricingItem().getTariff().getAccomCharge().floatValue());
							long units = 1;
				    		units = units + (Long) rbdMap.get(rbDesc);
				    		rbdMap.put(rbDesc, units);	
				    		rbdPriceMap.put(rbDesc, accomTktFare);	
						}else{
							accomTktFare = Math.abs(ticket.getPricingItem().getTariff().getAccomCharge().floatValue());					
							rbdMap.put(rbDesc, (long)1);
							rbdArryList.add(rbDesc);
							rbdPriceMap.put(rbDesc, accomTktFare);
						}
					}else if(ticket.getPricingItem().getTariff().getTotalFare().floatValue() > 0){
						if(rbdMap.containsKey(rbDesc)){
							totalFare = 0;
							long units = 1;
				    		units = units + (Long) rbdMap.get(rbDesc);
				    		rbdMap.put(rbDesc, units);	
				    		rbdPriceMap.put(rbDesc, 0);	
						}else{
							totalFare = Math.abs(ticket.getPricingItem().getTariff().getTotalFare().floatValue());					
							rbdMap.put(rbDesc, (long)1);
							rbdArryList.add(rbDesc);
							rbdPriceMap.put(rbDesc, 0);
						}
					}else{
						rbDesc = segment.getClassOfService().getRBDDescription();
						if(rbdMap.containsKey(rbDesc)){
							rbdMap.clear();
	    					rbdPriceMap.clear();
	    					rbdArryList.clear();
							long units = segment.getClassOfService().getNumberOfUnits().longValue();
				    		rbdMap.put(rbDesc, units);	
				    		noOfUnitsConsidered = true;
				    		rbdArryList.add(rbDesc);
							rbdPriceMap.put(rbDesc, totalFareForNoOfUnitsConsidered);
						}else{
							rbdMap.put(rbDesc, segment.getClassOfService().getNumberOfUnits().longValue());
							rbdArryList.add(rbDesc);
							rbdPriceMap.put(rbDesc, 0);
						}
					}
				}
		    }
		}
	    
	    // To build PsgrAssociations from segments
		Segment4 .PsgrAssociations psgrAssociations = segment.getPsgrAssociations();	    			
		List<BigInteger> psgrAssociationsList= psgrAssociations.getPsgrAssociation();	
		for (Iterator pList = psgrAssociationsList.iterator(); pList.hasNext(); )  {	    				
			  BigInteger pNum = (BigInteger) pList.next();	
				  if(!psgrToBeDisplayedForEndorsements.contains(pNum)){
					  psgrToBeDisplayedForEndorsements.add(pNum);
					  LOG.debug(this.getClass().getName(),"psgrToBeDisplayedForEndorsements Psgr NUMBER *********** "+pNum);	
				  }
		  }	
		LOG.debug(this.getClass().getName(),"exiting rbdDescriptionForReceipts(segment,rbdMap,rbdPriceMap,rbdArrayList,formatSendPsgrNotificationRQ)");	

	}
	
	/**
	 * Method to add the Segment Endorsements to the HTML string
	 * @param formatSendPsgrNotificationRQ
	 * @param segNumberList
	 */
	private void displaySegmentEndorsements(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ, List segNumberList){	

		LOG.debug(this.getClass().getName(),"entering displaySegmentEndorsements(formatSendPsgrNotificationRQ,segNumberList)");	

		boolean endorsementFlg = false;
		FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements  endorsementsRQ = (FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements)formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getEndorsements();
		if(endorsementsRQ != null){
			List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement> endorsementListRQ = endorsementsRQ.getEndorsement();
			for (Iterator j= endorsementListRQ.iterator();j.hasNext();)  {
				  FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement endorsement = (FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement)j.next();
			      if(!endorsement.getEndorsementLine().getLineNbr().replaceFirst("^0*", "").equals("5")){//Do not display Endorsements if LineNumber=5
					if(endorsement.getPsgrAssociations() != null ){
				    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement.SegAssociations segAssocns = endorsement.getSegAssociations();
				    	List<BigInteger> segNumbrs = segAssocns.getSegAssociation();
				    	boolean psgrFound = false;
				    	for (Iterator s = segNumbrs.iterator(); s.hasNext(); )  {
				  			if(psgrFound){
				  				break;
				  			}				  			
				    		BigInteger sNum = (BigInteger) s.next();
				  			if(segNumberList.contains(sNum.intValue())){
						    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement.PsgrAssociations psgrAssocns = endorsement.getPsgrAssociations();
						    	List<BigInteger> psgrNumbrs = psgrAssocns.getPsgrAssociation();
				  				for (Iterator p = psgrNumbrs.iterator(); p.hasNext(); )  {
						  			BigInteger pNum = (BigInteger) p.next();
						      		if(psgrToBeDisplayedForEndorsements.contains(pNum)){
						      			if(!endorsementFlg){
						  					HTML += "<div class=\"Endorsements\">";
						  					HTML += "<span class=\"EndorsementHeading\">Ticket Terms & Conditions</span>";
						  					endorsementFlg = true;
						  				}
						  				HTML += "<span class=\"EndorsementDetails\">"+ endorsement.getEndorsementLine().getText()+"</span>";
						  				psgrFound = true;
						  				break;
						      		}
				  				}//End of Passengers for Loop
				  			}//End of IF condition for Segments
				    	}//End of Segments for Loop
					 }//End of Passengers Associations
			      }//End of if LineNumber 5
			}//End of Endorsements Loop 
		}//End of endorsementsRQ
		
		if(endorsementFlg){
			HTML += "</div>";
		}
		LOG.debug(this.getClass().getName(),"exiting displaySegmentEndorsements(formatSendPsgrNotificationRQ,segNumberList)");	
}
	
	/**
	 * Method to add the Express Delivery Fee section to the HTML string
	 */
	private void expressDeliveryFee(){	

		LOG.debug(this.getClass().getName(), "entering method expressDeliveryFee()");
// test the express delivery fee before checking in the code
		if(Float.floatToRawIntBits(expressDeliveryFee) != 0 ){
			HTML += "<div class=\"ChangeSummarySubTotalContainerWhiteBackGround\">";
				HTML += "<div class=\"ChangeSummarySubTotalAlignLeft\">";
					HTML += "Express Delivery Fee";
				HTML += "</div>";
				HTML += "<div class=\"ChangeSummarySubTotalAlignRight\"><span>";
					HTML += tddCommonFunctions.getTotalAmountFormat(expressDeliveryFee, isBulkFare);
				HTML += "</span></div>";
			HTML += "</div>";
		}
		LOG.debug(this.getClass().getName(), "exiting method expressDeliveryFee()");


	}	
	
	/**
	 * Method to add the Service Fee section to the HTML string
	 */
	private void showServiceFee(){	

		LOG.debug(this.getClass().getName(), "entering method showServiceFee()");
// Test this service fee before checking the code 
		if(Float.floatToRawIntBits(serviceFee) != 0 ){
			HTML += "<div class=\"ChangeSummaryPenaltiesContainer\">";
				HTML += "<div class=\"ChangeSummaryPenaltiesLeft\">";
					HTML += "Service Fee";
				HTML += "</div>";
				HTML += "<div class=\"ChangeSummaryPenaltiesRight\">";
					HTML += tddCommonFunctions.getTotalAmountFormat(serviceFee, isBulkFare);
				HTML += "</div>";
			HTML += "</div>";
		}
		LOG.debug(this.getClass().getName(), "exiting method showServiceFee()");
	}

	/**
	 * Method to prepare the endorsement text
	 * @param formatSendPsgrNotificationRQ
	 * @param segNumber
	 * @param pasNum
	 * @return String endorsement Text
	 */
	private String displayEndorsementForRBDDescription(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ, int segNumber, BigInteger pasNum){	

		LOG.debug(this.getClass().getName(), "entering method displayEndorsementForRBDDescription(formatSendPsgrNotificationRQ)");

		String endorsementTxt = null;
		FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements  endorsementsRQ = (FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements)formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getEndorsements();
		if(endorsementsRQ != null){
			List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement> endorsementListRQ = endorsementsRQ.getEndorsement();
			for (Iterator j= endorsementListRQ.iterator();j.hasNext();)  {
				  FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement endorsement = (FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement)j.next();
			      if(endorsement.getEndorsementLine().getLineNbr().replaceFirst("^0*", "").equals("5")){//Do not display Endorsements if LineNumber=5
					if(endorsement.getPsgrAssociations() != null ){
				    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement.PsgrAssociations psgrAssocns = endorsement.getPsgrAssociations();
				    	List<BigInteger> psgrNumbrs = psgrAssocns.getPsgrAssociation();
				  		for (Iterator p = psgrNumbrs.iterator(); p.hasNext(); )  {
				  			BigInteger pNum = (BigInteger) p.next();
				      		if(pasNum.equals(pNum)){
				      			FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement.SegAssociations segAssocns = endorsement.getSegAssociations();
				      			List<BigInteger> segNumbrs = segAssocns.getSegAssociation();
				      			for (Iterator s = segNumbrs.iterator(); s.hasNext(); )  {
						  			BigInteger sNum = (BigInteger) s.next();
						  			if(segNumber == sNum.intValue()){
						  				endorsementTxt = endorsement.getEndorsementLine().getText();
						  				break;
						  			}
				      			}
				      		}
				  		}//End of Passengers for Loop	
					 }//End of Passengers Associations
			      }//End of if LineNumber 5
			}//End of Endorsements Loop 
		}//End of endorsementsRQ

		LOG.debug(this.getClass().getName(), "exiting method displayEndorsementForRBDDescription(formatSendPsgrNotificationRQ)");

		return endorsementTxt;		
	}

	
	/*
	 * Returns list of passenger starting with <code>LastName, FirstName</code>
	 * and delimited by comma.
	 * @param request FormatSendPsgrNotificationRQ object.
	 * @return String with format FirstName1, LastName1, FirstName2, LastName2 etc
	 */
	
	//TDD2
	String getCommaDelimitedPassengerList(FormatSendPsgrNotificationRQ request){
		List<Passenger> passengers = request.getFormatSendPsgrNotification().getPassengers().
																				getPassenger();
		Iterator<Passenger> it = passengers.iterator();
		StringBuilder builder = new StringBuilder(100);
		while(it.hasNext()){
			Passenger passenger = it.next();
			PassengerName passengerName = passenger.getPassengerName();
			//Need to reset the name to a blank space " " since we try extracting the first character.
			String firstName = (passengerName.getFirstName() == null || 
								"".equals(passengerName.getFirstName())) ? SPACE: passengerName.getFirstName().toLowerCase();
			String lastName = (passengerName.getLastName() == null ||
								"".equals(passengerName.getLastName()))? SPACE:passengerName.getLastName().toLowerCase();
			
			firstName = Character.toUpperCase(firstName.charAt(0)) + firstName.substring(1);
			lastName =  Character.toUpperCase(lastName.charAt(0)) + lastName.substring(1);
			
			//If both the firstName and lastName are empty dont append it
			if(!firstName.trim().equals("") || !lastName.trim().equals("")){
				builder.append(",").append(SPACE).append(firstName).
										    append(SPACE).append(lastName);
			}
		}
		
		//Remove the first comma during the processing.
		String psgrStr = builder.toString().replaceFirst("^," , "");
		//Trim string if needed
		return psgrStr.trim();
	}	
	 
	/*
	 * Returns the first passenger in the request
	 * @param request FormatSendPsgrNotificationRQ object.
	 */
	
	String getFirstPassengerName(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){
		List<Passenger> passengers = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification()
																	.getPassengers().getPassenger();
		Iterator<Passenger> it = passengers.iterator();
		while(it.hasNext()){
			Passenger passenger = it.next();
			PassengerName passengerName = passenger.getPassengerName();
			return passengerName.getFirstName() + " " + passengerName.getLastName();
		}
		
		return "";
		
	}
	/*
	 * Get first ticket number from {@link FormatSendPsgrNotificationRQ} class. In the case
	 * of cancel requests an empty text is returned, since TicketNumber does not exist for
	 * Cancelled tickets.
	 * @return Ticket number or empty string in case of Cancelled tickets.
	 */
	
	String getFirstTicketNumber(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){
		// TODO Auto-generated method stub
		FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = 
								formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();
		
		//Ticket numbers can be empty for requests of type CR
		if(itineraryRQ == null){
			return "";
		}
		
		List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
	    
	    for(java.util.Iterator<LogicalTrip> l=logicalTripListRQ.iterator();l.hasNext();){
	    	List<com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment> 
	    						segmentList = l.next().getSegments().getSegment();
	    	//Iterate through each segment
    		for(Iterator s = segmentList.iterator();s.hasNext(); ){	
    			Segment segment = new Segment();
				segment = (Segment)s.next();
    			if(segment.getTickets()!=null){
					if(segment.getTickets().getTicket()!=null && !(new FormatPrintCommonFunctions().serviceFee(segment))){					
						List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket> ticketList = segment.getTickets().getTicket();									
						for(Iterator t=ticketList.iterator();t.hasNext();) {						
							Ticket ticket = (Ticket)t.next();
							String ticketNumber = ticket.getTicketNumber();
							if(ticketNumber != null){
								return ticketNumber;
							}
						 }											
					 }	
				}	
	    	
    		}
		
	    }
	
	    return "";
	}
	

}

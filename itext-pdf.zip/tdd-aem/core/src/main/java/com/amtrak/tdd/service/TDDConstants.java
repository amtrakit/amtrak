/**
 * THIS PROGRAM IS CONFIDENTIAL AND PROPRIETARY TO AMTRAK AND 

 * MAY NOT BE REPRODUCED, PUBLISHED OR DISCLOSED TO OTHERS WITHOUT AUTHORIZATION.  

 * COPYRIGHT � AMTRAK.  THIS WORK IS UNPUBLISHED.


 */
package com.amtrak.tdd.service;

import java.util.regex.Pattern;

/**
 * TDD Constants Class
 * 
 * 	This class will store all the constants required for TDD  Projects.
 *
 * @author VPakalapati
 *
 */
public class TDDConstants {
	
	
	/**
	 * Constructor
	 */
	private TDDConstants(){
        // nothing to do.
	}

	// ARIES Request Options
	public static final String PRINT = "PRINT";
	public static final String EMAIL = "EMAIL";
	public static final String MOBILE = "MOBILE";
	public static final String BARCODE = "BARCODE";
	public static final String NOTHING = "NOTHING";
	// Schema constants
	public static final String FORMATSENDPSGRNOTIFICATIONRQ_XSD = "FormatSendPsgrNotificationRQ.xsd";
	public static final String SENDEMAILNOTIFICATIONRQ_XSD = "SendEmailNotification.xsd";
	public static final String BASE_SCHEMA_LOCATION = "schemas/ota/";

	// List of receipt types 2 letter codes
	public static final String PURCHASE_SUMMARY = "PS";
	public static final String CHANGE_SUMMARY = "CS";
	public static final String EVEN_EXCHANGE = "EX";
	public static final String DOWNGRADE_REFUND = "DR";
	public static final String UPGRADE_AMOUNT_DUE = "UD";
	public static final String UPGRADE_NEW_MONEY = "UN";
	public static final String CANCEL_REFUND = "CR";
	public static final String EVOUCHER_TYPE = "EV";

	// List of receipt requests
	public static final String DUPLICATE_RECEIPT_REQUEST = "DR";
	public static final String DOCUMENT_REQUEST = "TD";
	public static final String DOCUMENT_RECEIPT_REQUEST = "DD";
	public static final String EVOUCHER_REQUEST = "EV";
	public static final String XL_REQUEST = "XL";
	public static final String QR = "QR";
	
	// Form of payment types
	public static final String CREDIT_CARD = "CCD";
	public static final String CASH = "CSH";
	public static final String CHECK = "CHK";
	public static final String EVOUCHER = "EVC";
	public static final String EXCHANGE = "EXC";
	public static final String NAPNEAP = "NAP";	
	public static final String MISCORDER = "MOD";
	public static final String PASSRIDER = "PRD";
	public static final String OTHERS = "OTH";
	
	// Carrier types
	public static final String TRAIN = "TRAIN";
	public static final String FERRY = "FERRY";
	public static final String LIMO = "LIMO";
	// Equipment Types
	public static final String THS = "THS";
	public static final String TRN = "TRN";
	public static final String CTR = "CTR";
	public static final String TSL = "TSL";
	public static final String TAT = "TAT";
	public static final String BUS = "BUS";
	public static final String LCH = "LCH";
	public static final String LMO = "LCH";
	// Fees
	public static final String EXPRESS_DELIVERY_FEE = "EXDL";
	public static final String SERVICE_FEE = "FEE";

	// JMS
	public static final String JMSXDeliveryCount = "JMSXDeliveryCount";

	// Formatting Constants
	public static final String SPACE = " ";
	public static final String PACIFIC_TIMEZONE = "PT";
	
	public static final String RETURN_TRIP = "RETURN_TRIP";
	public static final String ONEWAY_TRIP = "ONEWAY_TRIP";
	public static final String MULTICITY_TRIP = "MULTICITY_TRIP";

	/*
	 * Static field that needs to be displayed in case this is
	 * of type bulk
	 */
	public static final String BULK_TEXT_VALUE = "BULK";
	
	/*
	 * Multiride static text for Rule-75 implementation
	 */
	public static final String TRANSFERABLE_VALUE = "May be used by multiple riders";
	public static final String NON_TRANSFERABLE_VALUE = "NON-TRANSFERABLE";
	public static final String MULTI_MONTHLY_RIDE = "MONTHLY";
	public static final String MULTI_MONTHLY_RIDE_TICKET_TYPE = "Monthly";
	public static final String MULTI_MULTIRIDE =  "MULTIRIDE";

	public static final Pattern pattern = Pattern.compile("<(p|li)>(.+?)</(p|li)>");
	public static final String DEFAULT_PARTNER = "AMTRAK";
	public static final String DEFAULT_FOOTER_TEXT = "1-800-USA-RAIL (1-800-872-7245)";
	public static final String STATION_ADVISORY_PATH="/content/tdd/StationAdvisory/jcr:content/alertslist";
	public static final String SERVICE_ADVISORY_PATH="/content/tdd/ServiceAdvisory/jcr:content/alertslist";
	public static final String RBD_INFORMATION_PATH="/content/tdd/RBDInformation/jcr:content/alertslist";
	public static final String FARE_PLAN_INFORMATION_PATH="/content/tdd/FarePlanInformation/jcr:content/alertslist";
	public static final String PARTNER_INFORMATION_PATH="/content/tdd/PartnerInformation/jcr:content/alertslist";
	public static final String FOOTER_INFORMATION_PATH="/content/tdd/FooterInformation/jcr:content/alertslist";
	public static final String TICKET_TYPE_INFORMATION_PATH="/content/tdd/TicketTypeInformation/jcr:content/alertslist";
	public static final String GENERAL_INFORMATION_PATH="/content/tdd/GeneralInformation/jcr:content/alertslist";
	public static final String MULTIRIDE_PARTNER_IDENTIFIER_PATH="/content/tdd/MultiRidePartnerIdentifier/jcr:content/alertslist";
	public static final String DEPART_STATION="depstation";
	public static final String ARRIVE_STATION="arrivestation";
	public static final String SERVICE_NAME="servicename";
	public static final String SERVICE_NUMBER="servicenumber";
	public static final String TICKET_TYPE="tickettype";
	public static final String FARE_PLAN="fareplan";
	public static final String RBD_CODE="rbdcode";
	public static final String PAYMENT_CODE="paymenttype";
	public static final String PARTNER_NAME="partner";
	public static final String START_DATE="startdate";
	public static final String END_DATE="enddate";
	public static final String IMPORTANT_INFO_TEXT="impinfo";
	public static final String RANK_TEXT="rank";
	public static final String NODE_TYPE="nt:unstructured";
	public static final String SPLIT_STRING_TEXT="\\s*,\\s*";
	public static final String SERVICE_NUMBER_LIST_KEY="servicenumberList";
	public static final String SERVICE_NAME_LIST_KEY="servicenameList";
	public static final String PAGE_PATH_TEXT="path";
	public static final String NODE_TYPE_TEXT="type";
	public static final String LIKE_TEXT="like";
	public static final String TRUE_TEXT="true";
	public static final String P_HITS_TEXT="p.hits";
	public static final String P_HITS_VALUE="full";
	public static final String P_OFFSET_TEXT="p.offset";
	public static final String P_OFFSET_VALUE="0";
	public static final String P_LIMIT_TEXT="p.limit";
	public static final String P_LIMIT_VALUE="-1";
	public static final String PROPERTY_TEXT="property";
	public static final String PROPERTY_DOT_OPERATION_TEXT="property.operation";
	public static final String TEN_RIDE="10-Ride";
	public static final String SIX_RIDE="6-Ride";
	public static final String MONTHLY_RIDE="Monthly";
	public static final String PARTNER_STATION="partnerstation";
	public static final String AMTRAK_STATION="amtrakstation";
	public static final String SHARED_PARTNER_NAME="sharedpartner";
	public static final String PUBLISH_DATE="publishDate";
	public static final String RBD_EXCLUDE="rbdexclude";
	public static final String TRAIN_NAME_EXCLUDE="trainnameexclude";
	public static final String TRAIN_NUMBER_EXCLUDE="trainnumberexclude";
	public static final String SALES_RECEIPT_STATION_ADVISORY_PATH="/content/salesreceipt/StationAdvisory/jcr:content/alertslist";
	public static final String SALES_RECEIPT_SERVICE_ADVISORY_PATH="/content/salesreceipt/ServiceAdvisory/jcr:content/alertslist";
	public static final String SALES_RECEIPT_RBD_INFORMATION_PATH="/content/salesreceipt/RBDInformation/jcr:content/alertslist";
	public static final String SALES_RECEIPT_FARE_PLAN_INFORMATION_PATH="/content/salesreceipt/FarePlanInformation/jcr:content/alertslist";
	public static final String SALES_RECEIPT_PARTNER_INFORMATION_PATH="/content/salesreceipt/PartnerInformation/jcr:content/alertslist";
	public static final String SALES_RECEIPT_TICKET_TYPE_INFORMATION_PATH="/content/salesreceipt/TicketTypeInformation/jcr:content/alertslist";
	public static final String SALES_RECEIPT_GENERAL_INFORMATION_PATH="/content/salesreceipt/GeneralInformation/jcr:content/alertslist";
	public static final String SALES_RECEIPT_PAYMENT_CODE_INFORMATION_PATH="/content/salesreceipt/PaymentInformation/jcr:content/alertslist";
	
	public static final String REFUND_RECEIPT_GENERAL_INFORMATION_PATH="/content/refundreceipt/GeneralInformation/jcr:content/alertslist";
	public static final String REFUND_RECEIPT_PAYMENT_CODE_INFORMATION_PATH="/content/refundreceipt/PaymentInformation/jcr:content/alertslist";
	public static final String TEXT_EXCLUDE="exclude";
	public static final String TEXT_INCLUDE="include";
	public static final String TEXT_EXC="Exc";
	public static final String TEXT_INC="Inc";
	
	public static final String AMERICAN_EXPRESS="AMERICAN EXPRESS";
	public static final String MASTERCARD="MasterCard";
	public static final String VISA="Visa";
	public static final String DISCOVER="Discover";
	public static final String TRANSPORTATION_CERTIFICATE="Transportation Certificate";
	public static final String GIFT_CERTIFICATE="Gift Certificate";
	public static final String EXCHANGE_PAPER_TICKETS="Exchange Paper Tickets";
	public static final String TRANSIT_SUBSIDY="Transit Subsidy";
	public static final String TRANSIT_SUBSIDY_CHECK="Transit Subsidy Check";
	public static final String MONEY_ORDER="Money Order";
	public static final String UNIVERSAL_AIR_TRAVEL_PLAN="Universal Air Travel Plan";
	public static final String MISCELLANEOUS_CHANGE_ORDER="Miscellaneous Charge Order";
	public static final String UNDEFINED_FORM_OF_PAYMENT="Undefined Form of Payment";
	public static final String RAILROAD_ORDER="Railroad Order";
	public static final String AMTRAK_GUEST_REWARDS="Amtrak Guest Rewards";
	public static final String VIA_CREDIT_CARD="Via Credit Card";

	public static final String SELF_TRANSFER="SELF TRANSFER";
	


}


package com.amtrak.tdd.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.tdd.jcr.RBDCriteria;
import com.amtrak.tdd.service.TDDConstants;

public final class ImportantInformationHelper {
	
	private static final Logger LOG = LoggerFactory.getLogger(ImportantInformationHelper.class);

	
	 public static final ImportantInformationHelper INSTANCE = new  ImportantInformationHelper();
	 SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");
	 SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");

	   private ImportantInformationHelper() {
	        // nothing to do.
	    }

		public boolean compareResString(String resInfoProperty, String resName){
			boolean display = true;
			
			String[] resArray = resInfoProperty.trim().split("\\s*,\\s*");

			for (int j=0;j<resArray.length;j++){
				if(resArray[j].equals(resName)){
					display= true;
					break;
				} else {
					display= false;
				}
			}
			return display;
		}

		public boolean compareResString(String[] resArray, String resName){
			boolean display = true;
			
			for (int j=0;j<resArray.length;j++){
				if(resArray[j].equals(resName)){
					display= true;
					break;
				} else {
					display= false;
				}
			}
			return display;
		}
		
		
		public Date getInfoDate(String datetext) {

			Date date = null;
			
			try {
				date = inputFormat.parse(datetext);
			} catch (ParseException e) {
				LOG.error("Error while parsing the String date passed:"+datetext , e);
				
			}
			return date;
			
		}

		public Date getDate(String datetext) {

			Date date = null;
			
			try {
				date = dateFormat.parse(datetext);
			} catch (ParseException e) {
				LOG.error("Error while parsing the String date passed:"+datetext , e);
				
			}
			return date;
			
		}
	
		public Date getDate(Calendar datetext) {

			Date date = null;
			
			try {
				date = datetext.getTime();
			} catch (Exception e) {
				LOG.error("Error while parsing the Calendar date passed:"+datetext , e);
			}
			return date;
		}

		
		public boolean compareDates(Date travelstartdate,Date infostartdate,Date infoenddate) {
			boolean datecompare=false;
			try{
			if ((travelstartdate.after(infostartdate) || travelstartdate.equals(infostartdate))
					&& (travelstartdate.before(infoenddate) || travelstartdate.equals(infoenddate))) {
				datecompare=true;
			}
			} catch (Exception e){
				LOG.error("Error while comparing the dates passed:" , e);
				
			}
			
			return datecompare;
			
		}
	
		public Set<String> sortInformationList(Map<Integer, String> infomaplist,Set<String> infoHashSet){
			if (infomaplist != null){
				SortedSet<Integer> keys = new TreeSet<Integer>(infomaplist.keySet());
				for (Integer key : keys) { 
					infoHashSet.add(infomaplist.get(key));
				}
			}
			return infoHashSet;

		}

		public List<String> sortInformationList(Map<Integer, String> infomaplist,List<String> InfoList){
			if (infomaplist != null){
				SortedSet<Integer> keys = new TreeSet<Integer>(infomaplist.keySet());
				for (Integer key : keys) { 
					InfoList.add(infomaplist.get(key));
				}
			}
			return InfoList;

		}
		
		
	
		public boolean checkExcludeMatch(String resInfoProperty, String resName){
			boolean display = false;
		
			String[] resArray = resInfoProperty.trim().split("\\s*,\\s*");
			
			for (int j=0;j<resArray.length;j++){
				if(resArray[j].equals(resName)){
					display= true;
					break;
				} else {
					display= false;
				}
			}
			
			if ( display){
				display= false;
			} else {
				display= true;
			}
			
			return display;
		}

		public boolean checkRBDExcludeMatch(String[] resArray, List<RBDCriteria> rbdCode,boolean exclude){
			boolean display = false;
						
			
			for (int j=0;j<resArray.length;j++){
				for(int i=0;i<rbdCode.size();i++){
					
					if(resArray[j].equals(rbdCode.get(i).getRbdCode())){
						display= true;
						break;
					} else {
						display= false;
					}
					
				}
				if (display){
					break;
				}
				
			}
			
			if ( display== true && exclude == true){
				display= false;
			} else if(display== false && exclude == true){
				display= true;
			}
			
			return display;
		}

		public boolean checkRBDExcludeMatch(String resInfoProperty, List<RBDCriteria> rbdCode,boolean exclude){
			boolean display = false;
						
			String[] resArray = resInfoProperty.trim().split("\\s*,\\s*");
				for(int i=0;i<rbdCode.size();i++){
					for (int j=0;j<resArray.length;j++){
					
					if(resArray[j].equals(rbdCode.get(i).getRbdCode())){
						display= true;
						break;
					} else {
						display= false;
					}
					}
					if (display){
						break;
					}

				}
				
			
			if ( display== true && exclude == true){
				display= false;
			} else if(display== false && exclude == true){
				display= true;
			}
			
			return display;
		}
		public boolean checkExcludeServiceMatch(String resInfoProperty, List<String> resName){
			boolean display = false;
			String[] resArray = resInfoProperty.trim().split("\\s*,\\s*");
			
			for(int i=0;i<resName.size();i++){
				for (int j=0;j<resArray.length;j++){
					if(resArray[j].equals(resName.get(i))){
						display= true;
						break;
					} else {
						display= false;
					}
				}
				if (display){
					break;
				}
			}
			
			if ( display){
				display= false;
			} else {
				display= true;
			}
			
			return display;
		}

		
	public static String changeExcludeOption(String exoption ){
		
		String option = exoption;
			if (option != null && option.equalsIgnoreCase(TDDConstants.TEXT_EXCLUDE)){
				option = TDDConstants.TEXT_EXC;
			} else if (option != null && option.equalsIgnoreCase(TDDConstants.TEXT_INCLUDE)){
				option = TDDConstants.TEXT_INC;
			}
			
			return option;
			
	}

}

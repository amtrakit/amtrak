package com.amtrak.tdd.service;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRS.FormatSendPsgrNotification.PrintData.Page;
import com.amtrak.mulesoft.schema._2016._03._07.TicketTextHeightType;
import com.amtrak.mulesoft.schema._2016._03._07.TicketTextStyleType;
import com.amtrak.mulesoft.schema._2016._03._07.TicketTextWidthType;

public class FormatPrintCommonFunctions {
	// Define the Logger
	private static final Logger LOG = LoggerFactory.getLogger(FormatPrintCommonFunctions.class);
	
	public FormatPrintCommonFunctions(){
        // nothing to do.
	}
	
	public void setElementProperties(Page.Text text, String value, int row, int column, String style, String height, String width){
    	text.setValue(value);
		text.setRow(BigInteger.valueOf(row));
		text.setColumn(BigInteger.valueOf(column));
		text.setStyle(TicketTextStyleType.valueOf(style));
		text.setHeight(TicketTextHeightType.valueOf(height));
		text.setWidth(TicketTextWidthType.valueOf(width));
    }
	
	public String getPaymentType(String cType){
		String cardType = cType;
		if(cardType.equalsIgnoreCase(TDDConstants.AMERICAN_EXPRESS))
			cardType = "AX";
		else if(cardType.equalsIgnoreCase(TDDConstants.MASTERCARD))
			cardType = "MC";
		else if(cardType.equalsIgnoreCase(TDDConstants.VISA))
			cardType = "VI";
		else if(cardType.equalsIgnoreCase(TDDConstants.DISCOVER))
			cardType = "DS";
		else if(cardType.equalsIgnoreCase(TDDConstants.TRANSPORTATION_CERTIFICATE))
			cardType = "Trans Cert";
		else if(cardType.equalsIgnoreCase(TDDConstants.GIFT_CERTIFICATE))
			cardType = "Gift Cert";
		else if(cardType.equalsIgnoreCase(TDDConstants.EXCHANGE_PAPER_TICKETS))
			cardType = "Exchange";
		else if(cardType.equalsIgnoreCase(TDDConstants.TRANSIT_SUBSIDY))
			cardType = "Trans Sub";
		else if(cardType.equalsIgnoreCase(TDDConstants.TRANSIT_SUBSIDY_CHECK))
			cardType = "Trans Sub Chk";
		else if(cardType.equalsIgnoreCase(TDDConstants.MONEY_ORDER))
			cardType = "Money Order";
		else if(cardType.equalsIgnoreCase(TDDConstants.UNIVERSAL_AIR_TRAVEL_PLAN))
			cardType = "UATP";
		else if(cardType.equalsIgnoreCase(TDDConstants.MISCELLANEOUS_CHANGE_ORDER))
			cardType = "Misc Chg";
		else if(cardType.equalsIgnoreCase(TDDConstants.UNDEFINED_FORM_OF_PAYMENT))
			cardType = "OTHER";
		else if(cardType.equalsIgnoreCase(TDDConstants.RAILROAD_ORDER))
			cardType = "RR Order";
		else if(cardType.equalsIgnoreCase(TDDConstants.AMTRAK_GUEST_REWARDS))
			cardType = "AGR";
		else if(cardType.equalsIgnoreCase(TDDConstants.VIA_CREDIT_CARD))
			cardType = "VIA";		
	    LOG.info("###CARD TYPE in FormatPrintcommonFunctions ####" +cardType);
		return cardType;		
	}
	
	
	              
	
	 // To Get RBD Description
    public String rbdDescription(com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment segment){
	    String rbdDescription=null;
	    if(segment.getClassOfService().getClassOfService() != null){
	       if(segment.getClassOfService().getNumberOfUnits().longValue() > 01){
	          rbdDescription = segment.getClassOfService().getNumberOfUnits().longValue() +" " +segment.getClassOfService().getRBDDescription()+"S";
	        }else if(segment.getClassOfService().getNumberOfUnits().longValue() == 01){
	          rbdDescription = segment.getClassOfService().getNumberOfUnits().longValue() +" " +segment.getClassOfService().getRBDDescription();
	        }
	    }
	    return rbdDescription;
	}
    
    public String addSpaces(String tNum) {
    	int i=0;
    	String trainNum = tNum;
    	i=trainNum.length();
    	if ( i == 4 )
    	return trainNum;
    	else  {
    	int j= 4 - i;
    	for (int k=0; k<j; k++) {
    		trainNum=" "+trainNum;
    	}
    	return trainNum;
        	}
    	}
    
    public String addZero(String cNumber) {
    	int i=0;
    	String carNumber = cNumber;
    	i=carNumber.length();
    	if ( i == 4 )
    	return carNumber;
    	else  {
    	int j= 4 - i;
    	for (int k=0; k<j; k++) {
    		carNumber="0"+carNumber;
    	}
    	return carNumber;
        	}
    	} 
    
    public String addZeroCouponNum(String couponNum) {
    	int i=0;
    	i=couponNum.length();
    	if ( i == 2 )
    	return couponNum;
    	else  {
    	int j= 2 - i;
    	for (int k=0; k<j; k++) {
    		couponNum="0"+couponNum;
    	}
    	return couponNum;
        	}
    	}    
    
    public String addSpacesAmount(String amount) {
    	int i=0;
    	i=amount.length();
    	if ( i == 7 )
    	return amount;
    	else  {
    	int j= 7 - i;
    	for (int k=0; k<j; k++) {
    		amount=" "+amount;
    	}    	
    	return amount;   	
    	
        	}
    	}
  
    public String rbdDesc(String desc) {
    	String rbddesc	= null;
    if(desc.length()>20){
		rbddesc = desc.substring(0, 20);		
	}else{
		rbddesc = desc;		
	}
    return rbddesc;

    }
    // If RBD is more than one count then S will be added at the end in the RBD description
    public String rbdDescs(String desc) {
    	String rbddesc	= null;
    if(desc.length()>19){
		rbddesc = desc.substring(0, 19);		
	}else{
		rbddesc = desc;		
	}
    return rbddesc;

    }
    
    public String[] splitString(String sText, int len) {
 	   String[] result = new String[(int)Math.ceil((double)sText.length()/(double)len)];
 	   for (int i=0; i<result.length; i++)
 	result[i] = sText.substring(i*len, Math.min(sText.length(), (i+1)*len));
 	   return result;
 	}
    
    
    // SELF TRANSFER
    public Boolean selfTransfer(Segment segment) { 
	    LOG.debug("###SELF TRANSFER####");
       	Boolean selfTransfer = false;	
       	if(segment.getTrainDetails()!=null) {
       	 if(segment.getTrainDetails().getRouteName() == null || segment.getTrainDetails().getRouteName().equalsIgnoreCase(TDDConstants.SELF_TRANSFER)){
     	    LOG.debug("###SELF TRANSFER INSIDE Format Print command Function####");
       		 selfTransfer = true;    		 
       	 }
       	    }
   		return selfTransfer;
   	} 
    // In order to place on ATB document
    public String othersType(String othersType) {    	
    if(othersType.equalsIgnoreCase(TDDConstants.TRANSPORTATION_CERTIFICATE)){
    	othersType = "Trans Cert";		
	}else if (othersType.equalsIgnoreCase(TDDConstants.GIFT_CERTIFICATE)){
		othersType = "Gift Cert";		
	}
	    LOG.debug("###OTHERS TYPE REMARK Format Print command Functions####" +othersType);
    return othersType;

    }   
    
    // Last 4 Digits should be shown on Transportation Certificate.
    public String othersNumber(String othersNumber,String othersType) {    	
    	if(othersType.equalsIgnoreCase(TDDConstants.TRANSPORTATION_CERTIFICATE) || othersType.equalsIgnoreCase(TDDConstants.GIFT_CERTIFICATE)|| othersType.equalsIgnoreCase(TDDConstants.MONEY_ORDER)){
    		othersNumber = othersNumber.substring(othersNumber.length()-4, othersNumber.length());   		
    	}
	    LOG.debug("###othersNumber Number Format Print command Functions####" +othersNumber);
    return othersNumber;

    }
    
 // EXPRESS DELIVERY && SERVICE FEE
    public Boolean expressDeliveryAndServiceFee(Segment segment) { 
	    LOG.debug("###Check ExpressDelivery####");
    	Boolean expDelFeeFlg =false;
    	List<Ticket> ticketList = segment.getTickets().getTicket();	
		for (Iterator<Ticket> itr = ticketList.iterator(); itr.hasNext(); )  {        			
    		Ticket ticket = new Ticket();
    		ticket = (Ticket) itr.next(); 		    		    		
    		if(ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null &&
    				ticket.getPricingItem().getFarePlans().getFarePlan().get(0) != null &&
    				(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().equalsIgnoreCase(TDDConstants.EXPRESS_DELIVERY_FEE) ||
    						ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().substring(0, 3).equalsIgnoreCase(TDDConstants.SERVICE_FEE))){   			     
    			     expDelFeeFlg = true;		    		    		
    			  }
		}
		return expDelFeeFlg;

	}
    
 // SERVICE FEE
    public Boolean serviceFee(Segment segment) { 
	    LOG.debug("###service Fee####");
    	Boolean expDelFeeFlg =false;
    	List<Ticket> ticketList = segment.getTickets().getTicket();	
		for (Iterator<Ticket> itr = ticketList.iterator(); itr.hasNext(); )  {        			
    		Ticket ticket = new Ticket();
    		ticket = (Ticket) itr.next(); 		    		    		
    		if(ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null &&
    				ticket.getPricingItem().getFarePlans().getFarePlan().get(0) != null &&
    				(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().substring(0, 3).equalsIgnoreCase(TDDConstants.SERVICE_FEE))){   			     
    			     expDelFeeFlg = true;		    		    		
    			  }
		}
		return expDelFeeFlg;

	}
    
 // EXPRESS DELIVERY    
    public Boolean expressDelivery(Segment segment) { 
	    LOG.debug("###Check ExpressDelivery####");
    	Boolean expDelFeeFlg =false;
    	List<Ticket> ticketList = segment.getTickets().getTicket();	
		for (Iterator<Ticket> itr = ticketList.iterator(); itr.hasNext(); )  {        			
    		Ticket ticket = new Ticket();
    		ticket = (Ticket) itr.next(); 		    		    		
    		if(ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null &&
    				ticket.getPricingItem().getFarePlans().getFarePlan().get(0) != null &&
    				(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().equalsIgnoreCase(TDDConstants.EXPRESS_DELIVERY_FEE))){   			     
    			     expDelFeeFlg = true;		    		    		
    			  }
		}
		return expDelFeeFlg;
	}
   	
}
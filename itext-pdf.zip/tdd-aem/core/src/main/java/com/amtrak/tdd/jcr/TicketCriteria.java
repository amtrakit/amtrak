package com.amtrak.tdd.jcr;

public class TicketCriteria extends BaseCriteria{
	
	private String ticketType;

	public TicketCriteria() {
        // nothing to do.
	}
	public String getTicketType() {
		return ticketType;
	}
	public void setTicketType(String ticketType) {
		this.ticketType = ticketType;
	}
}

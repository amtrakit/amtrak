package com.amtrak.tdd.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.Session;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.tdd.jcr.PartnerCriteria;
import com.amtrak.tdd.jcr.RBDCriteria;
import com.amtrak.tdd.jcr.TicketCriteria;
import com.amtrak.tdd.service.TDDConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

public class FooterInformation {
	
	/** Default log. */
	private static final Logger LOG = LoggerFactory.getLogger(FooterInformation.class);

	/*
	 * Default Constructor
	 */
	private FooterInformation(){
        // nothing to do.
	}

	
	public static Set<String> footerInformation(List<PartnerCriteria> partnerId,List<TicketCriteria> ticketTypes,QueryBuilder qbuilder,Set<String> linkedHashSet,String informationPath, Session session) {

		try{

			Date currDate = new Date();

			Map<String, String> footermap = new HashMap<>();
			HashSet<String> footerList = new HashSet<>();
			List<RBDCriteria> rbdCode = new ArrayList<>();
			List<String> snamelist = new ArrayList<>();
			List<String> snumlist = new ArrayList<>();
			
			for (PartnerCriteria resobj:partnerId){
				
				if(resobj instanceof PartnerCriteria){
					rbdCode.add(resobj.getFarePlanCriteria().getRbdCriteria());
					if (resobj.getFarePlanCriteria() != null && resobj.getFarePlanCriteria().getRbdCriteria() != null && resobj.getFarePlanCriteria().getRbdCriteria().getServiceCriteria() != null){
						snamelist.add(resobj.getFarePlanCriteria().getRbdCriteria().getServiceCriteria().getServiceName());
						snumlist.add(resobj.getFarePlanCriteria().getRbdCriteria().getServiceCriteria().getServiceNumber());
						
					}

				}

				
			}

			footermap.put(TDDConstants.PAGE_PATH_TEXT, informationPath);
			footermap.put(TDDConstants.NODE_TYPE_TEXT, TDDConstants.NODE_TYPE);
			footermap.put(TDDConstants.PROPERTY_TEXT, TDDConstants.PARTNER_NAME);
			if (partnerId != null && partnerId.size() > 0 ) {
				for (int i = 0; i < partnerId.size(); i++) {
					footermap.put("property." + (i + 1) + "_value", "%" + partnerId.get(i).getPartnerName() + "%");
				} 
			} else {
				footermap.put("property.value", "%" + TDDConstants.DEFAULT_PARTNER + "%");
			}
			footermap.put(TDDConstants.PROPERTY_DOT_OPERATION_TEXT, TDDConstants.LIKE_TEXT);
			footermap.put(TDDConstants.P_HITS_TEXT, TDDConstants.P_HITS_VALUE);
			footermap.put(TDDConstants.P_OFFSET_TEXT, TDDConstants.P_OFFSET_VALUE);
			footermap.put(TDDConstants.P_LIMIT_TEXT, TDDConstants.P_LIMIT_VALUE);

			Query footerquery = qbuilder.createQuery(PredicateGroup.create(footermap), session);
			footerquery.setStart(0);
			SearchResult footerresult = footerquery.getResult();

			for (Hit hit : footerresult.getHits()) {
				ValueMap Prop = hit.getProperties();
				Date astartdate = null;
				Date aenddate = null;
				Date tdate = null;
				Date pubdate = null;
				boolean bpubdate = true;
				
				if (Prop.get(TDDConstants.PUBLISH_DATE) != null ) {
					pubdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.PUBLISH_DATE).toString());
					if (currDate.before(pubdate)) {
						bpubdate = false;
					}
				}


				if (Prop.get(TDDConstants.PARTNER_NAME) != null && bpubdate) {
					for (int i = 0; i < partnerId.size(); i++) {

						String partner= Prop.get(TDDConstants.PARTNER_NAME).toString();
						String[] partnerArray = partner.split(TDDConstants.SPLIT_STRING_TEXT);

						for (int j=0;j<partnerArray.length;j++){
							if(partnerArray[j].equals(partnerId.get(i).getPartnerName())){




								if (Prop.get(TDDConstants.START_DATE) != null)
								{
									astartdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.START_DATE).toString());
								}
								if (Prop.get(TDDConstants.END_DATE) != null)	{
									aenddate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.END_DATE).toString());
								}

								tdate =ImportantInformationHelper.INSTANCE.getDate(partnerId.get(i).getOriginDate());

								if (ImportantInformationHelper.INSTANCE.compareDates(tdate,astartdate,aenddate)) {

									Boolean display = true;

									if ((Prop.get(TDDConstants.SERVICE_NAME) != null) && display) {
										if (partnerId.get(i)!= null && partnerId.get(i).getServiceCriteria()!= null && partnerId.get(i).getServiceCriteria().getServiceName()!= null){
											if (Prop.get(TDDConstants.TRAIN_NAME_EXCLUDE) != null && Prop.get(TDDConstants.TRAIN_NAME_EXCLUDE).toString().equalsIgnoreCase(TDDConstants.TEXT_EXCLUDE) ) {
												display =ImportantInformationHelper.INSTANCE.checkExcludeServiceMatch(Prop.get(TDDConstants.SERVICE_NAME).toString(),snamelist);
											} else { 
												display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.SERVICE_NAME).toString(),partnerId.get(i).getServiceCriteria().getServiceName());
											}
										}
									}
									if ((Prop.get(TDDConstants.SERVICE_NUMBER) != null) && display) {
										if (partnerId.get(i)!= null && partnerId.get(i).getServiceCriteria()!= null && partnerId.get(i).getServiceCriteria().getServiceNumber()!= null){
											if (Prop.get(TDDConstants.TRAIN_NUMBER_EXCLUDE) != null && Prop.get(TDDConstants.TRAIN_NUMBER_EXCLUDE).toString().equalsIgnoreCase(TDDConstants.TEXT_EXCLUDE) ) {
												display =ImportantInformationHelper.INSTANCE.checkExcludeServiceMatch(Prop.get(TDDConstants.SERVICE_NUMBER).toString(),snumlist);
											} else { 
												display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.SERVICE_NUMBER).toString(),partnerId.get(i).getServiceCriteria().getServiceNumber());
											}
										}
									}
									if ((Prop.get(TDDConstants.DEPART_STATION) != null) && display) {
										if (partnerId.get(i)!= null && partnerId.get(i).getOriginStation()!= null ){
											display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.DEPART_STATION).toString(),partnerId.get(i).getOriginStation());
										}

									}
									if ((Prop.get(TDDConstants.ARRIVE_STATION) != null) && display) {
										if (partnerId.get(i)!= null && partnerId.get(i).getDestinationStation()!= null ){
											display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.ARRIVE_STATION).toString(),partnerId.get(i).getDestinationStation());
										}
									}
									if ((Prop.get(TDDConstants.TICKET_TYPE) != null) && display) {
										if (ticketTypes.get(0)!= null && ticketTypes.get(0).getTicketType()!= null ){
											if (Prop.get(TDDConstants.TICKET_TYPE) instanceof String[]){
												display =ImportantInformationHelper.INSTANCE.compareResString((String[]) Prop.get(TDDConstants.TICKET_TYPE),ticketTypes.get(0).getTicketType());
											} else {
												display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.TICKET_TYPE).toString(),ticketTypes.get(0).getTicketType());
											}
										}
									}
									if ((Prop.get(TDDConstants.FARE_PLAN) != null) && display) {
										if (partnerId.get(i)!= null && partnerId.get(i).getFarePlanCode()!= null ){
											display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.FARE_PLAN).toString(),partnerId.get(i).getFarePlanCode());
										}
									}
									if ((Prop.get(TDDConstants.RBD_CODE) != null) && display) {
										if (partnerId.get(i)!= null && partnerId.get(i).getRbdCriteria() != null && partnerId.get(i).getRbdCriteria().getRbdCode()!= null ){
											if (Prop.get(TDDConstants.RBD_EXCLUDE) != null &&  Prop.get(TDDConstants.RBD_EXCLUDE).toString().equalsIgnoreCase(TDDConstants.TEXT_EXCLUDE)) {
												display =ImportantInformationHelper.INSTANCE.checkRBDExcludeMatch(Prop.get(TDDConstants.RBD_CODE).toString(),rbdCode,true);

											} else {
												display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.RBD_CODE).toString(),partnerId.get(i).getRbdCriteria().getRbdCode());
												
											}
										}
									}

									if ((Prop.get(TDDConstants.IMPORTANT_INFO_TEXT) != null) && display) {
										String infotext = Prop.get(TDDConstants.IMPORTANT_INFO_TEXT).toString();
										footerList.add(infotext);
									}

								}

							}
						}

					}

				}

			}
			
			if (footerList != null && !footerList.isEmpty() && footerList.size()<2 ){
				linkedHashSet.addAll(footerList);
			} else {
				
				Map<String, String> defaultFooterMap = new HashMap<>();
				footerList = new HashSet<>();
				defaultFooterMap.put(TDDConstants.PAGE_PATH_TEXT, informationPath);
				defaultFooterMap.put(TDDConstants.NODE_TYPE_TEXT, TDDConstants.NODE_TYPE);
				defaultFooterMap.put(TDDConstants.PROPERTY_TEXT, TDDConstants.PARTNER_NAME);
				defaultFooterMap.put("property.value", "%" + TDDConstants.DEFAULT_PARTNER + "%");
				defaultFooterMap.put(TDDConstants.PROPERTY_DOT_OPERATION_TEXT, TDDConstants.LIKE_TEXT);
				defaultFooterMap.put(TDDConstants.P_HITS_TEXT, TDDConstants.P_HITS_VALUE);
				defaultFooterMap.put(TDDConstants.P_OFFSET_TEXT, TDDConstants.P_OFFSET_VALUE);
				defaultFooterMap.put(TDDConstants.P_LIMIT_TEXT, TDDConstants.P_LIMIT_VALUE);

				Query defaultFooterquery = qbuilder.createQuery(PredicateGroup.create(defaultFooterMap), session);
				defaultFooterquery.setStart(0);
				SearchResult defaultFooterresult = defaultFooterquery.getResult();

				for (Hit hit : defaultFooterresult.getHits()) {
					ValueMap Prop = hit.getProperties();
					Date astartdate = null;
					Date aenddate = null;
					Date tdate = null;
					Date pubdate = null;
					boolean bpubdate = true;
					
					if (Prop.get(TDDConstants.PUBLISH_DATE) != null ) {
						pubdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.PUBLISH_DATE).toString());
						if (currDate.before(pubdate)) {
							bpubdate = false;
						}
					}


					if (Prop.get(TDDConstants.PARTNER_NAME) != null && bpubdate) {

									if (Prop.get(TDDConstants.START_DATE) != null)
									{
										astartdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.START_DATE).toString());
									}
									if (Prop.get(TDDConstants.END_DATE) != null)	{
										aenddate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.END_DATE).toString());
									}

									tdate =ImportantInformationHelper.INSTANCE.getDate(ticketTypes.get(0).getDate());

									if (ImportantInformationHelper.INSTANCE.compareDates(tdate,astartdate,aenddate)) {

										if (Prop.get(TDDConstants.IMPORTANT_INFO_TEXT) != null ) {
											String infotext = Prop.get(TDDConstants.IMPORTANT_INFO_TEXT).toString();
											footerList.add(infotext);
											break;
										}

									}

								}

				}
				
				
				if (footerList != null && !footerList.isEmpty() && footerList.size()<2){
					linkedHashSet.addAll(footerList);
				} else {
					linkedHashSet.add(TDDConstants.DEFAULT_FOOTER_TEXT);
				}
				
			}
		}
		catch (Exception e)
		{
			LOG.error("Exception: Error while parsing Footer Information:", e);
			linkedHashSet.add(TDDConstants.DEFAULT_FOOTER_TEXT);
		}


		return linkedHashSet;
	}



}

package com.amtrak.tdd.schedulers;

import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrRecursiveRemove;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;

/**
 * @author AMTRAK
 *
 */
@Properties({
		@Property(name = Constants.SERVICE_DESCRIPTION,
					value = "Component for running Historical Information Archiver job"),
		@Property(name = Constants.SERVICE_VENDOR,
					value = "Amtrak.com"),
		@Property(name = "Archive Start Period",
					value = "-6M",
					description = "The Period since when(eg since 6 months) the alerts has to be deleted"),
		@Property(name = "Archive End Period",
					value = "-100M",
					description = "The Period till when(eg since 100 months) the alerts needs to be deleted"),
		@Property(name = "Advisory List",
					value = "ServiceAdvisory,StationAdvisory,PartnerInformation,RBDInformation,FarePlanInformation,FooterInformation,TicketTypeInformation,GeneralInformation,TicktypeAdvisory,PaymentInformation",
					description = "Represents comma seperated nodes to be deleted from content"),
		@Property(name = "Advisory Locator Format",
					value = "/content/tdd/FORMATSTR/jcr:content/alertslist",
					description = "This is a field to denote the location of the advisory's content path"),
		@Property(name = "Sales Receipt Advisory Locator Format",
					value = "/content/salesreceipt/FORMATSTR/jcr:content/alertslist",
					description = "This is a field to denote the location of the sales advisory's content path"),
		@Property(name = "Refund Receipt Receipt Advisory Locator Format",
					value = "/content/refundreceipt/FORMATSTR/jcr:content/alertslist",
					description = "This is a field to denote the location of the refund advisory's content path"),
		@Property( name = "scheduler.expression",
					value = "0 51 12 ? * SUN"),

		@Property( name="scheduler.concurrent",
					boolValue=true)
	})

@Component(label = "Amtrak : Historical Information Archiver",
			description = "This component is for running Historical Information Archiver",
			immediate = true,
			metatype = true)

@Service(value = Runnable.class)

public class HistoricalInformationArchiver implements Runnable {

	private static final Logger LOGGER = LoggerFactory.getLogger(HistoricalInformationArchiver.class);
	private static final String CLEANUP_HIST_NODES = "com.amtrak.tdd.scheduler.HistoricalInformationArchiver";
	private static final String CLEANUP_HIST_START_PERIOD = "Archive Start Period";
	private static final String CLEANUP_HIST_END_PERIOD = "Archive End Period";
	private static final String LISTALERT_ADVISORY = "Advisory List";
	private static final String LISTALERT_ADVISORY_FORMAT_LOCATOR = "Advisory Locator Format";
	private static final String SALESLISTALERT_ADVISORY_FORMAT_LOCATOR = "Sales Receipt Advisory Locator Format";
	private static final String REFUNDLISTALERT_ADVISORY_FORMAT_LOCATOR = "Refund Receipt Receipt Advisory Locator Format";
	private static final String FORMATSTR = "FORMATSTR";
	private static final String LEGACYPREFIX = "prop.";
	private static final JcrRecursiveRemove jcrRecursiveRemove = new JcrRecursiveRemove();

	private Session session;
	private ResourceResolver rr;
	private String archiveLowerBound;
	private String archiveUpperBound;
	private String advisoryNameList;
	private String scheduleExp;
	private String advisoryFormatString;
	private String salesadvisoryFormatString;
	private String refundadvisoryFormatString;

	@Reference
	private Scheduler scheduler;

	@Reference
	protected ResourceResolverFactory resourceResolverFactory;

	@Reference
	protected QueryBuilder builder;

	@SuppressWarnings("deprecation")
	@Activate
	protected void activate(ComponentContext componentContext) {

		if (null != resourceResolverFactory) {
			try {
				rr = resourceResolverFactory.getAdministrativeResourceResolver(null);
				session = rr.adaptTo(Session.class);
				Dictionary<?, ?> config = componentContext.getProperties();
				//Retrieve the component's configurables from felix console
				scheduleExp = PropertiesUtil.toString(config.get(CLEANUP_HIST_NODES),
						PropertiesUtil.toString(config.get(LEGACYPREFIX + CLEANUP_HIST_NODES), ""));
				archiveUpperBound = PropertiesUtil.toString(config.get(CLEANUP_HIST_START_PERIOD),
						PropertiesUtil.toString(config.get(LEGACYPREFIX + CLEANUP_HIST_START_PERIOD), ""));
				archiveLowerBound = PropertiesUtil.toString(config.get(CLEANUP_HIST_END_PERIOD),
						PropertiesUtil.toString(config.get(LEGACYPREFIX + CLEANUP_HIST_END_PERIOD), ""));
				advisoryNameList = PropertiesUtil.toString(config.get(LISTALERT_ADVISORY),
						PropertiesUtil.toString(config.get(LEGACYPREFIX + LISTALERT_ADVISORY), ""));
				advisoryFormatString = PropertiesUtil.toString(config.get(LISTALERT_ADVISORY_FORMAT_LOCATOR),
						PropertiesUtil.toString(config.get(LEGACYPREFIX + LISTALERT_ADVISORY_FORMAT_LOCATOR), ""));
				salesadvisoryFormatString = PropertiesUtil.toString(config.get(SALESLISTALERT_ADVISORY_FORMAT_LOCATOR),
						PropertiesUtil.toString(config.get(LEGACYPREFIX + SALESLISTALERT_ADVISORY_FORMAT_LOCATOR), ""));
				refundadvisoryFormatString = PropertiesUtil.toString(config.get(REFUNDLISTALERT_ADVISORY_FORMAT_LOCATOR),
						PropertiesUtil.toString(config.get(LEGACYPREFIX + REFUNDLISTALERT_ADVISORY_FORMAT_LOCATOR), ""));
			}
			catch (Exception exp) {
				LOGGER.error(exp.getMessage(), exp);
			}
		}
	}

	@Override
	public void run() {
		if(validateLengthBounds()){
				//nameList containts the list of advisories that need archival
				String[] nameList = advisoryNameList.split(",");
				//Iterate through each advisory and archive its nodes
				for (String advisoryName : nameList) {
					//Construct the alert list path dynamically using namelist
					try{
							archiveNodes(advisoryFormatString.replaceAll(FORMATSTR, advisoryName));
							archiveNodes(salesadvisoryFormatString.replaceAll(FORMATSTR, advisoryName));
							archiveNodes(refundadvisoryFormatString.replaceAll(FORMATSTR, advisoryName));
					}
					catch (RepositoryException exp) {
						LOGGER.error(exp.getMessage(), exp);
					}
				}
			}
	}
		private boolean validateLengthBounds() {
			if(scheduleExp.length() > 0
					&&archiveLowerBound.length() > 0
					&& archiveUpperBound.length() > 0
					&& advisoryNameList.length() > 0) {
					return true;
				}
			return false;
		}
	@Deactivate
    protected void deactivate(ComponentContext ctx) {
		if(null != ctx){
			if(null != session)
				session.logout();
			if(null != rr)
				rr.close();
		}
    }
	private void archiveNodes(String advisoryPath) throws RepositoryException {
			//Construct a map for Query builder
		if (null != session
				&& null != builder
				&& session.nodeExists(advisoryPath)) {
			Map<String, String> map = new HashMap<>();
				//Check whether the path we are searching valid
					//advisoryPath is the path whether content alert list is stored and this QB will delete last 6M data
					map.put("path", advisoryPath);
					map.put("p.hits", "full");
					map.put("p.limit", "-1");
					map.put("1_relativedaterange.property", "enddate");
					map.put("1_relativedaterange.lowerBound", archiveLowerBound);
					map.put("1_relativedaterange.upperBound", archiveUpperBound);

					Query query = builder.createQuery(PredicateGroup.create(map), session);

					SearchResult result = query.getResult();
					Iterator<Node> resultIter = result.getNodes();

					while (resultIter.hasNext()) {
						LOGGER.debug("iterating through nodes of " + advisoryPath);
						Node node = resultIter.next();
						removeThisNode(node,advisoryPath);
					}
		}
	}

	private void removeThisNode(Node node, String advisoryPath) throws RepositoryException {
		if(null != node && session.nodeExists(node.getPath())){
			//Handling delete as warn so that deleted alert node name is logged for reporting purpose
			LOGGER.warn("deleting the alert" + node.getName() + " from the path " + advisoryPath);
			jcrRecursiveRemove.removeRecursive(node, 0);
		}
	}
}
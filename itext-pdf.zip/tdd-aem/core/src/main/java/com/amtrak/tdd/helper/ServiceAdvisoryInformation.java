package com.amtrak.tdd.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;

import javax.jcr.Session;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.tdd.jcr.ServiceCriteria;
import com.amtrak.tdd.jcr.TicketCriteria;
import com.amtrak.tdd.service.TDDConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

public class ServiceAdvisoryInformation {

	
	/** Default log. */
	private static final Logger LOG = LoggerFactory.getLogger(ServiceAdvisoryInformation.class);

	/*
	 * Default Constructor
	 */
	private ServiceAdvisoryInformation(){
        // nothing to do.
	}
	
	public static Map<String,List<String>> serviceAdvisory(List<ServiceCriteria> serviceName,List<TicketCriteria> ticketTypes,QueryBuilder qbuilder,List<String> servicenumberlist,List<String> servicenamelist, Map<String,List<String>> listmap,String informationPath, Session session) {

		try {
			
			Date currDate = new Date();
			
			// query for service alerts
			Map<String, String> servicemap = new HashMap<>();
			List<SortInformation> serviceNumberInfoList = new ArrayList<>();
			List<SortInformation> serviceNameInfoList = new ArrayList<>();
			Set<String> snumberSet = new LinkedHashSet<>();
			Set<String> snameSet = new LinkedHashSet<>();
			
			List<String> snamelist = new ArrayList<>();
			List<String> snumlist = new ArrayList<>();
			for (ServiceCriteria resobj:serviceName){
					snamelist.add(resobj.getServiceName());
					snumlist.add(resobj.getServiceNumber());
			}

			
			servicemap.put(TDDConstants.PAGE_PATH_TEXT, informationPath);
			servicemap.put(TDDConstants.NODE_TYPE_TEXT, TDDConstants.NODE_TYPE);
			servicemap.put("group.p.or", TDDConstants.TRUE_TEXT);
			servicemap.put("group.1_property", TDDConstants.SERVICE_NAME); 
			for (int i = 0; i < serviceName.size(); i++) {
				servicemap.put("group.1_property." + (i + 1) + "_value", "%" + serviceName.get(i).getServiceName() + "%");
			}
			servicemap.put("group.1_property.operation", TDDConstants.LIKE_TEXT);
			servicemap.put("group.2_property", TDDConstants.SERVICE_NUMBER);
			for (int i = 0; i < serviceName.size(); i++) {
				servicemap.put("group.2_property." + (i + 1) + "_value", "%" + serviceName.get(i).getServiceNumber() + "%");
			}
			servicemap.put("group.2_property.operation", TDDConstants.LIKE_TEXT);
			servicemap.put("group.3_property", TDDConstants.TRAIN_NAME_EXCLUDE);
			servicemap.put("group.3_property._value",TDDConstants.TEXT_EXCLUDE );
			servicemap.put("group.4_property", TDDConstants.TRAIN_NUMBER_EXCLUDE);
			servicemap.put("group.4_property._value",TDDConstants.TEXT_EXCLUDE );
			servicemap.put(TDDConstants.P_HITS_TEXT, TDDConstants.P_HITS_VALUE);
			servicemap.put(TDDConstants.P_OFFSET_TEXT, TDDConstants.P_OFFSET_VALUE);
			servicemap.put(TDDConstants.P_LIMIT_TEXT, TDDConstants.P_LIMIT_VALUE);

			Query servicequery = qbuilder.createQuery(PredicateGroup.create(servicemap), session);
			servicequery.setStart(0);
			SearchResult serviceresult = servicequery.getResult();

			for (Hit hit : serviceresult.getHits()) {
				ValueMap Prop = hit.getProperties();

				Date astartdate = null;
				Date aenddate = null;
				Date tdate = null;
				Date pubdate = null;
				boolean bpubdate = true;
				
				if (Prop.get(TDDConstants.PUBLISH_DATE) != null) {
					pubdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.PUBLISH_DATE).toString());
					if (currDate.before(pubdate)) {
						bpubdate = false;
					}
				}

				if ((Prop.get(TDDConstants.SERVICE_NAME) != null || Prop.get(TDDConstants.SERVICE_NUMBER) != null) && bpubdate) {
					for (int i = 0; i < serviceName.size(); i++) {

						if (Prop.get(TDDConstants.START_DATE) != null) {
							astartdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.START_DATE).toString());
						}
						if (Prop.get(TDDConstants.END_DATE) != null) {
							aenddate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.END_DATE).toString());
						}
						tdate =ImportantInformationHelper.INSTANCE.getDate(serviceName.get(i).getOriginStationCriteria().getDate());

						if (ImportantInformationHelper.INSTANCE.compareDates(tdate,astartdate,aenddate)) {								

							Boolean display = true;
							Boolean servicenumberinfo = false;

							if ((Prop.get(TDDConstants.SERVICE_NAME) != null) && display) {
								if (serviceName.get(i)!= null && serviceName.get(i).getServiceName()!= null){
									if (Prop.get(TDDConstants.TRAIN_NAME_EXCLUDE) != null && Prop.get(TDDConstants.TRAIN_NAME_EXCLUDE).toString().equalsIgnoreCase(TDDConstants.TEXT_EXCLUDE) ) {
										display =ImportantInformationHelper.INSTANCE.checkExcludeServiceMatch(Prop.get(TDDConstants.SERVICE_NAME).toString(),snamelist);
									} else {
										display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.SERVICE_NAME).toString(),serviceName.get(i).getServiceName());
									}
								}

							}
							if ((Prop.get(TDDConstants.SERVICE_NUMBER) != null) && display) {
								if (serviceName.get(i)!= null && serviceName.get(i).getServiceNumber()!= null){
									if (Prop.get(TDDConstants.TRAIN_NUMBER_EXCLUDE) != null && Prop.get(TDDConstants.TRAIN_NUMBER_EXCLUDE).toString().equalsIgnoreCase(TDDConstants.TEXT_EXCLUDE) ) {
										display =ImportantInformationHelper.INSTANCE.checkExcludeServiceMatch(Prop.get(TDDConstants.SERVICE_NUMBER).toString(),snumlist);
									} else{
										display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.SERVICE_NUMBER).toString(),serviceName.get(i).getServiceNumber());
									}
									servicenumberinfo = true;
								}


							}
							if ((Prop.get(TDDConstants.DEPART_STATION) != null) && display) {
								if (serviceName.get(i)!= null && serviceName.get(i).getOriginStationCriteria()!= null && serviceName.get(i).getOriginStationCriteria().getStationName() != null){
									display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.DEPART_STATION).toString(),serviceName.get(i).getOriginStationCriteria().getStationName());
								}

							}
							if ((Prop.get(TDDConstants.ARRIVE_STATION) != null) && display) {
								if (serviceName.get(i)!= null && serviceName.get(i).getDestinationStationCriteria()!= null && serviceName.get(i).getDestinationStationCriteria().getStationName() != null){
									display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.ARRIVE_STATION).toString(),serviceName.get(i).getDestinationStationCriteria().getStationName());
								}

							}
							if ((Prop.get(TDDConstants.TICKET_TYPE) != null) && display) {
								if (ticketTypes.get(0)!= null && ticketTypes.get(0).getTicketType()!= null){
									if (Prop.get(TDDConstants.TICKET_TYPE) instanceof String[]){
										display =ImportantInformationHelper.INSTANCE.compareResString((String[]) Prop.get(TDDConstants.TICKET_TYPE),ticketTypes.get(0).getTicketType());
									} else {
										display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.TICKET_TYPE).toString(),ticketTypes.get(0).getTicketType());
									}
								}

							}

							if ((Prop.get(TDDConstants.IMPORTANT_INFO_TEXT) != null) && display) {
								String infotext = Prop.get(TDDConstants.IMPORTANT_INFO_TEXT).toString();
								Matcher m = TDDConstants.pattern.matcher(infotext);
								while (m.find()) {
									if (m.group(2).length()>2){
										int rank=1;
										if (Prop.get(TDDConstants.RANK_TEXT) != null){
											rank = Integer.parseInt(Prop.get(TDDConstants.RANK_TEXT).toString());
										}
										
										if(servicenumberinfo==true){
											serviceNumberInfoList.add(new SortInformation(serviceName.get(i).getOrder(),rank,infotext));
										} else {
											serviceNameInfoList.add(new SortInformation(serviceName.get(i).getOrder(),rank,infotext));
										}
									}
								}
							}

						}


					}
				}
			}

			Collections.sort(serviceNumberInfoList, new InformationComparator());
	        for (SortInformation snumberInf : serviceNumberInfoList) {
	            String infotext =snumberInf.getImpInformation();
				Matcher m = TDDConstants.pattern.matcher(infotext);

				while (m.find()) {
					if (m.group(2).length()>2){
						snumberSet.add(m.group(2));
					}
				}

	        }

			if (snumberSet.size()>0){
				servicenumberlist.addAll(snumberSet);
			}

			Collections.sort(serviceNameInfoList, new InformationComparator());
	        for (SortInformation snameInf : serviceNameInfoList) {
	            String infotext =snameInf.getImpInformation();
				Matcher m = TDDConstants.pattern.matcher(infotext);

				while (m.find()) {
					if (m.group(2).length()>2){
						snameSet.add(m.group(2));
					}
				}

	        }

			if (snameSet.size()>0){
				servicenamelist.addAll(snameSet);
			}

			listmap.put(TDDConstants.SERVICE_NUMBER_LIST_KEY,servicenumberlist);
			listmap.put(TDDConstants.SERVICE_NAME_LIST_KEY,servicenamelist);

		}catch (Exception e) {
			LOG.error("Error while parsing Service Advisory Important Information:", e);
		}


		return listmap;	
	}


}

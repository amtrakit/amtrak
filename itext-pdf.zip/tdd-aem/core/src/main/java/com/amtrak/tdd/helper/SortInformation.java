package com.amtrak.tdd.helper;

public class SortInformation{

	
	public int logicalorder;
	public int rankorder;
	private String importantinfo = "";

	public SortInformation(int logicalorder,int rankorder, String importantinfo) {
	    this.logicalorder=logicalorder;
	    this.rankorder=rankorder;
	    this.importantinfo=importantinfo;
	}

	public int getLogicalOrder() {
	    return logicalorder;
	}
	public void setLogicalOrder(int logicalorder) {
		this.logicalorder = logicalorder;
	}


	public int getRankOrder() {
	    return rankorder;
	}
	public void setRankOrder(int rankorder) {
		this.rankorder = rankorder;
	}
	
	public String getImpInformation() {
	    return importantinfo;
	}
	public void setImpInformation(String importantinfo) {
		this.importantinfo = importantinfo;
	}

}

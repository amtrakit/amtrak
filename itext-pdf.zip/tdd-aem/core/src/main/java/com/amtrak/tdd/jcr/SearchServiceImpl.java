package com.amtrak.tdd.jcr;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.tdd.helper.FarePlanInformation;
import com.amtrak.tdd.helper.FooterInformation;
import com.amtrak.tdd.helper.GeneralInformation;
import com.amtrak.tdd.helper.MultiRidePartnerIdentifier;
import com.amtrak.tdd.helper.PartnerInformation;
import com.amtrak.tdd.helper.RBDInformation;
import com.amtrak.tdd.helper.ServiceAdvisoryInformation;
import com.amtrak.tdd.helper.StationAdvisoryInformation;
import com.amtrak.tdd.helper.TicketTypeInformation;
import com.amtrak.tdd.service.TDDConstants;
import com.day.cq.search.QueryBuilder;

//This is a component so it can provide or consume services
@Component
@Service
public class SearchServiceImpl implements SearchService {



	/** Default log. */
	private static final Logger LOG = LoggerFactory.getLogger(SearchServiceImpl.class);

	private Session session;

	// Inject a Sling ResourceResolverFactory
	@Reference
	private ResourceResolverFactory resolverFactory;

	@Override
	public List<String> SearchCQForContent(ResourceResolver resourceResolver, QueryBuilder qbuilder,List<BaseCriteria> rdetails) {

		List<String> list = new ArrayList<>();
		Set<String> linkedHashSet = new LinkedHashSet<>();
		List<String> servicenumberlist = new ArrayList<>();
		List<String> servicenamelist = new ArrayList<>();
		Map<String,List<String>> listmap =new HashMap<>();

		try {
			List<StationCriteria> originStation = new ArrayList<>();
			List<StationCriteria> destinationStation = new ArrayList<>();
			List<PartnerCriteria> partnerId = new ArrayList<>();
			List<ServiceCriteria> serviceName = new ArrayList<>();
			List<RBDCriteria> rbdCode = new ArrayList<>();
			List<TicketCriteria> ticketTypes = new ArrayList<>();
			List<FarePlanCriteria> fareplanCode = new ArrayList<>();


			for (BaseCriteria resobj:rdetails){
				if(resobj instanceof StationCriteria){
					if (((StationCriteria) resobj).getStationType().equals(StationType.ORIGIN)){
						originStation.add((StationCriteria) resobj);
					}
				}
				if(resobj instanceof StationCriteria){
					if (((StationCriteria) resobj).getStationType().equals(StationType.DESTINATION)){
						destinationStation.add((StationCriteria) resobj);
					}
				}
				if(resobj instanceof ServiceCriteria){
					serviceName.add((ServiceCriteria) resobj);
				}
				if(resobj instanceof RBDCriteria){
					rbdCode.add((RBDCriteria) resobj);
				}
				if(resobj instanceof FarePlanCriteria){
					fareplanCode.add((FarePlanCriteria) resobj);
				}
				if(resobj instanceof PartnerCriteria){
					partnerId.add((PartnerCriteria) resobj);
				}
				if(resobj instanceof TicketCriteria){
					ticketTypes.add((TicketCriteria) resobj);
				}

			}


			// Invoke the adaptTo method to create a Session
			session = resourceResolver.adaptTo(Session.class);

			 if(!ticketTypes.isEmpty() && ticketTypes.get(0).getTicketType()!= null){
				 if ( ticketTypes.get(0).getTicketType().equalsIgnoreCase(TDDConstants.TEN_RIDE) || ticketTypes.get(0).getTicketType().equalsIgnoreCase(TDDConstants.SIX_RIDE) || ticketTypes.get(0).getTicketType().equalsIgnoreCase(TDDConstants.MONTHLY_RIDE)){
					 String multiRidePartnerName= MultiRidePartnerIdentifier.multiRidePartnerName(originStation,destinationStation,qbuilder,TDDConstants.MULTIRIDE_PARTNER_IDENTIFIER_PATH,session);
					 if (multiRidePartnerName != null){
							if (partnerId != null && partnerId.size() > 0 ) {
								for (int i = 0; i < partnerId.size(); i++) {
									 partnerId.get(i).setPartnerName(multiRidePartnerName);
								} 
							}

					 }
				 }

			 }
			
			
			
			if (originStation != null && originStation.size() > 0 ) {
				linkedHashSet =  StationAdvisoryInformation.stationAdvisory(originStation,destinationStation,qbuilder,linkedHashSet,TDDConstants.STATION_ADVISORY_PATH,session);
			}
			if (serviceName != null && serviceName.size() > 0 ) {
				ServiceAdvisoryInformation.serviceAdvisory(serviceName,ticketTypes,qbuilder,servicenumberlist,servicenamelist,listmap,TDDConstants.SERVICE_ADVISORY_PATH,session);
				if(!listmap.isEmpty() && listmap.containsKey(TDDConstants.SERVICE_NUMBER_LIST_KEY)){
					servicenumberlist = listmap.get(TDDConstants.SERVICE_NUMBER_LIST_KEY);
					for (String snumber:servicenumberlist){
						linkedHashSet.add(snumber);
					}
				}
			}
			if (rbdCode != null && rbdCode.size() > 0 ) {
				linkedHashSet =  RBDInformation.rbdInformation(rbdCode,ticketTypes,qbuilder,linkedHashSet,TDDConstants.RBD_INFORMATION_PATH,session);
			}
			if (fareplanCode != null && fareplanCode.size() > 0 ) {
				linkedHashSet =  FarePlanInformation.farePlanInformation(fareplanCode,ticketTypes,qbuilder,linkedHashSet,TDDConstants.FARE_PLAN_INFORMATION_PATH,session);
			}
			if(!listmap.isEmpty() && listmap.containsKey(TDDConstants.SERVICE_NAME_LIST_KEY)){
				servicenamelist = listmap.get(TDDConstants.SERVICE_NAME_LIST_KEY);
				for (String sname:servicenamelist){
					linkedHashSet.add(sname);
				}
			}

			if (ticketTypes != null && ticketTypes.size() > 0 ) {
				linkedHashSet =  TicketTypeInformation.ticketTypeInformation(ticketTypes,qbuilder,linkedHashSet,TDDConstants.TICKET_TYPE_INFORMATION_PATH,session);
			}
			linkedHashSet =  PartnerInformation.partnerInformation(partnerId,ticketTypes,qbuilder,linkedHashSet,TDDConstants.PARTNER_INFORMATION_PATH,session);

			linkedHashSet =  GeneralInformation.generalInformation(ticketTypes,TDDConstants.DOCUMENT_REQUEST,qbuilder,linkedHashSet,TDDConstants.GENERAL_INFORMATION_PATH,session);

			linkedHashSet =  FooterInformation.footerInformation(partnerId,ticketTypes,qbuilder,linkedHashSet,TDDConstants.FOOTER_INFORMATION_PATH,session);

			list.addAll(linkedHashSet);
		} catch (Exception e) {
			LOG.error("Error while parsing Important Information main method:", e);
			// close the session
			if (session != null){
			session.logout();
			}
		} 
		return list;
	}

	

}
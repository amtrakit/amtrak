package com.amtrak.tdd.service;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.BadElementException;


public class Barcode4j {

	private static final Logger LOG = LoggerFactory.getLogger(Barcode4j.class);

	/*
	 * Default Constructor
	 */
	public Barcode4j(){
        // nothing to do.
	}
	
	
	 public String oneDBarCode(String value){		 
	     try {
	    	 com.itextpdf.text.pdf.Barcode39 code39ext = new com.itextpdf.text.pdf.Barcode39();
	    	 code39ext.setCode(value);
	    	 code39ext.setStartStopText(false);
	    	 code39ext.setExtended(true);
	    	 java.awt.Image rawImage = code39ext.createAwtImage(java.awt.Color.BLACK, java.awt.Color.WHITE);
	    	 BufferedImage outImage = new BufferedImage(rawImage.getWidth(null), rawImage.getHeight(null), BufferedImage.TYPE_INT_RGB);
	    	 outImage.getGraphics().drawImage(rawImage, 0, 0, null);
	    	 ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
	    	 ImageIO.write(outImage, "png", bytesOut);
	    	 bytesOut.flush();
	    	 byte[] pngImageData = bytesOut.toByteArray();
	    	 return Arrays.toString(pngImageData);
		} catch (Exception e) {
			LOG.error("oneDBarCode: Error while parsing the String passed:"+ value, e);
			return null;
		}	
	 }
	 public com.itextpdf.text.Image qrBarCodeOld(String value){		 
	     try {
	    	 com.itextpdf.text.pdf.BarcodeQRCode qrcode = new com.itextpdf.text.pdf.BarcodeQRCode(value, 1, 1, null);
			 return qrcode.getImage();
		} catch (BadElementException e) {
			LOG.error("qrBarCodeOld: Error while parsing the String passed:"+ value, e);
			return null;
		}		 
	 }
	 	 
	 public byte[] getBarcodeInter25(String value){		
		 com.itextpdf.text.pdf.BarcodeInter25 inter25BarCode = new com.itextpdf.text.pdf.BarcodeInter25();	
	     try {	    	 
	    	 inter25BarCode.setCode(value);
	    	 java.awt.Image rawImage = inter25BarCode.createAwtImage(java.awt.Color.BLACK, java.awt.Color.WHITE);
	    	 BufferedImage outImage = new BufferedImage(rawImage.getWidth(null), rawImage.getHeight(null), BufferedImage.TYPE_INT_RGB);
	    	 Graphics g2 = outImage.getGraphics();
	    	 g2.drawImage(rawImage, 0,0,null);
	    	 g2.dispose();
	    	 ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
	    	 ImageIO.write(outImage, "png", bytesOut);
	    	 return getRefinedImage(outImage);	
		} catch (Exception e) {
			LOG.error("getBarcodeInter25: Error while parsing the String passed:"+ value, e);
			return null;
		}		
	 }
	 
	 public byte[] qrBarCode(String value){		
		 com.itextpdf.text.pdf.BarcodeQRCode qrcode = new com.itextpdf.text.pdf.BarcodeQRCode(value, 1, 1, null);	    	 
	     try {	    	 
	    	 java.awt.Image rawImage = qrcode.createAwtImage(java.awt.Color.BLACK, java.awt.Color.WHITE);
	    	 BufferedImage outImage = new BufferedImage(rawImage.getWidth(null), rawImage.getHeight(null), BufferedImage.TYPE_INT_RGB);
	    	 Graphics g2 = outImage.getGraphics();
	    	 g2.drawImage(rawImage, 0,0,null);
	    	 g2.dispose();
	    	 return getRefinedImage(outImage);	
		} catch (Exception e) {
			LOG.error("qrBarCode: Error while parsing the String passed:"+ value, e);
			return null;
		}		
	 }
	 
	 private static byte[] getRefinedImage(BufferedImage img) {
			int size = 300;
			ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
			try {
				int width = img.getWidth();
				int height = img.getHeight();
				int data[] = new int[width * height];
				img.getRGB(0,0, width, height, data, 0, width);
			
				int[] resized = new int[size * size];
				float ratio = (width > height) ? (float) height / size : (float) width / size;
				float hr = ratio / 2;
				int i, j, k, l, m;
				for (int x = 0; x < size; x ++) {
					for (int y = 0; y < size; y ++) {
					i = (int) (x * ratio);
					j = (int) (y * ratio);
					k = (int) (i + hr);
					l = (int) (j + hr);
						for (int p = 0; p < 3; p ++) {
							m = 0xFF << (p * 8);
							resized[x + y * size] |= (
							(data[i + j * width] & m) +
							(data[k + j * width] & m) +
							(data[i + l * width] & m) +
							(data[k + l * width] & m) >> 2) & m;
						}
					}
				}
			
				BufferedImage img1 = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
				img1.setRGB(0, 0, size, size, resized, 0, size);
				ImageIO.write(img1, "png", bytesOut);
				bytesOut.flush();		    	 
			} catch (IOException e) {
				LOG.error("IOException:getRefinedImage, Error while parsing image:", e);
			}catch (Exception e) {
				LOG.error("Exception:getRefinedImage, Error while parsing image:", e);
			}
			return bytesOut.toByteArray();
		}
}

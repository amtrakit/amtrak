package com.amtrak.tdd.jcr;

public enum ImportantInformation {

	ORIGIN_STATION,
	DESTINATION_STATION,
	PARTNER_ID,
	SERVICE_NAME,
	SERVICE_NUMBER,
	START_DATE,
	END_DATE,
	TICKET_TYPE,
	RBD,
	FARE_PLAN_CODE;
	
}

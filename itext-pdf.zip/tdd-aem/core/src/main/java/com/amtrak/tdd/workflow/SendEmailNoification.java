package com.amtrak.tdd.workflow;

/**
 * 
 * @author kganiga
 * 
 */
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Value;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.email.EmailService;
import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.commons.Externalizer;

@Component
@Service
@Properties({
		@Property(name = Constants.SERVICE_DESCRIPTION, value = "A custom workflow to Send Email Notifications to Workflow Initiator."),
		@Property(name = "process.label", value = "Sends Email Notification To Initiator") })

public class SendEmailNoification implements WorkflowProcess {

	private static final Logger LOGGER = LoggerFactory.getLogger(SendEmailNoification.class);

	private static final String WORKFLOW_INITIATOR_EMAIL = "./profile/email";
	private static final String WORKFLOW_INITIATOR_NAME = "./profile/givenName";

	@Reference
	private EmailService emailService;

	@Reference
	private ResourceResolverFactory resourceResolverFactory;

	@Reference
	Externalizer externalizer;

	@Override
	public final void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaData)
			throws WorkflowException {

		final WorkflowData workflowData = workItem.getWorkflowData();
		final String type = workflowData.getPayloadType();

		if (!"JCR_PATH".equals(type)) {
			return;
		}
		String emailTemplate = metaData.get("PROCESS_ARGS", String.class);

		if (emailTemplate == null) {
			LOGGER.warn("Invalid process arguments, returning");
			return;
		}

		String payloadPath = workflowData.getPayload().toString();

		ResourceResolver resourceResolver = null;
		Map<String, Object> param = new HashMap<>();
		param.put(ResourceResolverFactory.SUBSERVICE, "workflowServiceRep");
		try {
			resourceResolver = resourceResolverFactory.getServiceResourceResolver(param);
			payloadPath = externalizer.publishLink(resourceResolver, payloadPath + ".html");

			Map<String, String> emailParams = new HashMap<>();
			emailParams.put("payloadPath", payloadPath);

			Map<String, String> wfParams = getAdditionalParams(workItem, resourceResolver);
			if (wfParams != null) {
				emailParams.putAll(wfParams);
			}

			String emailTo = getUserInfo(workItem, resourceResolver, WORKFLOW_INITIATOR_EMAIL);

			List<String> emailSentList = emailService.sendEmail(emailTemplate, emailParams, emailTo);

			if (emailSentList.isEmpty()) {
				LOGGER.info("Email sent successfully to {} recipients", emailTo.length());
			} else {
				LOGGER.error("Email sent failed");
			}

		} catch (LoginException e) {
			LOGGER.error("Could not acquire a ResourceResolver object from the Workflow Session's JCR Session: {}", e);
		}
	}

	protected String getUserInfo(WorkItem workItem, ResourceResolver resourceResolver, String param) {
		String initiator;
		Value[] valArr = null;

		String strUsrInfo = "";
		initiator = workItem.getWorkflow().getInitiator();
		UserManager userManager = resourceResolver.adaptTo(UserManager.class);
		try {
			if (null != userManager) {
				Authorizable authorizable = userManager.getAuthorizable(initiator);

				if (authorizable.hasProperty(param)) {
					valArr = authorizable.getProperty(param);
				}

				for (Value val : valArr) {
					strUsrInfo += val;
				}
			}

		} catch (RepositoryException e) {
			LOGGER.error(e.getMessage(), e);
		}

		return strUsrInfo;

	}

	protected Map<String, String> getAdditionalParams(WorkItem workItem, ResourceResolver resourceResolver) {
		String recipientEmail = getUserInfo(workItem, resourceResolver, WORKFLOW_INITIATOR_EMAIL);
		String receipientName = getUserInfo(workItem, resourceResolver, WORKFLOW_INITIATOR_NAME);
		Map<String, String> wfParams = new HashMap<>();

		try {
			wfParams.put("workflowStep", workItem.getNode().getTitle());
			wfParams.put("workflowName", workItem.getWorkflow().getWorkflowModel().getTitle());
			wfParams.put("timeStamp", Calendar.getInstance().getTime().toString());
			wfParams.put("workflowInitiator", receipientName);
			wfParams.put("recipientEmail", recipientEmail);
		} catch (Exception e) {
			LOGGER.warn("Error getting workflow title and workflow step title {}", e);
		}

		return wfParams;
	}

}

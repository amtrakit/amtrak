package com.amtrak.tdd.jcr;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.tdd.helper.GeneralInformation;
import com.amtrak.tdd.helper.PaymentInformation;
import com.amtrak.tdd.service.TDDConstants;
import com.day.cq.search.QueryBuilder;


@Component
@Service
public class RefundReceiptServiceImpl implements RefundReceiptService {


	/** Default log. */
	private static final Logger LOG = LoggerFactory.getLogger(SalesReceiptServiceImpl.class);

	private Session session;

	// Inject a Sling ResourceResolverFactory
	@Reference
	private ResourceResolverFactory resolverFactory;


	@Override
	public List<String> SearchCQForRefundReceiptContent(ResourceResolver resourceResolver, QueryBuilder qbuilder,List<BaseCriteria> rdetails) {

		List<String> list = new ArrayList<>();
		Set<String> linkedHashSet = new LinkedHashSet<>();

		try {
			List<TicketCriteria> ticketTypes = new ArrayList<>();
			List<PaymentCriteria> paymentCode = new ArrayList<>();

			for (BaseCriteria resobj:rdetails){
				if(resobj instanceof PaymentCriteria){
					paymentCode.add((PaymentCriteria) resobj);
				}
				if(resobj instanceof TicketCriteria){
					ticketTypes.add((TicketCriteria) resobj);
				}

			}

			// Invoke the adaptTo method to create a Session
			session = resourceResolver.adaptTo(Session.class);

			if (paymentCode != null && paymentCode.size() > 0 ) {
				linkedHashSet =  PaymentInformation.paymentInformation(paymentCode,TDDConstants.CANCEL_REFUND,ticketTypes,qbuilder,linkedHashSet,TDDConstants.REFUND_RECEIPT_PAYMENT_CODE_INFORMATION_PATH,session);
			}

			linkedHashSet =  GeneralInformation.generalInformation(ticketTypes,TDDConstants.CANCEL_REFUND,qbuilder,linkedHashSet,TDDConstants.REFUND_RECEIPT_GENERAL_INFORMATION_PATH,session);


			list.addAll(linkedHashSet);
		} catch (Exception e) {
			LOG.error("Error while parsing Sales receipt Important Information main method:", e);
		} finally {
			// close the session
			if (session != null){
			session.logout();
			}

		}
		return list;
	}

}

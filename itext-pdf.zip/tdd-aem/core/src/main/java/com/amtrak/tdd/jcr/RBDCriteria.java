package com.amtrak.tdd.jcr;

public class RBDCriteria extends BaseCriteria{

	private ServiceCriteria serviceCriteria;
	private String rbdCode;
	
	public RBDCriteria() {
        // nothing to do.
	}
	public RBDCriteria(ServiceCriteria serviceCriteria, String rbdCode) {
		super();
		this.serviceCriteria = serviceCriteria;
		this.rbdCode = rbdCode;
	}

	public ServiceCriteria getServiceCriteria() {
		return serviceCriteria;
	}
	public void setServiceCriteria(ServiceCriteria serviceCriteria) {
		this.serviceCriteria = serviceCriteria;
	}
	public String getRbdCode() {
		return rbdCode;
	}
	public void setRbdCode(String rbdCode) {
		this.rbdCode = rbdCode;
	}
	public String getOriginStation(){
		return serviceCriteria.getOriginStationCriteria().getStationName();
	}
	public String getOriginDate(){
		return serviceCriteria.getOriginStationCriteria().getDate();
	}
	public String getDestinationStation(){
		return serviceCriteria.getDestinationStationCriteria().getStationName();
	}
	public String getDestinationDate(){
		return serviceCriteria.getDestinationStationCriteria().getDate();
	}
	
}

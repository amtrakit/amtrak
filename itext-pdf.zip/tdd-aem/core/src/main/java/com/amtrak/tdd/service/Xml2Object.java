package com.amtrak.tdd.service;

import javax.xml.bind.JAXBContext;

/**
 * Interface to convert Xml messages to Objects.
 */

public interface Xml2Object {
	
	/**
	 * Gets an Object of the specified class type from the Xml string message.
	 * 
	 * @param message The Xml message.
	 * @param clazz The class type.
	 * @param schemaName The schema name.
	 * @return The object of the specified class type.
	 */
	public Object getMessageObject(String message, Class<?> clazz, String schemaName);
	public JAXBContext getJAXBContext(String packageName);
}

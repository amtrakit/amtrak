package com.amtrak.tdd.service;

public class Xml2ObjectException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8257545278962759812L;

	public Xml2ObjectException() {
		super();
	}

	public Xml2ObjectException(String message) {
		super(message);
	}

	public Xml2ObjectException(Throwable cause) {
		super(cause);
	}

	public Xml2ObjectException(String message, Throwable cause) {
		super(message, cause);
	}

}

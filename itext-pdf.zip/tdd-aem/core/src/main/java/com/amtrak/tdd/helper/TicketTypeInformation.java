package com.amtrak.tdd.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;

import javax.jcr.Session;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.tdd.jcr.TicketCriteria;
import com.amtrak.tdd.service.TDDConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

public class TicketTypeInformation {
	
	/** Default log. */
	private static final Logger LOG = LoggerFactory.getLogger(TicketTypeInformation.class);

	/*
	 * Default Constructor
	 */
	private TicketTypeInformation(){
        // nothing to do.
	}

	public static Set<String> ticketTypeInformation(List<TicketCriteria> ticketTypes,QueryBuilder qbuilder,Set<String> linkedHashSet, String informationPath, Session session) {

		try {
			Date currDate = new Date();
			Map<String, String> ttypemap = new HashMap<>();
			List<SortInformation> ticketInfoList = new ArrayList<>();

			ttypemap.put(TDDConstants.PAGE_PATH_TEXT, informationPath);
			ttypemap.put(TDDConstants.NODE_TYPE_TEXT, TDDConstants.NODE_TYPE);
			ttypemap.put(TDDConstants.PROPERTY_TEXT, TDDConstants.TICKET_TYPE); // combine this group with OR
			for (int i = 0; i < ticketTypes.size(); i++) {
				ttypemap.put("property." + (i + 1) + "_value", "%" + ticketTypes.get(i).getTicketType() + "%");
			} 
			ttypemap.put(TDDConstants.PROPERTY_DOT_OPERATION_TEXT, TDDConstants.LIKE_TEXT);
			ttypemap.put(TDDConstants.P_HITS_TEXT, TDDConstants.P_HITS_VALUE);
			ttypemap.put(TDDConstants.P_OFFSET_TEXT, TDDConstants.P_OFFSET_VALUE);
			ttypemap.put(TDDConstants.P_LIMIT_TEXT, TDDConstants.P_LIMIT_VALUE);

			Query ttypequery = qbuilder.createQuery(PredicateGroup.create(ttypemap), session);
			ttypequery.setStart(0);
			SearchResult ttyperesult = ttypequery.getResult();

			for (Hit hit : ttyperesult.getHits()) {
				ValueMap Prop = hit.getProperties();

				Date astartdate = null;
				Date aenddate = null;
				Date tdate = null;
				Date pubdate = null;
				boolean bpubdate = true;
				
				if (Prop.get(TDDConstants.PUBLISH_DATE) != null ) {
					pubdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.PUBLISH_DATE).toString());
					if (currDate.before(pubdate)) {
						bpubdate = false;
					}
				}

				if (Prop.get(TDDConstants.TICKET_TYPE) != null && bpubdate) {
					for (int i = 0; i < ticketTypes.size(); i++) {
						
						String[] ttypeArray = null;
						String ttype= null;

						if (Prop.get(TDDConstants.TICKET_TYPE) instanceof String[]){
							ttypeArray = (String[]) Prop.get(TDDConstants.TICKET_TYPE);
						
						} else {
							 ttype= Prop.get(TDDConstants.TICKET_TYPE).toString();
							 ttypeArray = ttype.split(TDDConstants.SPLIT_STRING_TEXT);
						}


						for (int j=0;j<ttypeArray.length;j++){
							if(ttypeArray[j].equals(ticketTypes.get(i).getTicketType())){


								if (Prop.get(TDDConstants.START_DATE) != null) {
									astartdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.START_DATE).toString());
								}
								if (Prop.get(TDDConstants.END_DATE) != null)	{
									aenddate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.END_DATE).toString());
								}
								tdate =ImportantInformationHelper.INSTANCE.getDate(ticketTypes.get(i).getDate());

								if (ImportantInformationHelper.INSTANCE.compareDates(tdate,astartdate,aenddate)) {

									if (Prop.get(TDDConstants.IMPORTANT_INFO_TEXT) != null) {
										String infotext = Prop.get(TDDConstants.IMPORTANT_INFO_TEXT).toString();
										int rank=1;
										if (Prop.get(TDDConstants.RANK_TEXT) != null){
											rank = Integer.parseInt(Prop.get(TDDConstants.RANK_TEXT).toString());
										}
										ticketInfoList.add(new SortInformation(ticketTypes.get(i).getOrder(),rank,infotext));
									}
								}
							}

						}
					}

				}

			}
			Collections.sort(ticketInfoList, new InformationComparator());
	        for (SortInformation ticketInf : ticketInfoList) {
	            String infotext =ticketInf.getImpInformation();
				Matcher m = TDDConstants.pattern.matcher(infotext);

				while (m.find()) {
					if (m.group(2).length()>2){
						linkedHashSet.add(m.group(2));
					}
				}

	        }


		} catch (Exception e) {
			LOG.error("Exception:Error while parsing Ticket Type Information:", e);
		}

		return linkedHashSet;
	}


}

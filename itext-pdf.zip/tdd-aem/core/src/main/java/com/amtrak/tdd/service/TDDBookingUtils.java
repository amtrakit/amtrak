/**
 * THIS PROGRAM IS CONFIDENTIAL AND PROPRIETARY TO AMTRAK AND 

 * MAY NOT BE REPRODUCED, PUBLISHED OR DISCLOSED TO OTHERS WITHOUT AUTHORIZATION.  

 * COPYRIGHT � AMTRAK.  THIS WORK IS UNPUBLISHED.


 */
package com.amtrak.tdd.service;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket;

/**
 * Utility class providing methods for
 * 	- Generating PDF
 *  - Generating Receipt HTML
 * @author 90000781
 *
 */
public class TDDBookingUtils {

	// Define the Logger
	private static final Logger LOG = LoggerFactory.getLogger(TDDBookingUtils.class);
	
	/**
	 * Constructor
	 */
	private TDDBookingUtils(){
        // nothing to do.
	}
		    
    /*
     * Checks if the fare plan is of type bulk. This is
     * done by iterating through all the segments and checking
     * if the fareplan in the PricingItem is of type "XX*" 
      */
     public static boolean isBulkFarePlan(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ) {

	    LOG.debug(" entering isBulkFarePlan(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

    	 boolean returnFlag = false;
    	 
    	 FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = 
    			 formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();
    	 /*
    	  * Some valid TDD requests do not have itinerary in them for example
    	  * Cancel receipts.
    	  */

    	 if(itineraryRQ == null){
                 return false;
    	 }     
         List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
         for(java.util.Iterator<LogicalTrip> l=logicalTripListRQ.iterator();l.hasNext();){
        	 List<com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment> 
        	 segmentList = l.next().getSegments().getSegment();
        	 //Iterate through each segment
        	 for(Iterator<Segment> s = segmentList.iterator();s.hasNext(); ){     
        		 Segment segment = new Segment();
        		 segment = (Segment)s.next();
        		 if(segment.getTickets()!=null){
        			 if(segment.getTickets().getTicket()!=null && !(new FormatPrintCommonFunctions().serviceFee(segment))){                           
        				 List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket> ticketList = segment.getTickets().getTicket();                                                  
        				 for(Iterator<Ticket> t=ticketList.iterator();t.hasNext();) {                                
        					 Ticket ticket = new Ticket();
        					 ticket = (Ticket)t.next();
        					 if(ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null &&
        							 ticket.getPricingItem().getFarePlans().getFarePlan().get(0) != null) {
        						 if(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().substring(0, 2).equalsIgnoreCase("XX")){
        							 returnFlag = true;              
        						 }
        					 }
        				 }                                                               
        			 }   
        		 } 
        		 
        	 }
         } 
	    LOG.debug("exiting isBulkFarePlan(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

         return returnFlag;
     	}
     
     
     /*
      * Checks whether the request is for CCJPA or not 
      */
     
     public static boolean isCCJPARequest(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ) {

	    LOG.debug("entering isCCJPARequest(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

     	 boolean ccjpaRequest = true;
     	 
     	 FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = 
     			 formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();
     	 List<String> ccjpaStations = getCCJPAStations();     	
     	 
     	 if(itineraryRQ == null){
                 return false;
    	 }     
         List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
         if(logicalTripListRQ == null || (logicalTripListRQ != null && logicalTripListRQ.size() == 0)){
             return false;
         } 
         for(java.util.Iterator<LogicalTrip> l=logicalTripListRQ.iterator();l.hasNext();){
        	 List<com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment> 
        	 segmentList = l.next().getSegments().getSegment();
        	 //Iterate through each segment
        	 for(Iterator<Segment> s = segmentList.iterator();s.hasNext(); ){     
        		 Segment segment = new Segment();
        		 segment = (Segment)s.next();
        		 
        		 if(segment.getTickets()!= null ){
        			 if(segment.getTickets().getTicket()!=null ){                           
        				 List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket> ticketList = segment.getTickets().getTicket();    
        				 if(ticketList == null || (ticketList != null && ticketList.size() == 0)){
        					 return false;
        				 }
        				 for(Iterator<Ticket> t=ticketList.iterator();t.hasNext();) {                                
        					 Ticket ticket = new Ticket();
        					 ticket = (Ticket)t.next();
        					 
        					 if(ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null &&
        							 ticket.getPricingItem().getFarePlans().getFarePlan().get(0) != null) {
        						 String type = ticket.getMultirideType() ;
        						 
        						 if(type != null && (TDDConstants.MULTI_MONTHLY_RIDE.equals(type.toUpperCase()) || 
        								 TDDConstants.MULTI_MULTIRIDE.equals(type.toUpperCase()))){
        							 
      							    LOG.info("Multitride");
        							 
        							 if(ccjpaStations.contains(segment.getOrigin().getCode()) && ccjpaStations.contains(segment.getDestination().getCode())){
        								 if(!"UE45".equalsIgnoreCase(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode()) && 
        										 !"UEMT".equalsIgnoreCase(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode()) ){        									 
		        							 return false;              
		        						 }        								 
            						 }else{
            							 return false;
            						 }        							 
        						 }else{
       							    LOG.debug("Single trip");

		        						 if(!"UOCC".equalsIgnoreCase(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode()) &&
		        								 !"TOAM".equalsIgnoreCase(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode()) && 
        										 !"TOAA".equalsIgnoreCase(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode())){
		        							 return false;              
		        						 }
        						 }
        						 
        					 }else{
        						 return false;   
        					 }
        				 }                                                               
        			 }else{
        				 return false;   
        			 }
        		 }else{
        			 return false; 
        		 }
        		 
        	 }
         } 
          
	    LOG.debug("exiting isCCJPARequest(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

          return ccjpaRequest;
      	}

	private static List<String> getCCJPAStations() {
		
		String ccjpastations = "ARN,RLN,RSV,SAC,DAV,SUI,MTZ,RIC,BKY,EMY,OKJ,OAC,HAY,FMT,GAC,SCC,SJC,COX,TRU,RNO,SPX,PCV,SLT,SLH,SLN,RVT,SFC,SFF,SFW,SFS,SFV,SFM,SFP";
		return  Arrays.asList(ccjpastations.split(","));		
	}
 	
}
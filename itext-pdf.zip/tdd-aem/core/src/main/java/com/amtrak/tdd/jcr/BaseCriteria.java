package com.amtrak.tdd.jcr;

public class BaseCriteria {

	private String date;
	private int order;
	public BaseCriteria() {
        // nothing to do.
	}
	public BaseCriteria(String date, int order) {
		super();
		this.date = date;
		this.order = order;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	
}

package com.amtrak.tdd.service;

/**
 * Q&D elapsed time utility class uses System.nanoTime() to get the most accurate 
 * elapsed time available. Construct this object and then call the stop() 
 * method and then call the toString() method and/or the getTimeInMillisSeconds() 
 * or getTimeInNanoSeconds(). The object can (optionally) be reused by calling 
 * the restart() or restart(String desc) methods.
 */

public class ElapsedTime {
	

	private String desc;
	private long startTimeNanoSec;
	private long stopTimeNanoSec;
	private long elapsedTimeNanoSec;
	
	public ElapsedTime(String desc) {
		
		restart(desc);
	}
	
	public void restart() {
		
		stopTimeNanoSec = 0;
		elapsedTimeNanoSec = 0;
		startTimeNanoSec = System.nanoTime();
	}
	
	public void restart(String desc) {
		
		this.desc = desc;
		restart();
	}
	
	public void stop() {
		
		stopTimeNanoSec = System.nanoTime();
		elapsedTimeNanoSec = stopTimeNanoSec - startTimeNanoSec;
	}
	
	public long getTimeInNanoSeconds() {
		
		return elapsedTimeNanoSec;
	}
	
	public long getTimeInMilliSeconds() {
		
		// note: 1 Millisecond = 1,000,000 Nanoseconds
		return (elapsedTimeNanoSec / 1000000);
	}
	
	public String toString() {
			
		return desc + " elapsedTime=" + getTimeInMilliSeconds() + " ms." + 
		              " (nanoSec=" + getTimeInNanoSeconds() + ")";
	}

}

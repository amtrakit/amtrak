package com.amtrak.tdd.jcr;

import java.util.List;
import org.apache.sling.api.resource.ResourceResolver;
import com.day.cq.search.QueryBuilder;

public interface RefundReceiptService {
	
    public List SearchCQForRefundReceiptContent(ResourceResolver resourceResolver,QueryBuilder builder,List<BaseCriteria> rdetails);


}

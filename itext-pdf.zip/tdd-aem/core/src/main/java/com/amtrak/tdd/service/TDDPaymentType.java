/**
 * THIS PROGRAM IS CONFIDENTIAL AND PROPRIETARY TO AMTRAK AND 

 * MAY NOT BE REPRODUCED, PUBLISHED OR DISCLOSED TO OTHERS WITHOUT AUTHORIZATION.  

 * COPYRIGHT � AMTRAK.  THIS WORK IS UNPUBLISHED.


 */
package com.amtrak.tdd.service;

import java.math.BigDecimal;

/**
 * This class will contain all the information for a payment type in the 
 * reservation.  It will be when a FormatSendPsgrNotificationRQ is used to 
 * create a TDDBookingInfo.
 * @author Fergus Ryder
 * @version 2.0 TDD Hardening
 *
 */
public class TDDPaymentType {
	
	/** List of payment types. */
	public static final String CREDIT_CARD = TDDConstants.CREDIT_CARD;
	public static final String CASH = TDDConstants.CASH;
	public static final String CHECK = TDDConstants.CHECK;
	public static final String EVOUCHER = TDDConstants.EVOUCHER;
	public static final String EXCHANGE = TDDConstants.EXCHANGE;
	public static final String PASSRIDER = TDDConstants.PASSRIDER;
	public static final String MISCCHARGE = TDDConstants.MISCORDER;
	public static final String NAPNEAP = TDDConstants.NAPNEAP;
	public static final String OTHER = TDDConstants.OTHERS;
	
	/** Type of payment.  One of the above list. */
	private String type;
	/** Name associated to payment type.  Not present for all payment types. */
	private String name;
	/** Payment Type number, i.e. cc number, evoucher number, passrider number. **/
	private String number;
	/** Payment code, i.e. cc authorization code.  Not present for all payment types.  */
	private String code;
	/** Payment type code */
	private String paymentTypeCode;
	/** Payment remark.  */
	private String remark;
	/** Payment amount. */
	private BigDecimal amount;	
	
	/** 
	 * Constructor
	 */
	public TDDPaymentType() {
        // nothing to do.
	}

	/** 
	 * Constructor
	 */
	public TDDPaymentType(String paymentType, String paymentNumber, String paymentRemark, BigDecimal paymentAmount ) {
		type = paymentType;
		number = paymentNumber;
		remark = paymentRemark;
		amount = paymentAmount;
	}

	/**
	 * Setter for the payment name
	 * @param paymentName String
	 */
	public void setPaymentName(String paymentName) {
		name = paymentName;
	}

	/**
	 * Setter for the payment type.
	 * @param paymentType (CREDIT_CARD,EVOUCHER,CASH,CHECK,NAPNEAP,PASSRIDER,MISCCHARGE,EXCHANGE,OTHER)
	 */
	public void setPaymentType(String paymentType) {
		type = paymentType;
	}

	/**
	 * Setter for the payment number
	 * @param paymentNumber String
	 */
	public void setPaymentNumber(String paymentNumber) {
		number = paymentNumber;
	}

	/**
	 * Setter for the payment code.
	 * @param paymentCode String
	 */
	public void setPaymentCode(String paymentCode) {
		code = paymentCode;
	}
	/**
	 * Setter for the payment code.
	 * @param paymentCode String
	 */
	public void setPaymentTypeCode(String payTypeCode) {
		paymentTypeCode = payTypeCode;
	}

	/**
	 * Setter for the payment remark.
	 * @param paymentRemark String
	 */
	public void setPaymentRemark(String paymentRemark) {
		remark = paymentRemark;
	}
	
	/**
	 * Setter for the payment amount.
	 * @param paymentAmount BigDecimal.
	 */
	public void setPaymentAmount(BigDecimal paymentAmount) {
		amount = paymentAmount;
	}
	
	/**
	 * Returns the payment name.
	 * @return the name associated with the payment. String
	 */
	public String getPaymentName() {
		return name;
	}

	/**
	 * Returns the payment type.
	 * @return (CREDIT_CARD,EVOUCHER,CASH,CHECK,NAPNEAP,PASSRIDER,MISCCHARGE,EXCHANGE,OTHER)
	 */
	public String getPaymentType() {
		return type;
	}
	
	/**
	 * Payment Number
	 * @return the number associated with this payment, i.e. cc number, evoucher number.
	 */
	public String getPaymentNumber() {
		return number;
	}

	/**
	 * Returns the code associated with this payment.
	 * @return payment code, i.e. cc authorization.
	 */
	public String getPaymentCode() {
		return code;
	}

	/**
	 * Returns the payment type code associated with this payment.
	 * @return payment type code.
	 */
	public String getPaymentTypeCode() {
		return paymentTypeCode;
	}

	/**
	 * Returns the payment remark
	 * @return String
	 */
	public String getPaymentRemark() {
		return remark;
	}
	
	/**
	 * Returns the payment amount as a BigDecimal
	 * @return payment amount BigDecimal.
	 */
	public BigDecimal getPaymentAmount() {
		return amount;
	}
}

package com.amtrak.tdd.sling;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

public class StationAdvisoryUse extends WCMUsePojo {
	private static final Logger LOG = LoggerFactory.getLogger(StationAdvisoryUse.class);
	private String title;
	private String departureStation;
	private String arrivalStation;
	private String sDate;
	private String eDate;
	private Integer ranking =null;
	private String importantInfo;
	private String publishDate;

	@Override
	public void activate() throws Exception {
		title = getProperties().get("infotitle", String.class);
		departureStation = getProperties().get("depstation", String.class);
		arrivalStation = getProperties().get("arrivestation", String.class);
		sDate = getProperties().get("startdate", String.class);
		eDate = getProperties().get("enddate", String.class);
		ranking = getProperties().get("rank", Integer.class);
		importantInfo = getProperties().get("impinfo", String.class);
		publishDate = getProperties().get("publishDate", String.class);
	}

	public String getSDate() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat;
			inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
			Date fdat = inputFormat.parse(sDate);
			sDate = sdf.format(fdat);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
		return sDate;
	}

	public String getEDate() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat;
			inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
			Date fdat = inputFormat.parse(eDate);
			eDate = sdf.format(fdat);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}

		return eDate;
	}

	public String getPublishDate() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat inputFormat;
			inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
			Date fdat = inputFormat.parse(publishDate);
			publishDate = sdf.format(fdat);
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
		return publishDate;
	}

	public Integer getRanking() {
			return ranking;
	}

	public String getImportantInfo() {
		return importantInfo;
	}

	public String getTitle() {
		return title;
	}

	public String getDepartureStation() {
		return departureStation;
	}

	public String getArrivalStation() {
		return arrivalStation;
	}

}
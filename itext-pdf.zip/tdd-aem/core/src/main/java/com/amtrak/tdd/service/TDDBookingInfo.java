/**
 * THIS PROGRAM IS CONFIDENTIAL AND PROPRIETARY TO AMTRAK AND 

 * MAY NOT BE REPRODUCED, PUBLISHED OR DISCLOSED TO OTHERS WITHOUT AUTHORIZATION.  

 * COPYRIGHT � AMTRAK.  THIS WORK IS UNPUBLISHED.


 */
package com.amtrak.tdd.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.amtrak.mulesoft.schema._2016._03._07.Address;
import com.amtrak.mulesoft.schema._2016._03._07.BookingInfo2;
import com.amtrak.mulesoft.schema._2016._03._07.EmailAddress;
import com.amtrak.mulesoft.schema._2016._03._07.FormOfPayment3;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket;
import com.amtrak.mulesoft.schema._2016._03._07.ObjectFactory;
import com.amtrak.mulesoft.schema._2016._03._07.Passenger;
import com.amtrak.mulesoft.schema._2016._03._07.Payment3;
import com.amtrak.mulesoft.schema._2016._03._07.PaymentInfo3;
import com.amtrak.mulesoft.schema._2016._03._07.PaymentSummary2;
import com.amtrak.mulesoft.schema._2016._03._07.Payments3;

/**
 * This class is the TDD representation of the booking.  It is created by passing in either a 
 * FormatSendPsgrNotification or SendEmailNotification.  This class will be used to build the HTML
 * or PDF attachments.
 * @author Fergus Ryder
 * @version 3.0 TDD Hardening
 *
 */
public class TDDBookingInfo {
	
	// Booking web service request
	private FormatSendPsgrNotificationRQ bookingRequest;
	// Common BookingInfo2 class
	private BookingInfo2 bookingInformation;
	// Operation Type
	private String operationType;
	// Merchant ID
	private String merchantID;
	// PaymentInfo
	private PaymentInfo3 paymentInfo = (new ObjectFactory()).createPaymentInfo3();
	// Original Purchase Date Time
	private String originalPurchaseDateTime = null;
	// Modified Purchase Date Time
	private String modifiedPurchaseDateTime = null;
	// PNR Creation Date
	private String creationDate = null;
	// Credit Card Billing Name
	private String billingName = null;
	// Credit Card Billing Address
	private Address billingAddress = null;
	// List of payment types for this FormatSendPsgrNotificationRQ
	private List<TDDPaymentType> tddPaymentTypes = new ArrayList<TDDPaymentType>();
	// Receipt Type
	private String receiptType = "";
	// Receipt Type
	private boolean reservationCanceled = false;
	// PNR Locator
	private String pnrLocator = null;
	// ExpressDeliveryFee
	private BigDecimal expressDeliveryFee = null;
	// Service Fee
	private BigDecimal serviceFee = null;
	// Is this an auto train booking
	private boolean isAutoTrain = false;
	// List of Passengers
	private List<Passenger> passengers = null;
	// List of Email Addresses
	private List<EmailAddress> emailRecipients = null;
	// Is this a bulk fare booking
	private boolean isBulkFare = false;
	
	/** 
	 * Constructor
	 */
	public TDDBookingInfo() {
        // nothing to do.
	}

	/**
	 * Construction passing in the FormatSendPsgrNotificationRQ
	 * @param formatSendPsgrNotification
	 */
	public TDDBookingInfo(FormatSendPsgrNotificationRQ formatSendPsgrNotification) {
		bookingRequest = formatSendPsgrNotification;
		// Set the booking information
		bookingInformation = bookingRequest.getFormatSendPsgrNotification().getBookingInfo();
		// Set the pnrLocator
		pnrLocator = bookingInformation.getPNRLocator();
		// Set the operation type of this reservation, i.e. TD, DD, CR, DR, EV
		operationType = bookingRequest.getFormatSendPsgrNotification().getOperationType();
		// Set the payment Info
		paymentInfo = bookingRequest.getFormatSendPsgrNotification().getPaymentInfo();
		if (paymentInfo != null) {
			// Set the original purchase date & time for this reservation
			originalPurchaseDateTime = paymentInfo.getOriginalPurchaseDateTime();
			// Set the modified date time for this reservation (may not be set).
			modifiedPurchaseDateTime = paymentInfo.getModifiedDateTime();
		}
		// Set the reservation creation date
		creationDate = bookingRequest.getFormatSendPsgrNotification().getBookingInfo().getPNRCreationDate().toString();
		// Initialize the Merchant ID (May not be present)
		initializeMerchantID();
		// Initialize the tddPaymentTypes list with the payments in the FormatSendPsgrNotificationRequest
		initializePayments();
		// Initialize the receiptType 
		initializeReceiptType();
		// Initialize the list of passengers
		if (bookingRequest.getFormatSendPsgrNotification().getPassengers() != null) {
			passengers = bookingRequest.getFormatSendPsgrNotification().getPassengers().getPassenger();
		}
		// Initialize the list of email recipients
		if (bookingRequest.getFormatSendPsgrNotification().getMethod().getEmail() != null) {
			emailRecipients = bookingRequest.getFormatSendPsgrNotification().getMethod().getEmail().getEmailAddress();
		}
		// Is this a bulk fare booking
		isBulkFare = TDDBookingUtils.isBulkFarePlan(bookingRequest);
	}


	/**
	 * Initialize the merchant ID if it is present.
	 */
	private void initializeMerchantID() {
		if(paymentInfo != null){
			Payments3 payments2 = paymentInfo.getPayments();
			if (payments2 != null) {
				List<Payment3> payment2List = payments2.getPayment();
				if (payment2List != null && payment2List.size() > 0) {
					for (Iterator<Payment3> paymt2Itr = payment2List.iterator(); paymt2Itr.hasNext(); )  {
						Payment3 paymt2 = (Payment3) paymt2Itr.next();
						FormOfPayment3 formOfPayment2 =(new ObjectFactory()).createFormOfPayment3();
						formOfPayment2 = paymt2.getFormOfPayment();				
						//This Block is to check for Merchant ID
						if(formOfPayment2.getCard() != null && formOfPayment2.getCard().getMerchantID()!= null){
							merchantID = formOfPayment2.getCard().getMerchantID();
						}
					}//End of For Loop
				}
			}
		}
	}

	/**
	 * Initialize the booking payments.  Iterate through the list of payments and create a 
	 * TDDPaymentType for each one.  Also initializes the billing name and the billing address if present.  
	 * These will be the name and address associated to a credit card in the reservation.  If there are
	 * multiple credit cards and they all have name/addresses the first card will be used.
	 */
	private void initializePayments() {
		Payments3 payments2 = (new ObjectFactory()).createPayments3();
		PaymentSummary2 paySummary = (new ObjectFactory()).createPaymentSummary2();
		if(paymentInfo != null){
			payments2 = paymentInfo.getPayments();
			List<Payment3> payment2List = payments2.getPayment();
			paySummary = payments2.getPaymentSummary();
	
			// Iterate through the payments
			for (Iterator<Payment3> paymt2Itr = payment2List.iterator(); paymt2Itr.hasNext(); )  {
				Payment3 paymt2 = (Payment3) paymt2Itr.next();
				FormOfPayment3 formOfPayment2 =(new ObjectFactory()).createFormOfPayment3();
				formOfPayment2 = paymt2.getFormOfPayment();
				if(formOfPayment2.getCard() != null){
					TDDPaymentType tddPaymentType = new TDDPaymentType();
					tddPaymentType.setPaymentAmount(paymt2.getAmount());
					tddPaymentType.setPaymentNumber(formOfPayment2.getCard().getCardNumber());
					// Set the credit card authorization code
					tddPaymentType.setPaymentCode(formOfPayment2.getCard().getAuthorizationCode());
					tddPaymentType.setPaymentRemark(formOfPayment2.getCard().getRemarks().getRemark().get(0).getText());
					tddPaymentType.setPaymentType(TDDPaymentType.CREDIT_CARD);
					if (formOfPayment2.getCard().getCode() != null) {
						tddPaymentType.setPaymentTypeCode(formOfPayment2.getCard().getCode());
					}
					tddPaymentTypes.add(tddPaymentType);
					// Initialize Billing Address and Name also
					if (formOfPayment2.getCard().getName() != null) {
						// If this has not already been set.
						if (billingAddress == null) {
							billingAddress = formOfPayment2.getCard().getBillingAddress();
						}
						// If this has not already been set.
						if (billingName == null) {
							billingName = formOfPayment2.getCard().getName();
						}
					}
				}
				else if (formOfPayment2.getCash() != null) {
					TDDPaymentType tddPaymentType = 
							new TDDPaymentType(TDDPaymentType.CASH, null, formOfPayment2.getCash().getRemarks().getRemark().get(0).getText(),paymt2.getAmount());
					if (formOfPayment2.getCash().getCode() != null) {
						tddPaymentType.setPaymentTypeCode(formOfPayment2.getCash().getCode());
					}
					tddPaymentTypes.add(tddPaymentType);
				}
				else if (formOfPayment2.getCheck() != null) {
					TDDPaymentType tddPaymentType = 
							new TDDPaymentType(TDDPaymentType.CHECK, formOfPayment2.getCheck().getCheckNumber(), formOfPayment2.getCheck().getRemarks().getRemark().get(0).getText(),paymt2.getAmount());
					if (formOfPayment2.getCheck().getCode() != null) {
						tddPaymentType.setPaymentTypeCode(formOfPayment2.getCheck().getCode());
					}
					tddPaymentTypes.add(tddPaymentType);
				}
				else if (formOfPayment2.getEVoucher() != null) {
					TDDPaymentType tddPaymentType = 
							new TDDPaymentType(TDDPaymentType.EVOUCHER, formOfPayment2.getEVoucher().getEVoucherNumber(), formOfPayment2.getEVoucher().getRemarks().getRemark().get(0).getText(),paymt2.getAmount());
					if (formOfPayment2.getEVoucher().getCode() != null) {
						tddPaymentType.setPaymentTypeCode(formOfPayment2.getEVoucher().getCode());
					}

					tddPaymentTypes.add(tddPaymentType);
				}
				else if (formOfPayment2.getExchange() != null) {
					TDDPaymentType tddPaymentType = 
							new TDDPaymentType(TDDPaymentType.EXCHANGE, null, formOfPayment2.getExchange().getRemarks().getRemark().get(0).getText(),paymt2.getAmount());
					if (formOfPayment2.getExchange().getTicketNumber().getTicketNumber() != null) 
						tddPaymentType.setPaymentNumber(formOfPayment2.getExchange().getTicketNumber().getTicketNumber());
					
					if (formOfPayment2.getExchange().getCode() != null) {
						tddPaymentType.setPaymentTypeCode(formOfPayment2.getExchange().getCode());
					}

					tddPaymentTypes.add(tddPaymentType);
				}
				else if (formOfPayment2.getNAPNEAP() != null) {
					TDDPaymentType tddPaymentType = 
							new TDDPaymentType(TDDPaymentType.NAPNEAP, formOfPayment2.getNAPNEAP().getPassNumber(), formOfPayment2.getNAPNEAP().getRemarks().getRemark().get(0).getText(),paymt2.getAmount());
					if (formOfPayment2.getNAPNEAP().getCode() != null) {
						tddPaymentType.setPaymentTypeCode(formOfPayment2.getNAPNEAP().getCode());
					}

					tddPaymentTypes.add(tddPaymentType);
				}
				else if (formOfPayment2.getMiscChargeOrder() != null) {
					TDDPaymentType tddPaymentType = 
							new TDDPaymentType(TDDPaymentType.MISCCHARGE, formOfPayment2.getMiscChargeOrder().getMCONumber(), formOfPayment2.getMiscChargeOrder().getRemarks().getRemark().get(0).getText(),paymt2.getAmount());
					if (formOfPayment2.getMiscChargeOrder().getCode() != null) {
						tddPaymentType.setPaymentTypeCode(formOfPayment2.getMiscChargeOrder().getCode());
					}

					tddPaymentTypes.add(tddPaymentType);
				}
				else if (formOfPayment2.getPassRider() != null) {
					TDDPaymentType tddPaymentType = 
							new TDDPaymentType(TDDPaymentType.PASSRIDER, formOfPayment2.getPassRider().getPassNumber(), formOfPayment2.getPassRider().getRemarks().getRemark().get(0).getText(),paymt2.getAmount());
					if (formOfPayment2.getPassRider().getCode() != null) {
						tddPaymentType.setPaymentTypeCode(formOfPayment2.getPassRider().getCode());
					}

					tddPaymentTypes.add(tddPaymentType);
				}
				else if (formOfPayment2.getOthers() != null) {
					TDDPaymentType tddPaymentType = 
							new TDDPaymentType(TDDPaymentType.OTHER, formOfPayment2.getOthers().getNumber(), formOfPayment2.getOthers().getRemarks().getRemark().get(0).getText(),paymt2.getAmount());
					if (formOfPayment2.getOthers().getCode() != null) {
						tddPaymentType.setPaymentTypeCode(formOfPayment2.getOthers().getCode());
					}

					tddPaymentTypes.add(tddPaymentType);
				}
			}
		}
	}
		
	/**
	 * Set the FormatSendPsgrNoticiationRQ
	 * @param formatSendPsgrNotification
	 */
	public void setBookingRequest(FormatSendPsgrNotificationRQ formatSendPsgrNotification) {
		bookingRequest = formatSendPsgrNotification;
	}


	/**
	 * Returns the FormatSendPsgrNotificationRQ
	 * @return FormatSendPsgrNotificationRQ
	 */
	public FormatSendPsgrNotificationRQ getBookingRequest() {
		return bookingRequest;
	}
	
	/**
	 * Returns the Booking Creation Date as a String
	 * @return
	 */
	public String getBookingCreationDate() {
		return bookingInformation.getPNRCreationDate().toString();
	}

	/**
	 * Returns the Booking PNR Number as a String
	 * @return
	 */
	public String getBookingPNRNumber() {
		return pnrLocator;
	}

	/**
	 * Returns the operation type of this request
	 * @return String (TD/DD/CR/DR/EV)
	 */
	public String getOperationType() {
		return operationType;
	}

	/**
	 * Returns the merchantID of this request
	 * @return String 
	 */
	public String getMerchantID() {
		return merchantID;
	}

	/**
	 * Returns the creationDate of this request
	 * @return String (yyyy-MM-dd)
	 */
	public String getCreationDate() {
		return creationDate;
	}

	/**
	 * Returns the original purchase date time
	 * @return String (MM/dd/yyyy h:mm a)
	 */
	public String getOriginalPurchaseDateTime() {
		return originalPurchaseDateTime;
	}

	/**
	 * Returns the modified purchase date time
	 * @return String (MM/dd/yyyy h:mm a)
	 */
	public String getModifiedPurchaseDateTime() {
		return modifiedPurchaseDateTime;
	}

	/**
	 * Returns the billing address
	 * @return Address
	 */
	public Address getBillingAddress() {
		return billingAddress;
	}

	/**
	 * Returns the billing name
	 * @return String
	 */
	public String getBillingName() {
		return billingName;
	}

	/**
	 * Returns the list of payment types associated with this booking
	 * @return List of TDDPaymentType objects.
	 */
	public List<TDDPaymentType> getPaymentTypes() {
		return tddPaymentTypes;
	}

	/**
	 * Returns whether the reservation is canceled
	 * @return boolean.
	 */
	public String getReceiptType() {
		return receiptType;
	}

	/**
	 * Returns whether the reservation is canceled
	 * @return boolean.
	 */
	public boolean getReservationCanceled() {
		return reservationCanceled;
	}

	/**
	 * Returns the express delivery fee
	 * @return BigDecimal or null
	 */
	public BigDecimal getExpressDeliveryFee() {
		return expressDeliveryFee;
	}

	/**
	 * Returns the service fee
	 * @return BigDecimal or null
	 */
	public BigDecimal getServiceFee() {
		return serviceFee;
	}

	/**
	 * Returns the number of passengers
	 * @return int
	 */
	public int getNumberOfPassengers() {
		if (passengers == null) 
			return 0;
		return passengers.size();
	}

	/**
	 * Returns primary passenger family name
	 * @return String
	 */
	public String getPrimaryPassengerFamilyName() {
		if (passengers == null) 
			return null;
		return passengers.get(0).getPassengerName().getLastName();
	}

	/**
	 * Returns primary passenger first name
	 * @return String
	 */
	public String getPrimaryPassengerFirstName() {
		if (passengers == null) 
			return null;
		return passengers.get(0).getPassengerName().getFirstName();
	}
	
	/**
	 * Returns the list of email recipients
	 * @return List
	 */
	public List<EmailAddress> getEmailRecipients() {
		return emailRecipients;
	}

	/**
	 * Returns if this booking is a BULK FARE
	 * @return boolean
	 */
	public boolean getBulkFare() {
		return isBulkFare;
	}
	
	/**
	 * Returns the PaymentInfo
	 * @return PaymentInfo3
	 */
	public PaymentInfo3 getPaymentInfo() {
		return paymentInfo;
	}

	/**
	 * Method to determine the type of receipt required for the standard email
	 *  - Purchase Summary
	 *  - Even Exchange
	 *  - Cancel Refund
	 *  - Upgrade New Money
	 *  - Upgrade Amount Due
	 *  - Downgrade Refund
	 * @param formatSendPsgrNotificationRQ
	 * @return String
	 */
	public void initializeReceiptType(){	
		
		// If this is a CANCEL Operation type then just return TDDConstants.CANCEL_REFUND
		if (operationType.equals(TDDConstants.CANCEL_REFUND)) {
			receiptType = TDDConstants.CANCEL_REFUND;
			reservationCanceled = true;
		}
		
		if(paymentInfo != null && paymentInfo.getPayments() != null && paymentInfo.getPayments().getPaymentSummary() != null){
			// Set the payment Summary
			PaymentSummary2 paymentSummary = paymentInfo.getPayments().getPaymentSummary();
			// If paymentInfo is present
			//For UPGRADE_NEW_MONEY there might be a situation where there is no modified time but paymentDue is > 0.
				if( (paymentInfo.getModifiedDateTime() == null || paymentInfo.getModifiedDateTime().isEmpty()) && 
						!(paymentSummary.getPaymentDue() != null && paymentSummary.getPaymentDue().floatValue() > 0)){
					//Purchase Summary	    
					receiptType = TDDConstants.PURCHASE_SUMMARY;
				} 
				else {	    	
			    	if(paymentSummary.getAvailableTktAmt() != null &&
			    			paymentSummary.getNewTktAmt() != null && paymentSummary.getEVoucherAmt() != null &&
			    			(Float.floatToRawIntBits(paymentSummary.getAvailableTktAmt().floatValue()) == Float.floatToRawIntBits((paymentSummary.getEVoucherAmt().floatValue() + paymentSummary.getNewTktAmt().floatValue())))){
			    		//Even Exchange	    		
			    		receiptType = TDDConstants.EVEN_EXCHANGE;
			    	}else if(paymentSummary.getAvailableTktAmt() != null &&
			    			paymentSummary.getNewTktAmt() != null &&
			    			(Float.floatToRawIntBits(paymentSummary.getAvailableTktAmt().floatValue()) == Float.floatToRawIntBits(paymentSummary.getNewTktAmt().floatValue()))){
			    		//Even Exchange	    		
			    		receiptType = TDDConstants.EVEN_EXCHANGE;
			    	}else if((paymentSummary.getNewTktAmt() == null ||
			    			Float.floatToRawIntBits(paymentSummary.getNewTktAmt().floatValue()) == 0) 
			    			&& paymentSummary.getRefundAmt() != null){
			    		//Cancel Refund
			    		receiptType = TDDConstants.CANCEL_REFUND;
			    	}else if(paymentSummary.getNewTktAmt() != null && paymentSummary.getNewTktAmt().floatValue() > 0
			    			&& ((paymentSummary.getPaidAmt() != null && paymentSummary.getPaidAmt().floatValue() > 0) 
			    					&&(paymentSummary.getEVoucherAmt() != null && paymentSummary.getEVoucherAmt().floatValue() > 0))){
			    		//Downgrade with Refund
			    		receiptType = TDDConstants.UPGRADE_NEW_MONEY;
			    		//Prepare instructions only if Downgrade Refund to eVoucher
			    	}else if(paymentSummary.getNewTktAmt() != null && paymentSummary.getNewTktAmt().floatValue() > 0
			    			&& ((paymentSummary.getPaidAmt() != null && paymentSummary.getPaidAmt().floatValue() > 0) 
			    					&&(paymentSummary.getForfeitAmt() != null && paymentSummary.getForfeitAmt().floatValue() > 0))){
			    		//Downgrade with Refund
			    		receiptType = TDDConstants.UPGRADE_NEW_MONEY;	    		
			    	}else if(paymentSummary.getNewTktAmt() != null && paymentSummary.getNewTktAmt().floatValue() > 0
			    			&& ((paymentSummary.getRefundAmt() != null && paymentSummary.getRefundAmt().floatValue() > 0) 
			    					||(paymentSummary.getEVoucherAmt() != null && paymentSummary.getEVoucherAmt().floatValue() > 0))){
			    		//Downgrade with Refund
			    		receiptType = TDDConstants.DOWNGRADE_REFUND;
			    	}else if(paymentSummary.getAvailableTktAmt() != null &&
			    			paymentSummary.getNewTktAmt() != null && 
			    			paymentSummary.getNewTktAmt().floatValue() > paymentSummary.getAvailableTktAmt().floatValue()){
			    		if(paymentSummary.getPaymentDue() != null){
			    			//Upgrade with Amount Due
				    		receiptType = TDDConstants.UPGRADE_AMOUNT_DUE;
			    		}else{
			    			//Upgrade with New Money
				    		receiptType = TDDConstants.UPGRADE_NEW_MONEY;
			    		}
			    	}
				}
		
			/**
			 *  For purchases of NR and RW FOPs, paymentsummary will only contain PaidAmt=�0.00�.  
				For exchanges of NR and RW FOPs, it will contain both PaidAmt=�0.00� and RefundAmt=�0.00�.  
				For refunds of NR and RW FOPs, it will contain only RefundAmt=�0.00�.  Please keep in mind some scenarios are not possible 
				such as you cannot do a NR exchange (it�s restricted).  Also the refunds of these may actually be shown as CA cash instead 
				of NR and RW FOPs.  This is yet to be determined as the refund processing has to create records for the receipt to look at.
			*/
			if(receiptType == null || receiptType.isEmpty()){
				if(paymentSummary.getPaidAmt() != null && paymentSummary.getRefundAmt() != null){
					//EVEN EXCHANGE
					receiptType = TDDConstants.EVEN_EXCHANGE;
				}else if(paymentSummary.getPaidAmt() != null){
					//PURCHASE SUMMARY
					receiptType = TDDConstants.PURCHASE_SUMMARY;
				}else if(paymentSummary.getRefundAmt() != null){
					//CANCEL_REFUND
					receiptType = TDDConstants.CANCEL_REFUND;
					reservationCanceled = true;
				}
			}
		}
	}
	
	/**
	 * Method to set values for the ExpressDeliveryFee and ServiceFee if present and to determine if this is an 
	 * Auto-Train booking.
	 */
	private void initializeFees() {

		// Get the itinerary
    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = bookingRequest.getFormatSendPsgrNotification().getItinerary();    	
    	List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();

    	// Iterate through the segments and set the express delivery and service fees.
		for (Iterator<LogicalTrip> j = logicalTripListRQ.iterator(); j.hasNext(); )  { 
			List<Segment> segmentsList  = ((FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip)j.next()).getSegments().getSegment();
			for (Iterator<Segment> i = segmentsList.iterator(); i.hasNext(); )  {        			
    			Segment segment = new Segment();
    			segment = (Segment) i.next();
				if(segment.getTickets() != null){
	    			List<Ticket> ticketList = segment.getTickets().getTicket();	
    				for (Iterator<Ticket> itr = ticketList.iterator(); itr.hasNext(); )  {        			
    		    		Ticket ticket = new Ticket();
    		    		ticket = (Ticket) itr.next(); 		    		    		
    		    		if(ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null &&
    		    				ticket.getPricingItem().getFarePlans().getFarePlan().get(0) != null){	    		    			
    		    			if(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().equalsIgnoreCase(TDDConstants.EXPRESS_DELIVERY_FEE)){
	    		    			//Store Express Delivery Fee Amount
	    		    			expressDeliveryFee = ticket.getPricingItem().getTariff().getRailFare();
    		    			}else if(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().substring(0, 3).equalsIgnoreCase(TDDConstants.SERVICE_FEE)){
	    		    			//Store Service Fee Amount
	    		    			serviceFee = ticket.getPricingItem().getTariff().getRailFare();
    		    			}
    		    		}
    				}
				}
    			if(segment.getTrainDetails().getRouteName() != null && "AUTO TRAIN".equalsIgnoreCase(segment.getTrainDetails().getRouteName())){
    				isAutoTrain = true;
    			}
			}
		}
	}
} 

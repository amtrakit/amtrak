package com.amtrak.tdd.servlets;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket;
import com.amtrak.mulesoft.schema._2016._03._07.PricingItem.FarePlans;
import com.amtrak.mulesoft.schema._2016._03._07.PricingItem.FarePlans.FarePlan;
import com.amtrak.tdd.jcr.BaseCriteria;
import com.amtrak.tdd.jcr.FarePlanCriteria;
import com.amtrak.tdd.jcr.PartnerCriteria;
import com.amtrak.tdd.jcr.PaymentCriteria;
import com.amtrak.tdd.jcr.RBDCriteria;
import com.amtrak.tdd.jcr.RefundReceiptServiceImpl;
import com.amtrak.tdd.jcr.SalesReceiptServiceImpl;
import com.amtrak.tdd.jcr.SearchServiceImpl;
import com.amtrak.tdd.jcr.ServiceCriteria;
import com.amtrak.tdd.jcr.StationCriteria;
import com.amtrak.tdd.jcr.StationType;
import com.amtrak.tdd.jcr.TicketCriteria;
import com.amtrak.tdd.service.TDDBookingInfo;
import com.amtrak.tdd.service.TDDConstants;
import com.amtrak.tdd.service.TDDDateUtils;
import com.amtrak.tdd.service.TDDPaymentType;
import com.day.cq.search.QueryBuilder;

public class JCRService {

	private static final Logger LOG = LoggerFactory.getLogger(JCRService.class);
	
	private ResourceResolver resourceResolver;

	private QueryBuilder builder;

	private TDDBookingInfo bookingInfo;


	public JCRService() {
		super();
	}

	public JCRService(ResourceResolver resourceResolver, QueryBuilder builder, TDDBookingInfo bookingInfo) {
		super();
		this.resourceResolver = resourceResolver;
		this.builder = builder;
		this.bookingInfo = bookingInfo;
	}

	public List<String> getImportantInformation(String tktType) {
		SearchServiceImpl simpl = new SearchServiceImpl();
		List<BaseCriteria> criterias = populateCriteria(tktType);
		List<String> infolist = simpl.SearchCQForContent(resourceResolver, builder, criterias);
		return infolist;
	}

	public List<String> getSalesReceiptImportantInformation(String tktType) {
		SalesReceiptServiceImpl simpl = new SalesReceiptServiceImpl();
		List<BaseCriteria> criterias = populateCriteria(tktType);
		List<String> infolist = simpl.SearchCQForSalesReceiptContent(resourceResolver, builder, criterias);
		return infolist;
	}
	
	public List<String> getRefundReceiptImportantInformation(String tktType) {
		RefundReceiptServiceImpl simpl = new RefundReceiptServiceImpl();
		List<BaseCriteria> criterias = populateCriteria(tktType);
		List<String> infolist = simpl.SearchCQForRefundReceiptContent(resourceResolver, builder, criterias);
		return infolist;
	}
	
	private List<BaseCriteria> populateCriteria(String ticketType){
		List<BaseCriteria> criterias = new ArrayList<>();
		List<PartnerCriteria> partnerCriterias = new ArrayList<>();
		Set<String> paymentCode = new HashSet<>();
		String pcode = null;
		String tktType = ticketType;


		FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ = bookingInfo.getBookingRequest();
		Itinerary itinerary = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();
		
		if (bookingInfo != null && bookingInfo.getPaymentTypes() != null){
		
			List<TDDPaymentType> paymentsTypes = bookingInfo.getPaymentTypes();
			
			for (int i=0; i<paymentsTypes.size();i++) {
				if(paymentsTypes.get(i).getPaymentTypeCode() != null){
					paymentCode.add(paymentsTypes.get(i).getPaymentTypeCode());
				}
				
			}
	
			pcode = StringUtils.join(paymentCode,",");
		}
		
		if (itinerary != null){
			List<LogicalTrip> logicalTrips = itinerary.getLogicalTrip();
			int stationCounter = 0;
			int serviceCounter = 0;
			int rbdCounter = 0;
			int farePlanCounter = 0;
			int partnerCounter = 0;
			int ticketCounter = 0;
	
			String startDate = "";
	
			if(StringUtils.contains(tktType, TDDConstants.MULTI_MONTHLY_RIDE_TICKET_TYPE)){
				tktType = TDDConstants.MULTI_MONTHLY_RIDE_TICKET_TYPE;
			}
			TicketCriteria ticketCriteria = new TicketCriteria();
			ticketCriteria.setTicketType(tktType);
			ticketCriteria.setOrder(++ticketCounter);
	
			Set<String> partnerIds = new HashSet<>();
			String partnerName = "AMTRAK";
			
			for(LogicalTrip logicalTrip : logicalTrips){
	
	    		List<Segment> segments  = logicalTrip.getSegments().getSegment();
	    		for(Segment segment : segments){
	    			if(segment != null){
	    				if(segment.getOrigin() != null && segment.getOrigin().getCode() != null
	    						&& segment.getDestination() != null && segment.getDestination().getCode() != null){
	    					String departureDate = "";
	        				if(segment.getDepartureDateTime() != null){
	        					try {
	        						departureDate = TDDDateUtils.convertDateToMMddyy(segment.getDepartureDateTime().toString());
	        						if(StringUtils.isBlank(startDate)){
	        							startDate = departureDate;
	        						}
	        					} catch (ParseException e) {
	        						LOG.error("Error while parsing departure date:"+segment.getDepartureDateTime().toString() , e);
	        					}
	        				}
	        				if(StringUtils.isBlank(departureDate)){
	        					if(segment.getTickets() != null){
	        						Tickets tickets = segment.getTickets();
	        						if(tickets.getTicket() != null && !tickets.getTicket().isEmpty()){
	        							Ticket ticket = tickets.getTicket().get(0);
	        							if(ticket != null && ticket.getNotValidBefore() != null){
	        								try {
	        	        						departureDate = TDDDateUtils.convertDateToMMddyy(ticket.getNotValidBefore().toString());
	        	        						if(StringUtils.isBlank(startDate)){
	        	        							startDate = departureDate;
	        	        						}
	        	        					} catch (ParseException e) {
	        	        						LOG.error("Error while parsing departure date:"+ticket.getNotValidBefore().toString() , e);
	        	        					}
	        							}
	        						}
	        					}
	        				}
	    					StationCriteria originStationCriteria = new StationCriteria(segment.getOrigin().getCode(), StationType.ORIGIN, departureDate, ++stationCounter);
	        				criterias.add(originStationCriteria);
	
	        				String arrivalDate = "";
	    					if(segment.getArrivalDateTime() != null){
	    						try {
	    							arrivalDate = TDDDateUtils.convertDateToMMddyy(segment.getArrivalDateTime().toString());
	    						} catch (ParseException e) {
		        						LOG.error("Error while parsing arrival date:"+segment.getArrivalDateTime().toString() , e);
		        						     						}
	    					}
	    					if(StringUtils.isBlank(arrivalDate)){
	        					if(segment.getTickets() != null){
	        						Tickets tickets = segment.getTickets();
	        						if(tickets.getTicket() != null && !tickets.getTicket().isEmpty()){
	        							Ticket ticket = tickets.getTicket().get(0);
	        							if(ticket != null && ticket.getNotValidAfter() != null){
	        								try {
	        									arrivalDate = TDDDateUtils.convertDateToMMddyy(ticket.getNotValidAfter().toString());
	        	        					} catch (ParseException e) {
	        	        						LOG.error("Error while parsing arrival date:"+ticket.getNotValidAfter().toString() , e);
	        	        					}
	        							}
	        						}
	        					}
	        				}
	    					StationCriteria destinationStationCriteria = new StationCriteria(segment.getDestination().getCode(), StationType.DESTINATION, arrivalDate, ++stationCounter);
	    					criterias.add(destinationStationCriteria);
	
	    					if(segment.getTrainDetails() != null && segment.getTrainDetails().getRouteName() != null){
	    							String trainNumber;
	    							if(segment.getTrainDetails().getTrainNumber() != null){
	    								trainNumber = segment.getTrainDetails().getTrainNumber().toString();
	    							}else{
	    								trainNumber = segment.getTrainDetails().getRouteName();
	    							}
	    							ServiceCriteria serviceCriteria = new ServiceCriteria(originStationCriteria, destinationStationCriteria, segment.getTrainDetails().getRouteName(), trainNumber);
	    							serviceCriteria.setOrder(++serviceCounter);
	    							criterias.add(serviceCriteria);
	
	    							RBDCriteria rbdCriteria = new RBDCriteria(serviceCriteria, segment.getClassOfService().getClassOfService());
	    							rbdCriteria.setOrder(++rbdCounter);
	    							criterias.add(rbdCriteria);
	    							
	    							PaymentCriteria paymentCriteria = new PaymentCriteria(serviceCriteria, pcode);
	    							criterias.add(paymentCriteria);
	
	    							String partnerId = segment.getTrainDetails().getPartnerID();
	    							boolean hasPartner = false;
	    							Tickets tickets = segment.getTickets();
	    							if(tickets != null && tickets.getTicket() != null && !tickets.getTicket().isEmpty()){
	    								for(Ticket ticket : tickets.getTicket()){
	    									if(ticket !=  null && ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null ){
	    										FarePlans farePlans = ticket.getPricingItem().getFarePlans();
	    										if(farePlans != null && farePlans.getFarePlan() != null && !farePlans.getFarePlan().isEmpty()){
	    											for(FarePlan farePlan : farePlans.getFarePlan()){
	    												if(farePlan != null && farePlan.getCode() != null){
	    													FarePlanCriteria farePlanCriteria = new FarePlanCriteria(rbdCriteria, farePlan.getCode(), false);
	    													farePlanCriteria.setOrder(++farePlanCounter);
	    					    							criterias.add(farePlanCriteria);
	
	    					    							if(StringUtils.isBlank(partnerId)){
	    					    								partnerId = partnerName;
	    					    							}
	    					    							partnerIds.add(partnerId);
	    					    							PartnerCriteria partnerCriteria = new PartnerCriteria(farePlanCriteria, partnerId);
	    													partnerCriteria.setOrder(++partnerCounter);
	    					    							partnerCriterias.add(partnerCriteria);
	    					    							hasPartner = true;
	    												}
	    											}
	    										}
	    									}
	    								}
	    							}
	    							if(!hasPartner){
										FarePlanCriteria farePlanCriteria = new FarePlanCriteria(rbdCriteria, "", false);
										farePlanCriteria.setOrder(++farePlanCounter);
										criterias.add(farePlanCriteria);
	
										if(StringUtils.isBlank(partnerId)){
											partnerId = partnerName;
										}
										partnerIds.add(partnerId);
										PartnerCriteria partnerCriteria = new PartnerCriteria(farePlanCriteria, partnerId);
										partnerCriteria.setOrder(++partnerCounter);
	    					    		partnerCriterias.add(partnerCriteria);
									}
	
	    					}
	    				}
	    			}
	    		}
	    	}
			ticketCriteria.setDate(startDate);
			criterias.add(ticketCriteria);
	
			if(partnerIds.size() > 1){
				for(PartnerCriteria partnerCriteria : partnerCriterias){
					partnerCriteria.setPartnerName(partnerName);
				}
			}
	
			
	
		} else {
		
			if (bookingInfo != null && bookingInfo.getReceiptType()!= null && bookingInfo.getReceiptType().equals(TDDConstants.CANCEL_REFUND)) {
				PaymentCriteria paymentCriteria = new PaymentCriteria();
				paymentCriteria.setPaymentCode(pcode);
				criterias.add(paymentCriteria);
				
			}
		}
		
		criterias.addAll(partnerCriterias);
    	return criterias;
	}

}

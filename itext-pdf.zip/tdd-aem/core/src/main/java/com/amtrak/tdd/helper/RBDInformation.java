package com.amtrak.tdd.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;

import javax.jcr.Session;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.amtrak.tdd.jcr.RBDCriteria;
import com.amtrak.tdd.jcr.TicketCriteria;
import com.amtrak.tdd.service.TDDConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

public class RBDInformation {
	
	/** Default log. */
	private static final Logger LOG = LoggerFactory.getLogger(RBDInformation.class);

	/*
	 * Default Constructor
	 */
	private RBDInformation(){
        // nothing to do.
	}

	public static Set<String> rbdInformation(List<RBDCriteria> rbdCode,List<TicketCriteria> ticketTypes,QueryBuilder qbuilder,Set<String> linkedHashSet,String informationPath, Session session) {

		try{
			Date currDate = new Date();
			Map<String, String> rbdmap = new HashMap<>();
			List<SortInformation> rbdInfoList = new ArrayList<>();
			List<String> snamelist = new ArrayList<>();
			List<String> snumlist = new ArrayList<>();
			for (RBDCriteria resobj:rbdCode){
				if (resobj.getServiceCriteria() != null){
					snamelist.add(resobj.getServiceCriteria().getServiceName());
					snumlist.add(resobj.getServiceCriteria().getServiceNumber());
				}
			}

			rbdmap.put(TDDConstants.PAGE_PATH_TEXT, informationPath);
			rbdmap.put(TDDConstants.NODE_TYPE_TEXT, TDDConstants.NODE_TYPE);
			rbdmap.put("group.p.or", TDDConstants.TRUE_TEXT);
			rbdmap.put("group.1_property", TDDConstants.RBD_CODE);
			for (int i = 0; i < rbdCode.size(); i++) {
				rbdmap.put("group.1_property." + (i + 1) + "_value", "%" + rbdCode.get(i).getRbdCode() + "%");
			}
			rbdmap.put("group.1_property.operation", TDDConstants.LIKE_TEXT);
			rbdmap.put("group.2_property", TDDConstants.RBD_EXCLUDE);
			rbdmap.put("group.2_property._value",TDDConstants.TEXT_EXCLUDE );
			rbdmap.put(TDDConstants.P_HITS_TEXT, TDDConstants.P_HITS_VALUE);
			rbdmap.put(TDDConstants.P_OFFSET_TEXT, TDDConstants.P_OFFSET_VALUE);
			rbdmap.put(TDDConstants.P_LIMIT_TEXT, TDDConstants.P_LIMIT_VALUE);

			Query rbdquery = qbuilder.createQuery(PredicateGroup.create(rbdmap), session);
			rbdquery.setStart(0);
			SearchResult rbdresult = rbdquery.getResult();

			for (Hit hit : rbdresult.getHits()) {
				ValueMap Prop = hit.getProperties();

				Date astartdate = null;
				Date aenddate = null;
				Date tdate = null;
				Date pubdate = null;
				boolean bpubdate = true;
				boolean rbddisplay = false;
				
				if (Prop.get(TDDConstants.PUBLISH_DATE) != null ) {
					pubdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.PUBLISH_DATE).toString());
					if (currDate.before(pubdate)) {
						bpubdate = false;
					}
				}

				
				
				if (Prop.get(TDDConstants.RBD_CODE) != null && bpubdate) {
					for (int i = 0; i < rbdCode.size(); i++) {

						String rbdcode= Prop.get(TDDConstants.RBD_CODE).toString();
						String[] rbdcodeArray = rbdcode.split(TDDConstants.SPLIT_STRING_TEXT);


						if (Prop.get(TDDConstants.RBD_EXCLUDE) != null &&  Prop.get(TDDConstants.RBD_EXCLUDE).toString().equalsIgnoreCase(TDDConstants.TEXT_EXCLUDE) ) {
							rbddisplay = ImportantInformationHelper.INSTANCE.checkRBDExcludeMatch(rbdcodeArray, rbdCode, true);
						} else {
							rbddisplay = ImportantInformationHelper.INSTANCE.checkRBDExcludeMatch(rbdcodeArray, rbdCode, false);
							
						}
						
								
							if(rbddisplay ){


								if (Prop.get(TDDConstants.START_DATE) != null) {
									astartdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.START_DATE).toString());
								}
								if (Prop.get(TDDConstants.END_DATE) != null)	{
									aenddate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.END_DATE).toString());
								}
								tdate =ImportantInformationHelper.INSTANCE.getDate(rbdCode.get(i).getOriginDate());


								if (ImportantInformationHelper.INSTANCE.compareDates(tdate,astartdate,aenddate)) {

									Boolean display = true;
									if ((Prop.get(TDDConstants.SERVICE_NAME) != null) && display) {
										if (rbdCode.get(i)!= null && rbdCode.get(i).getServiceCriteria()!= null && rbdCode.get(i).getServiceCriteria().getServiceName()!= null){
											if (Prop.get(TDDConstants.TRAIN_NAME_EXCLUDE) != null && Prop.get(TDDConstants.TRAIN_NAME_EXCLUDE).toString().equalsIgnoreCase(TDDConstants.TEXT_EXCLUDE) ) {
												display =ImportantInformationHelper.INSTANCE.checkExcludeServiceMatch(Prop.get(TDDConstants.SERVICE_NAME).toString(),snamelist);
											} else {
												display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.SERVICE_NAME).toString(),rbdCode.get(i).getServiceCriteria().getServiceName());
											}
										}
									}
									if ((Prop.get(TDDConstants.SERVICE_NUMBER) != null) && display) {
										if (rbdCode.get(i)!= null && rbdCode.get(i).getServiceCriteria()!= null && rbdCode.get(i).getServiceCriteria().getServiceNumber()!= null){
											if (Prop.get(TDDConstants.TRAIN_NUMBER_EXCLUDE) != null && Prop.get(TDDConstants.TRAIN_NUMBER_EXCLUDE).toString().equalsIgnoreCase(TDDConstants.TEXT_EXCLUDE) ) {
												display =ImportantInformationHelper.INSTANCE.checkExcludeServiceMatch(Prop.get(TDDConstants.SERVICE_NUMBER).toString(),snumlist);
											} else{
												display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.SERVICE_NUMBER).toString(),rbdCode.get(i).getServiceCriteria().getServiceNumber());
											}
										}
									}
									if ((Prop.get(TDDConstants.DEPART_STATION) != null) && display) {
										if (rbdCode.get(i)!= null && rbdCode.get(i).getOriginStation()!= null ){
											display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.DEPART_STATION).toString(),rbdCode.get(i).getOriginStation());
										}
									}
									if ((Prop.get(TDDConstants.ARRIVE_STATION) != null) && display) {
										if (rbdCode.get(i)!= null && rbdCode.get(i).getDestinationStation()!= null ){
											display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.ARRIVE_STATION).toString(),rbdCode.get(i).getDestinationStation());
										}
									}
									if ((Prop.get(TDDConstants.TICKET_TYPE) != null) && display) {
										if (ticketTypes.get(0)!= null && ticketTypes.get(0).getTicketType()!= null ){
											if (Prop.get(TDDConstants.TICKET_TYPE) instanceof String[]){
												display =ImportantInformationHelper.INSTANCE.compareResString((String[]) Prop.get(TDDConstants.TICKET_TYPE),ticketTypes.get(0).getTicketType());
											} else {
												display =ImportantInformationHelper.INSTANCE.compareResString(Prop.get(TDDConstants.TICKET_TYPE).toString(),ticketTypes.get(0).getTicketType());
											}
										}

									}

									if ((Prop.get(TDDConstants.IMPORTANT_INFO_TEXT) != null) && display) {
										String infotext = Prop.get(TDDConstants.IMPORTANT_INFO_TEXT).toString();
										int rank=1;
										if (Prop.get(TDDConstants.RANK_TEXT) != null){
											rank = Integer.parseInt(Prop.get(TDDConstants.RANK_TEXT).toString());
										}
										rbdInfoList.add(new SortInformation(rbdCode.get(i).getOrder(),rank,infotext));
									}

								}

							}
						}
				}

			}
			Collections.sort(rbdInfoList, new InformationComparator());
	        for (SortInformation rbdInf : rbdInfoList) {
	            String infotext =rbdInf.getImpInformation();
				Matcher m = TDDConstants.pattern.matcher(infotext);

				while (m.find()) {
					if (m.group(2).length()>2){
						linkedHashSet.add(m.group(2));
					}
				}

	        }

		}
		catch (Exception e)
		{
			LOG.error("Exception: Error while parsing RBD Important Information:", e);
		}

		return linkedHashSet;
	}


}

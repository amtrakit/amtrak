package com.amtrak.tdd.service;

import java.util.Properties;

import javax.xml.bind.JAXBContext;


public class PropertiesHandler {
    private static final Xml2Object xml2Object = new Xml2ObjectJaxbImpl();
	/**
	 * PropertiesHandler constructor comment.
	 */
	private PropertiesHandler() {
	}

	public static Properties getProperties() {
		Properties P = null;
		P = new Properties();
		P.put("routeName", "SELF TRANSFER");
		return P;
	}
	
	public static JAXBContext getJAXBContext(String packageName) {		
		return xml2Object.getJAXBContext(packageName);		 
	}
}
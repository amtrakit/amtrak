package com.amtrak.tdd.workflow;

/**
 * 
 * @author kganiga
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.acs.commons.email.EmailService;
import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.HistoryItem;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.commons.Externalizer;

@Component

@Service

@Properties({
		@Property(name = Constants.SERVICE_DESCRIPTION, value = "A custom workflow to Send Email Notifications to Workflow Initiator and Approver group."),
		@Property(name = "process.label", value = "TDD Approval Rejection Workflow Procss")

})
public class TDDEmailNotifier implements WorkflowProcess {

	private static final Logger LOGGER = LoggerFactory.getLogger(TDDEmailNotifier.class);
	private static final String WORKFLOW_INITIATOR_EMAIL = "./profile/email";
	SendEmailNoification sendEmailNoification = new SendEmailNoification();

	@Reference
	private EmailService emailService;

	@Reference
	private ResourceResolverFactory resourceResolverFactory;

	@Reference
	Externalizer externalizer;

	protected enum Arguments {
		PROCESS_ARGS("PROCESS_ARGS"), TEMPLATE("emailTemplate"), SEND_TO("sendTo");

		private String argumentName;

		Arguments(String argumentName) {
			this.argumentName = argumentName;
		}

		public String getArgumentName() {
			return this.argumentName;
		}

	}

	@Override
	public final void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaData)
			throws WorkflowException {
		LOGGER.info("ApprovalRejectProcess execution statrted");

		HistoryItem historyItem;
		String reviewComments = "";
		final WorkflowData workflowData = workItem.getWorkflowData();
		final String type = workflowData.getPayloadType();

		String payloadPath = workflowData.getPayload().toString();

		if (!"JCR_PATH".equals(type)) {
			return;
		}

		String[] args = buildArguments(metaData);

		String emailTemplate = getValueFromArgs(Arguments.TEMPLATE.getArgumentName(), args);

		if (emailTemplate == null) {
			LOGGER.error("Invalid process arguments, returning");
			return;
		}

		ResourceResolver resourceResolver = null;
		Map<String, Object> param = new HashMap<>();
		param.put(ResourceResolverFactory.SUBSERVICE, "workflowServiceRep");

		try {
			resourceResolver = resourceResolverFactory.getServiceResourceResolver(param);
			payloadPath = externalizer.publishLink(resourceResolver, payloadPath + ".html");

			Map<String, String> emailParams = new HashMap<>();
			emailParams.put("payloadPath", payloadPath);
			List<String> bccEmailStr = getApproverEmailInfo(resourceResolver,
					getValueFromArgs(Arguments.SEND_TO.getArgumentName(), args));
			List<HistoryItem> history = workflowSession.getHistory(workItem.getWorkflow());
			Iterator<HistoryItem> historyIterator = history.iterator();
			while (historyIterator.hasNext()) {
				historyItem = historyIterator.next();
				reviewComments = historyItem.getComment();
			}
			emailParams.put("reviewComments", reviewComments);

			String[] bccList = new String[bccEmailStr.size() + 1];
			for (int i = 0; i < bccEmailStr.size(); i++) {
				bccList[i] = bccEmailStr.get(i);
			}
			bccList[bccEmailStr.size()] = sendEmailNoification.getUserInfo(workItem, resourceResolver,
					WORKFLOW_INITIATOR_EMAIL);
			Map<String, String> wfParams = sendEmailNoification.getAdditionalParams(workItem, resourceResolver);
			if (wfParams != null) {
				emailParams.putAll(wfParams);
			}

			List<String> emailSentList = emailService.sendEmail(emailTemplate, emailParams, bccList);
			if (emailSentList.isEmpty()) {
				LOGGER.info("Email sent successfully to {} recipients", bccList.length);
			} else {
				LOGGER.error("Email sent failed");
			}

		} catch (LoginException e) {
			LOGGER.error("Could not acquire a ResourceResolver object from the Workflow Session's JCR Session: {}", e);
		}

	}

	private String[] buildArguments(MetaDataMap metaData) {

		String processArgs = metaData.get(Arguments.PROCESS_ARGS.getArgumentName(), String.class);
		if (null != processArgs && !"".equals(processArgs)) {
			return processArgs.split(",");
		} else {
			return new String[0];
		}
	}

	protected String getValueFromArgs(String key, String[] arguments) {
		for (String str : arguments) {
			String trimmedStr = str.trim();
			if (trimmedStr.startsWith(key + ":")) {
				return trimmedStr.substring((key + ":").length());
			}
		}
		return null;
	}

	protected List<String> getApproverEmailInfo(ResourceResolver resourceResolver, String userGrpPath) {
		List<String> emailList = new ArrayList<>();
		try {
			Resource authRes = resourceResolver.getResource(userGrpPath);
			if (null != authRes) {
				Authorizable authorizable = authRes.adaptTo(Authorizable.class);
				if (null != authorizable && authorizable.isGroup()) {
					Group authGroup = authRes.adaptTo(Group.class);
					if (null != authGroup) {
						Iterator<Authorizable> members = authGroup.getMembers();
						while (members.hasNext()) {
							String userEmail = getAuthorizableEmail(members.next());
							if (null != userEmail) {
								emailList.add(userEmail);
							}
						}
					}
				}

			}

		} catch (RepositoryException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return emailList;

	}

	private static String getAuthorizableEmail(Authorizable authorizable) throws RepositoryException {
		if (authorizable.hasProperty("profile/email")) {
			Value[] emailVal = authorizable.getProperty("profile/email");
			return emailVal[0].getString();
		}

		return null;
	}

}

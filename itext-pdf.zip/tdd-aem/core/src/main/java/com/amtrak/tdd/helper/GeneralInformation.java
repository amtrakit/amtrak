package com.amtrak.tdd.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;

import javax.jcr.Session;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.tdd.jcr.TicketCriteria;
import com.amtrak.tdd.service.TDDConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

public class GeneralInformation {
	
	/** Default log. */
	private static final Logger LOG = LoggerFactory.getLogger(GeneralInformation.class);
	
	/*
	 * Default Constructor
	 */
	private GeneralInformation(){
        // nothing to do.
	}

	public static Set<String> generalInformation(List<TicketCriteria> ticketTypes,String docType,QueryBuilder qbuilder,Set<String> linkedHashSet, String informationPath, Session session) {

		try {
			Date currDate = new Date();
			int logicalorder = 0;

			Map<String, String> generalmap = new HashMap<>();
			List<SortInformation> generalInfoList = new ArrayList<>();

			generalmap.put(TDDConstants.PAGE_PATH_TEXT, informationPath);
			generalmap.put(TDDConstants.NODE_TYPE_TEXT, TDDConstants.NODE_TYPE);
			generalmap.put(TDDConstants.P_HITS_TEXT, TDDConstants.P_HITS_VALUE);
			generalmap.put(TDDConstants.P_OFFSET_TEXT, TDDConstants.P_OFFSET_VALUE);
			generalmap.put(TDDConstants.P_LIMIT_TEXT, TDDConstants.P_LIMIT_VALUE);

			Query generalquery = qbuilder.createQuery(PredicateGroup.create(generalmap), session);
			generalquery.setStart(0);
			SearchResult generalresult = generalquery.getResult();

			for (Hit hit : generalresult.getHits()) {
				ValueMap Prop = hit.getProperties();

				Date astartdate = null;
				Date aenddate = null;
				Date tdate = null;
				Date pubdate = null;
				boolean bpubdate = true;

				if (Prop.get(TDDConstants.PUBLISH_DATE) != null ) {
					pubdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.PUBLISH_DATE).toString());
					if (currDate.before(pubdate)) {
						bpubdate = false;
					}
				}
				
				if (bpubdate){

				if (Prop.get(TDDConstants.START_DATE) != null) {
					astartdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.START_DATE).toString());
				}
				if (Prop.get(TDDConstants.END_DATE) != null)	{
					aenddate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.END_DATE).toString());
				}
				if (docType.equals(TDDConstants.CANCEL_REFUND)){
					tdate =currDate;
				} else {
					tdate =ImportantInformationHelper.INSTANCE.getDate(ticketTypes.get(0).getDate());
				}

				if (ImportantInformationHelper.INSTANCE.compareDates(tdate,astartdate,aenddate)) {

					if (Prop.get(TDDConstants.IMPORTANT_INFO_TEXT) != null) {
						String infotext = Prop.get(TDDConstants.IMPORTANT_INFO_TEXT).toString();
						int rank=1;
						if (Prop.get(TDDConstants.RANK_TEXT) != null){
							rank = Integer.parseInt(Prop.get(TDDConstants.RANK_TEXT).toString());
						}
						if (docType.equals(TDDConstants.CANCEL_REFUND)){
							generalInfoList.add(new SortInformation(logicalorder,rank,infotext));
						} else {
							generalInfoList.add(new SortInformation(ticketTypes.get(0).getOrder(),rank,infotext));
						}
					}
				}
				}
			}
			Collections.sort(generalInfoList, new InformationComparator());
	        for (SortInformation generalInf : generalInfoList) {
	            String infotext =generalInf.getImpInformation();
				Matcher m = TDDConstants.pattern.matcher(infotext);

				while (m.find()) {
					if (m.group(2).length()>2){
						linkedHashSet.add(m.group(2));
					}
				}

	        }


		} catch (Exception e) {
			LOG.error("Exception: Error while parsing General Information:", e);
		}

		return linkedHashSet;
	}



}

package com.amtrak.tdd.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;

import javax.jcr.Session;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.tdd.jcr.StationCriteria;
import com.amtrak.tdd.service.TDDConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

public class StationAdvisoryInformation {

	/** Default log. */
	private static final Logger LOG = LoggerFactory.getLogger(StationAdvisoryInformation.class);

	/*
	 * Default Constructor
	 */
	private StationAdvisoryInformation(){
        // nothing to do.
	}

	
	public static Set<String> stationAdvisory(List<StationCriteria> originStation,List<StationCriteria> destinationStation,QueryBuilder qbuilder,Set<String> linkedHashSet, String informationPath, Session session) {
		try {
			Date currDate = new Date();

			// create query description as hash map (simplest way, same as form post)
			Map<String, String> stationmap = new HashMap<>();
			List<SortInformation> stationInfoList = new ArrayList<>();

			stationmap.put(TDDConstants.PAGE_PATH_TEXT, informationPath);
			stationmap.put(TDDConstants.NODE_TYPE_TEXT, TDDConstants.NODE_TYPE);
			stationmap.put("group.p.or", TDDConstants.TRUE_TEXT);
			stationmap.put("group.1_property", TDDConstants.DEPART_STATION);
			for (int i = 0; i < originStation.size(); i++) {
				stationmap.put("group.1_property." + (i + 1) + "_value", "%" + originStation.get(i).getStationName() + "%");
			}
			stationmap.put("group.1_property.operation", TDDConstants.LIKE_TEXT);
			stationmap.put("group.2_property", TDDConstants.ARRIVE_STATION);
			for (int i = 0; i < destinationStation.size(); i++) {
				stationmap.put("group.2_property." + (i + 1) + "_value", "%" + destinationStation.get(i).getStationName() + "%");
			}
			stationmap.put("group.2_property.operation", TDDConstants.LIKE_TEXT);
			stationmap.put(TDDConstants.P_HITS_TEXT, TDDConstants.P_HITS_VALUE);
			stationmap.put(TDDConstants.P_OFFSET_TEXT, TDDConstants.P_OFFSET_VALUE); 
			stationmap.put(TDDConstants.P_LIMIT_TEXT, TDDConstants.P_LIMIT_VALUE); 

			Query query = qbuilder.createQuery(PredicateGroup.create(stationmap), session);

			query.setStart(0);
			SearchResult result = query.getResult();


			// iterating over the results
			for (Hit hit : result.getHits()) {

				ValueMap Prop = hit.getProperties();
				Date astartdate = null;
				Date aenddate = null;
				Date tdate = null;
				Date pubdate = null;
				boolean bpubdate = true;
				
				if (Prop.get(TDDConstants.PUBLISH_DATE) != null ) {
					pubdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.PUBLISH_DATE).toString());
					if (currDate.before(pubdate)) {
						bpubdate = false;
					}
				}


				if (Prop.get(TDDConstants.DEPART_STATION) != null && bpubdate) {

					String depstation= Prop.get(TDDConstants.DEPART_STATION).toString();
					String[] depstationArray = depstation.split(TDDConstants.SPLIT_STRING_TEXT);
					for (int i = 0; i < originStation.size(); i++) {
						for (int j=0;j<depstationArray.length;j++){
							if(depstationArray[j].equals(originStation.get(i).getStationName())){
								if (Prop.get(TDDConstants.START_DATE) != null) {

									astartdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.START_DATE).toString());
								}
								if (Prop.get(TDDConstants.END_DATE) != null) {
									aenddate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.END_DATE).toString());
								}
								if(originStation.get(i).getDate() != null){
									tdate =ImportantInformationHelper.INSTANCE.getDate(originStation.get(i).getDate());
								}

								if (ImportantInformationHelper.INSTANCE.compareDates(tdate,astartdate,aenddate)) {

									if (Prop.get(TDDConstants.IMPORTANT_INFO_TEXT) != null) {
										String infotext = Prop.get(TDDConstants.IMPORTANT_INFO_TEXT).toString();

										int rank=1;
										if (Prop.get(TDDConstants.RANK_TEXT) != null){
											rank = Integer.parseInt(Prop.get(TDDConstants.RANK_TEXT).toString());
										}
										stationInfoList.add(new SortInformation(originStation.get(i).getOrder(),rank,infotext));
										
									}

								}

							}
						}
					}

				}



				if (Prop.get(TDDConstants.ARRIVE_STATION) != null && bpubdate) {

					String arrivestation= Prop.get(TDDConstants.ARRIVE_STATION).toString();
					String[] arrivestationArray = arrivestation.split(TDDConstants.SPLIT_STRING_TEXT);


					for (int i = 0; i < destinationStation.size(); i++) {
						for (int j=0;j<arrivestationArray.length;j++){
							if(arrivestationArray[j].equals(destinationStation.get(i).getStationName())){
								if (Prop.get(TDDConstants.START_DATE) != null) {
									astartdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.START_DATE).toString());
								}
								if (Prop.get(TDDConstants.END_DATE) != null) {
									aenddate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.END_DATE).toString());
								}
								if(destinationStation.get(i).getDate() != null){
									tdate =ImportantInformationHelper.INSTANCE.getDate(destinationStation.get(i).getDate());
								}

								if (ImportantInformationHelper.INSTANCE.compareDates(tdate,astartdate,aenddate)) {

									if (Prop.get(TDDConstants.IMPORTANT_INFO_TEXT) != null) {
										String infotext = Prop.get(TDDConstants.IMPORTANT_INFO_TEXT).toString();
										int rank=1;
										if (Prop.get(TDDConstants.RANK_TEXT) != null){
											rank = Integer.parseInt(Prop.get(TDDConstants.RANK_TEXT).toString());
										}
										stationInfoList.add(new SortInformation(destinationStation.get(i).getOrder(),rank,infotext));
									}

								}

							}
						}
					}

				}

			}
			Collections.sort(stationInfoList, new InformationComparator());
	        for (SortInformation stationInf : stationInfoList) {
	            String infotext =stationInf.getImpInformation();
				Matcher m = TDDConstants.pattern.matcher(infotext);

				while (m.find()) {
					if (m.group(2).length()>2){
						linkedHashSet.add(m.group(2));
					}
				}

	        }


		} catch (Exception e) {
			LOG.error("Error while parsing Station Advisory Important Information:", e);
		}

		return linkedHashSet;

	}


}

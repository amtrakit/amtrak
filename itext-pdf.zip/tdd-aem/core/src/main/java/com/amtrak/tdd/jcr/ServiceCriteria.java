package com.amtrak.tdd.jcr;

public class ServiceCriteria extends BaseCriteria{

	private StationCriteria originStationCriteria;
	private StationCriteria destinationStationCriteria;
	private String serviceName;
	private String serviceNumber;
	
	public ServiceCriteria() {
        // nothing to do.
	}
	public ServiceCriteria(StationCriteria originStationCriteria, StationCriteria destinationStationCriteria, String serviceName, String serviceNumber) {
		super();
		this.originStationCriteria = originStationCriteria;
		this.destinationStationCriteria = destinationStationCriteria;
		this.serviceName = serviceName;
		this.serviceNumber = serviceNumber;
	}

	public StationCriteria getOriginStationCriteria() {
		return originStationCriteria;
	}
	public void setOriginStationCriteria(StationCriteria originStationCriteria) {
		this.originStationCriteria = originStationCriteria;
	}
	public StationCriteria getDestinationStationCriteria() {
		return destinationStationCriteria;
	}
	public void setDestinationStationCriteria(StationCriteria destinationStationCriteria) {
		this.destinationStationCriteria = destinationStationCriteria;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getServiceNumber() {
		return serviceNumber;
	}
	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = serviceNumber;
	}
	public String getOriginStation(){
		return originStationCriteria.getStationName();
	}
	public String getOriginDate(){
		return originStationCriteria.getDate();
	}
	public String getDestinationStation(){
		return destinationStationCriteria.getStationName();
	}
	public String getDestinationDate(){
		return destinationStationCriteria.getDate();
	}
	
}

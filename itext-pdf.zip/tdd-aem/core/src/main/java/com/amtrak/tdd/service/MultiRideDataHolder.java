package com.amtrak.tdd.service;

import java.util.Iterator;
import java.util.List;

import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket;

/*
 * Data structure to hold the multi-ride data for rendering
 * in html or pdf pages.
 * 
 * Some of the elements below are reused by both PDF and HTML
 * classes @{link TDDPDFAttachmentSessionBean} and 
 * @{link TDDGenerateReceiptHTMLSessionBean}.
 * 
 * 
 * 
 */


public class MultiRideDataHolder {
	private static final String MULTIRIDE_MULTIRIDE_TYPE = "Multiride";
	private static final String MULTIRIDE_MONTHLY_TYPE = "Monthly";
	private static final String SPACE = " ";
	private String rideType = null;
	private String rideTypeTextForPDF;
	private String rideTypeTextForHTML;
	private String dateHeaderText;
	private String dateFooterText;
	private String ruleText;
	
	
	public MultiRideDataHolder(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){
			FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = 
				formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();
			//Ticket numbers can be empty for requests of type CR
			if(itineraryRQ == null){
				rideType = null;
				return;
			}
			
			List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
			
			for(java.util.Iterator<LogicalTrip> l=logicalTripListRQ.iterator();l.hasNext();){
				List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment> 
								segmentList = l.next().getSegments().getSegment();
					//Iterate through each segment and each ticket in listing
					for(Iterator<Segment> s = segmentList.iterator();s.hasNext(); ){	
					Segment segment = new Segment();
					segment = (Segment)s.next();
						if(segment.getTickets()!=null){
							if(segment.getTickets().getTicket()!=null && !(new FormatPrintCommonFunctions().serviceFee(segment))){					
									List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket> 
										ticketList = segment.getTickets().getTicket();									
									for(Iterator<Ticket> t=ticketList.iterator();t.hasNext();) {						
										Ticket ticket = (Ticket)t.next();
										String type = ticket.getMultirideType() ;
										if(type != null) {
											ruleText = (ticket.isMultipleRidersAllowed()!=null)? 
													(ticket.isMultipleRidersAllowed() ? TDDConstants.TRANSFERABLE_VALUE:TDDConstants.NON_TRANSFERABLE_VALUE):
																													  TDDConstants.NON_TRANSFERABLE_VALUE;
											if(TDDConstants.MULTI_MONTHLY_RIDE.equals(type.toUpperCase())){
												rideType = "Monthly";
											 	rideTypeTextForHTML = "Monthly Ticket";
												//Header and footer are same for Monthly.
												dateHeaderText = TDDDateUtils.convertDateToMMMMyyyy(ticket.getNotValidBefore());
												String nonStandardMonthYearName = TDDHelperFunctions.
																		getNonStandardMonthNameFromMonthNumber(
																				TDDDateUtils.convertDateToM(ticket.getNotValidBefore())) + SPACE +
																				TDDDateUtils.convertDateToYYYY(ticket.getNotValidBefore());
												dateFooterText = nonStandardMonthYearName;
												rideTypeTextForPDF = "Monthly" + SPACE + "-" + SPACE + nonStandardMonthYearName;
											}else if(TDDConstants.MULTI_MULTIRIDE.equals(type.toUpperCase())){
												rideType = "Multiride";
												rideTypeTextForPDF = ticket.getMaxNumberOfRides() + "-Ride";
											
												rideTypeTextForHTML = TDDHelperFunctions.getWordForNumber(ticket.getMaxNumberOfRides()) + "-Ride Ticket";
												dateHeaderText = TDDDateUtils.convertDateToMMMMdyyyy(ticket.getNotValidBefore()) + SPACE + "-" + SPACE +
												TDDDateUtils.convertDateToMMMMdyyyy(ticket.getNotValidAfter());
												dateFooterText = TDDDateUtils.convertDateToMMMMd(ticket.getNotValidBefore()) +  SPACE + "-" + SPACE + 
																							TDDDateUtils.convertDateToMMMMdyyyy(ticket.getNotValidAfter());
											}
											
											//Return after the first occurence is found
											return;
										}
								 }	
							}	//Iterate through all the segments.
						} //segment not null check.
	
				}
			}	//Logical trip iteration.
		}
	
		public boolean isValid(){
			return isMonthly() || isMultiride();
		}
	
		public boolean isMonthly(){
			if(this.rideType != null && 
					( MULTIRIDE_MONTHLY_TYPE.equals(this.rideType) )){ 
				return true;
			}
	
			return false;
		}
		
	
		public boolean isMultiride(){
			if(this.rideType != null && 
					 (MULTIRIDE_MULTIRIDE_TYPE.equals(this.rideType) )){
				return true;
			}
			
			return false;
		}
		
		public String getRideType() {
			return rideType;
		}

		public String getRideTypeTextPDF() {
			return rideTypeTextForPDF;
		}
		
		public String getRideTypeTextHTML() {
			return rideTypeTextForHTML;
		}

		public String getDateHeaderText() {
			return dateHeaderText;
		}

		public String getDateFooterText() {
			return dateFooterText;
		}
		
		public String getRuleText(){
			return ruleText;
		}

}
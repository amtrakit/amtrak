package com.amtrak.tdd.helper;

import java.util.Comparator;

import org.apache.commons.lang3.builder.CompareToBuilder;

public class InformationComparator implements Comparator<SortInformation> {

	@Override
	public int compare(SortInformation o1, SortInformation o2) {
	     return new CompareToBuilder()
         .append(o1.getLogicalOrder(), o2.getLogicalOrder())
         .append(o1.getRankOrder(), o2.getRankOrder()).toComparison();
	}
	

}

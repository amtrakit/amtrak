package com.amtrak.tdd.jcr;

public class StationAdvisory {
	
	private String infolist;
	private String rank;
	
	public StationAdvisory() {
		super();
	}
	public String getInfoList() {
		return infolist;
	}
	public void setinfolist(String infolist) {
		this.infolist = infolist;
	}
	public String getrank() {
		return rank;
	}
	public void setrank(String rank) {
		this.rank = rank;
	}

}

package com.amtrak.tdd.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.Session;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.tdd.jcr.StationCriteria;
import com.amtrak.tdd.service.TDDConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

public class MultiRidePartnerIdentifier {
	
	/** Default log. */
	private static final Logger LOG = LoggerFactory.getLogger(MultiRidePartnerIdentifier.class);

	/*
	 * Default Constructor
	 */
	private MultiRidePartnerIdentifier(){
        // nothing to do.
	}

	public static String multiRidePartnerName(List<StationCriteria> originStation,List<StationCriteria> destinationStation,QueryBuilder qbuilder,String informationPath, Session session) {
		
		Map<String, String> mrpartnermap = new HashMap<>();
		boolean isOrgAmtrakStation = false;
		boolean isDesAmtrakStation = false;
		boolean isOrgPartnerStation = false;
		boolean isDesPartnerStation = false;
		Set<String> partnerName = new LinkedHashSet<>();
		Set<String> sharedPartnerName = new LinkedHashSet<>();
		List<String> partnerList = new ArrayList<>();

		try {
			Date currDate = new Date();

		mrpartnermap.put(TDDConstants.PAGE_PATH_TEXT, informationPath);
		mrpartnermap.put(TDDConstants.NODE_TYPE_TEXT, TDDConstants.NODE_TYPE);
		mrpartnermap.put(TDDConstants.P_HITS_TEXT, TDDConstants.P_HITS_VALUE);
		mrpartnermap.put(TDDConstants.P_OFFSET_TEXT, TDDConstants.P_OFFSET_VALUE);
		mrpartnermap.put(TDDConstants.P_LIMIT_TEXT, TDDConstants.P_LIMIT_VALUE);

		Query mrquery = qbuilder.createQuery(PredicateGroup.create(mrpartnermap), session);
		mrquery.setStart(0);
		SearchResult mrresult = mrquery.getResult();

		for (Hit hit : mrresult.getHits()) {
			ValueMap Prop = hit.getProperties();

			Date pubdate = null;
			boolean bpubdate = true;
			
			if (Prop.get(TDDConstants.PUBLISH_DATE) != null ) {
				pubdate = ImportantInformationHelper.INSTANCE.getInfoDate(Prop.get(TDDConstants.PUBLISH_DATE).toString());
				if (currDate.before(pubdate)) {
					bpubdate = false;
				}
			}

			if (bpubdate){
				if (Prop.get(TDDConstants.AMTRAK_STATION) != null) {
					String amtrakstation= Prop.get(TDDConstants.AMTRAK_STATION).toString();
					String[] amtrakStationArray = amtrakstation.split(TDDConstants.SPLIT_STRING_TEXT);

					for (int j=0;j<amtrakStationArray.length;j++){
						if(originStation.get(0).getStationName().equalsIgnoreCase(amtrakStationArray[j])){
							isOrgAmtrakStation = true;
						}
						if(destinationStation.get(0).getStationName().equalsIgnoreCase(amtrakStationArray[j])){
							isDesAmtrakStation = true;
						}
						
					}

				}
				if (Prop.get(TDDConstants.PARTNER_STATION) != null) {
					String amtrakstation= Prop.get(TDDConstants.PARTNER_STATION).toString();
					String[] amtrakStationArray = amtrakstation.split(TDDConstants.SPLIT_STRING_TEXT);

					for (int j=0;j<amtrakStationArray.length;j++){
						if(originStation.get(0).getStationName().equalsIgnoreCase(amtrakStationArray[j])){
							isOrgPartnerStation = true;
						}
						if(destinationStation.get(0).getStationName().equalsIgnoreCase(amtrakStationArray[j])){
							isDesPartnerStation = true;
						}
						
					}

				}
				
				if(isOrgAmtrakStation && isDesAmtrakStation){
					if (Prop.get(TDDConstants.SHARED_PARTNER_NAME) != null) {
						sharedPartnerName.add(Prop.get(TDDConstants.SHARED_PARTNER_NAME).toString());
					}
					
				} else if (isOrgPartnerStation && isDesPartnerStation) {
					if (Prop.get(TDDConstants.PARTNER_NAME) != null) {
						partnerName.add(Prop.get(TDDConstants.PARTNER_NAME).toString());
					}
					
				}
			}

		}
		
		if (!partnerName.isEmpty()) {
			partnerList.addAll(partnerName);
		}
		if (!sharedPartnerName.isEmpty()) {
			partnerList.addAll(sharedPartnerName);
		}
		if (!partnerList.isEmpty() && partnerList.size()==1){
			return partnerList.get(0).toString();
		}
		
		
		} catch (Exception e) {
			LOG.error("Exception: Error while identifying multiride partner:", e);
		}
		
		return null;
		
	}



}

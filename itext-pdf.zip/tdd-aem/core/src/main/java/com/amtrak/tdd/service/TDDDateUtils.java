/**
 * THIS PROGRAM IS CONFIDENTIAL AND PROPRIETARY TO AMTRAK AND 

 * MAY NOT BE REPRODUCED, PUBLISHED OR DISCLOSED TO OTHERS WITHOUT AUTHORIZATION.  

 * COPYRIGHT � AMTRAK.  THIS WORK IS UNPUBLISHED.


 */
package com.amtrak.tdd.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class for Date & Time
 * @author Fergus Ryder
 * @version 2.0 TDD Hardening
 *
 */
public class TDDDateUtils {

	// Define the Logger
	private static final Logger LOG = LoggerFactory.getLogger(TDDDateUtils.class);


	// Date Formats
	public static final String YYYY_MM_DD_FORMAT = "yyyy-MM-dd";

	public static final String DD_MMM_YY_FORMAT = "dd MMM yy";
	public static final String MMMM_DD_YYYY_FORMAT = "MMMM dd, yyyy";
	public static final String DDMMYY_FORMAT = "ddMMyy";
	public static final String DDMMMYY_FORMAT = "ddMMMyy";

	private String startDate;
	private String endDate;
	
	/**
	 * Constructor
	 */
	public TDDDateUtils(){
        // nothing to do.
	}
	
	/**
	 * Returns a date String formatted according to the dateFormat parameter
	 * @param date input date string (yyyy-MM-dd format is assumed)
	 * @param dateFormat output date format
	 * @return String date formatted in the output date format
	 */
	public static String getDateFormat(String date, String dateFormat) {

		// Input Date Format
		SimpleDateFormat sdfIN = new SimpleDateFormat(YYYY_MM_DD_FORMAT);
		// Output Date Format
		SimpleDateFormat sdfOUT = new SimpleDateFormat(dateFormat);
		try {
			// Parse the input date to a Java Date
            java.util.Date inputDate =  sdfIN.parse(date);
            // Format the Java Date to the output date Format
            return sdfOUT.format(inputDate);
		}
		catch (ParseException pe) {
			LOG.error("DateUtils.getDateFormat - Parse Exception thrown Input Date:" + date + " dateFormat:" + dateFormat, pe);
		}
		// Return a null on failure
		return null;
	}

	/** 
	 * Returns a date String formatted to the MMMM dd, yyyy format
	 * and in Upper Case
	 * @param date input date
	 * @return date String formatted to "MMMM dd, yyyy"
	 */
	public static String getMMMMDDYYYY(String date) {
		return getDateFormat(date, MMMM_DD_YYYY_FORMAT).toUpperCase();
	}

	/** 
	 * Returns a date String formatted to the dd MMM yy format
	 * and in Upper Case
	 * @param date input date
	 * @return date String formatted to "dd MMM yy"
	 */
	public static String getDDMONYY(String date) {
		return getDateFormat(date, DD_MMM_YY_FORMAT).toUpperCase();
	}
	
	/** 
	 * Returns a date String formatted to the "ddMMyy" format
	 * and in Upper Case
	 * @param date input date
	 * @return date String formatted to "ddMMyy"
	 */
	public static String getddMMyy(String date) {
		return getDateFormat(date, DDMMYY_FORMAT).toUpperCase();
	}
	
	/** 
	 * Returns a date String formatted to the "dd MMM yy" format
	 * @param date input date
	 * @return date String formatted to "dd MMM yy"
	 */
	public static String getDDMMMYYFormat(String date)	{	
		return getDateFormat(date, DDMMMYY_FORMAT);
	}
	
	/**
	 * Returns the current date & time formatted to "ddMMMyyhhmma"
	 * @return current date time string
	 */
	public static String getcurrentDatetime() {
		SimpleDateFormat format = new SimpleDateFormat("ddMMMyyhhmma");	
		Date date = new Date();	
		String str = format.format(date);		
		return str;	
	}

	/**
	 * Returns the current date formatted to "ddMMMyy"
	 * @return current date string
	 */
	public static String getcurrentDatetimeDDMMMYY() {
		SimpleDateFormat format = new SimpleDateFormat("ddMMMyy");	
		Date date = new Date();	
		String str = format.format(date);		
		return str;	
	}

	/**
	 * Returns a time string formatted to "h:mm a"
	 * @return formatted time string
	 */
	public static String getTime(XMLGregorianCalendar date) throws ParseException{
		//TDD3: This check is added to take care of multiride requests which
		//can have an empty date for Arrival and Departure in Segment.
		if(date == null){
			return "";
		}
		
		date.setTimezone(DatatypeConstants.FIELD_UNDEFINED);  
		SimpleDateFormat sdf = new SimpleDateFormat ( "h:mm a" ) ;
		java.util.Date tmp = date.toGregorianCalendar().getTime();
    	return sdf.format(tmp);     	 
	}

	
	/**
	 * Returns a date String formatted to "ddMMMyy"
	 * @param date input date
	 * @return formatted date String
	 */
	public static String convertDateToMMMddyyyy(XMLGregorianCalendar date) {
        String sDate = date.toString(); 
        return getDateFormat(sDate, "ddMMMyy");
	}
	
	
	/**
	 * Returns a date String formatted to "MMM d, yyyy"
	 * @param date input date
	 * @return formatted date String
	 */
	public static String convertDateToMMM_dd_yyyy(XMLGregorianCalendar date) {
		if(date == null){
    		return "";
    	}
		
        String sDate = date.toString(); 
        return getDateFormat(sDate, "MMM d, yyyy");
	}
	
	/**
	 * Returns a date String formatted to "MMMMM d, yyyy" and in Upper Case
	 * @param date input date
	 * @return formatted date String
	 */
	public static String convertDateToMMMMMddyyyy(XMLGregorianCalendar date) {
        String sDate = date.toString(); 
        return getDateFormat(sDate, "MMMMM d, yyyy").toUpperCase();
	}
	
	/**
	 * Returns a date String formatted to "MM/dd/yy" and in Upper Case
	 * @param date input date
	 * @return formatted date String
	 */
	public static String convertDateToMMddyy(String sDate) throws ParseException{
		return getDateFormat(sDate, "MM/dd/yy").toUpperCase();
	}
	

	/**
	 * Returns a date time String formatted to "MM/dd/yyyy h:mm a"
	 * @param date input date
	 * @return formatted date String
	 */
	public static String convertDateToMMddyyyyhmma(String sDate) throws ParseException{
        try {
        	Date d = (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")).parse(sDate);
        	sDate = (new SimpleDateFormat("MM/dd/yyyy h:mm a")).format(d);
	      } catch (ParseException e) {
				LOG.error("DateUtils.convertDateToMMddyyyyhmma - Parse Exception thrown Input Date:" + sDate , e);
	    	  
	      }  
	      return sDate;
	}
	
	/**
	 * Returns a date time String formatted to the input parameter
	 * @param sDate input date
	 * @param dateFormat output date format
	 * @return formatted date String
	 */
	public static String convertDateToFormat(String sDate, String dateFormat) throws ParseException{
        try {
        	
        	//Backward compatibility: SSS is removed from date, but to have backward compatibilty
        	//below logic takes care of scenarios where date has this in format
        	//TODO: Rewrite below logic when we get confirmation of complete format change.
    		SimpleDateFormat sdf = sDate.endsWith(".0Z")? new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS"):
    													  new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
         	Date d = sdf.parse(sDate);
        	sDate = (new SimpleDateFormat(dateFormat)).format(d);
	      } catch (ParseException e) {
				LOG.error("DateUtils.convertDateToFormat - Parse Exception thrown Input Date:" + sDate + " dateFormat:" + dateFormat, e);
	      }  
	      return sDate;
	}

	
	/**
	 * Returns a date time String formatted to "h:mm a EEEE, MMMMM d, yyyy"
	 * @param date input date
	 * @return formatted date String
	 */
	public static String getDateTimeForReceipts(XMLGregorianCalendar date) throws ParseException{
		date.setTimezone(DatatypeConstants.FIELD_UNDEFINED);  
		SimpleDateFormat sdf = new SimpleDateFormat ( "EEEE, MMMMM d, yyyy" ) ;
    	SimpleDateFormat sdfAct = new SimpleDateFormat("yyyy-MM-dd");
        String sDate = date.toString(); 
    	java.util.Date dtDate = sdfAct.parse(sDate);
    	return getTime(date)+", "+sdf.format(dtDate);    	 
	}
	
	/**
	 * Returns a date String formatted to "EEE MMM d"
	 * @param date input date
	 * @return formatted date String
	 */
	public static String convertDateEEEMMMd(XMLGregorianCalendar date) throws ParseException{
		if(date == null){
			return "";
		}
		
		return getDateFormat(date.toString(), "EEE MMM d");
	}
	
	/**
	 * Returns a date String formatted to "yyyy-MM-dd HH:mm:ss"
	 * Used in the Error Email
	 * @param date input date
	 * @return formatted date String
	 */
	public static String getFormattedDate(Date date) {		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sdate = df.format(date);		
		return sdate;
	}
	

 	/**
	 * Returns a date String formatted to "MMMMM yyyy" and in Upper Case
	 * @param date input date
	 * @return formatted date String
	 */
	public static String convertDateToMMMMyyyy(XMLGregorianCalendar sDate){
			return getDateFormat(sDate.toString(), "MMMMM yyyy");
	}
	
	
	/**
	 * Returns a date String formatted to "MMMMM yyyy" and in Upper Case
	 * @param date input date
	 * @return formatted date String
	 */
	public static String convertDateToMMMMdyyyy(XMLGregorianCalendar sDate){
		return getDateFormat(sDate.toString(), "MMMMM d, yyyy");
	}
	

	/**
	 * Returns a date String formatted to "MMMMM yyyy" and in Upper Case
	 * @param date input date
	 * @return formatted date String
	 */
	public static String convertDateToMMMMd(XMLGregorianCalendar sDate){
		return getDateFormat(sDate.toString(), "MMMMM d");
	}
	
	
	

	/**
	 * Returns a date String formatted to "MMM yyyy" and in Upper Case
	 * @param date input date
	 * @return formatted date String
	 */
	public static String convertDateToMMMyyyy(XMLGregorianCalendar sDate){
		return getDateFormat(sDate.toString(), "MMM yyyy");
	}
	

    public String getFirstDay(Date d) throws ParseException   
    {  
    	Calendar calendar = Calendar.getInstance();  
        calendar.setTime(d);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        Date dddd = calendar.getTime();  
        SimpleDateFormat sdf1 = new SimpleDateFormat("ddMMM");  
        return sdf1.format(dddd);
    }  
  
    public String getLastDay(Date d) throws ParseException  
    {  
        Calendar calendar = Calendar.getInstance();  
        calendar.setTime(d);  
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));  
        Date dddd = calendar.getTime();  
        SimpleDateFormat sdf1 = new SimpleDateFormat("ddMMMyy");  
        return sdf1.format(dddd);  
    } 
    
	public String getMMMYYFormat(String date) throws ParseException{		
		String MMMyy = null;		
		SimpleDateFormat sdf = new SimpleDateFormat("MMMyy");
		SimpleDateFormat sdfAct = new SimpleDateFormat("yyyy-MM-dd");		
		java.util.Date dtDate=new Date();
		dtDate = sdfAct.parse(date);
		MMMyy = sdf.format(dtDate);
	 	return MMMyy;		
	}

	public static String convertDateToM(XMLGregorianCalendar sdate) {
		return getDateFormat(sdate.toString(), "M");
	}

	public static String convertDateToYYYY(XMLGregorianCalendar sdate) {
		return getDateFormat(sdate.toString(), "yyyy");
	}
	public void setStartDate(String startDate){
		this.startDate=startDate;
	}
	public String getStartDate(){
		String opFormatDateStr=null;
		try{
			SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
		    SimpleDateFormat inputFormat ; 
		    inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
	        Date fdat=inputFormat.parse(this.startDate);
	        opFormatDateStr=sdf.format(fdat);	       
	    }
	    catch(Exception e){
			LOG.error(e.getMessage(), e);
	    	opFormatDateStr=this.startDate;
	    }

		return opFormatDateStr;
	}
	public void setEndDate(String endDate){
		this.endDate=endDate;
	}
	public String getEndDate(){
		String opFormatDateStr=null;
		try{
			SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
		    SimpleDateFormat inputFormat ; 
		    inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
	        Date fdat=inputFormat.parse(this.endDate);
	        opFormatDateStr=sdf.format(fdat);	       
	    }
	    catch(Exception e){
			LOG.error(e.getMessage(), e);
	    	opFormatDateStr=this.endDate;
	    }

		return opFormatDateStr;
	}
 }

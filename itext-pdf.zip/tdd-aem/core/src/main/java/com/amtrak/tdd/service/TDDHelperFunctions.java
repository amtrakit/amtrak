/**
 * THIS PROGRAM IS CONFIDENTIAL AND PROPRIETARY TO AMTRAK AND 

 * MAY NOT BE REPRODUCED, PUBLISHED OR DISCLOSED TO OTHERS WITHOUT AUTHORIZATION.  

 * COPYRIGHT � AMTRAK.  THIS WORK IS UNPUBLISHED.


 */
package com.amtrak.tdd.service;

import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.mulesoft.schema._2016._03._07.Advisory;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Advisories;
import com.amtrak.mulesoft.schema._2016._03._07.ObjectFactory;
import com.amtrak.mulesoft.schema._2016._03._07.Passenger;
import com.amtrak.mulesoft.schema._2016._03._07.PaymentInfo3;
import com.amtrak.mulesoft.schema._2016._03._07.PaymentSummary2;
import com.amtrak.mulesoft.schema._2016._03._07.Segment4;

/**
 * Utility class providing methods for
 * 	- Generating PDF
 *  - Generating Receipt HTML
 * @author 90000781
 *
 */
public class TDDHelperFunctions {

	// Define the Logger
	private static final Logger LOG = LoggerFactory.getLogger(TDDDateUtils.class);

	//Mapping between number to word conversion.
	private static String[] wordToNumberMapping = {"One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"};
	private static String[] monthToNumberMapping = {"Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"};
	private static final String SPACE = " ";
	

	PaymentInfo3 paymentInfo2 = (new ObjectFactory()).createPaymentInfo3();

	/**
	 * Constructor
	 */
	public TDDHelperFunctions(){
        // nothing to do.
	}
	
		
	
	/**
	 * Returns the PNRLocator from the FormatSendPsgrNotificationRequest
	 * @param formatSendPsgrNotificationRQ
	 * @return String PNRLocator
	 */
	public String getPNRLocator (FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ) {
		
	    LOG.debug("entering getPNRLocator(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

		// Log the PNR Locator
		if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification()!=null && 
				formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getBookingInfo() != null &&
				formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getBookingInfo().getPNRLocator()!=null){
		    LOG.debug("exiting getPNRLocator(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

			return formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getBookingInfo().getPNRLocator();
		
		}
	    LOG.debug("exiting getPNRLocator(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

		return "";
	}


	/**
	 * Returns whether a boiler plate or dynamic receipt is required
	 * @param formatSendPsgrNotificationRQ
	 * @return boolean
	 */
	public boolean isOriginalReceiptRequired(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ) {
		
	    LOG.debug("entering isOriginalReceiptRequired(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

		// Default return value is false for a boiler plate receipt
		boolean result = false;
		// In case of DD we won't receive Payment Summary Information
		if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getPaymentInfo() != null){
			paymentInfo2 = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getPaymentInfo();				
			if(paymentInfo2.getPayments() != null && paymentInfo2.getPayments().getPaymentSummary() != null){
				PaymentSummary2 paymentSummary = paymentInfo2.getPayments().getPaymentSummary();			
				if(paymentSummary.getPaymentDue() != null && paymentSummary.getPaymentDue().signum()== 1){
				    LOG.info("PAYMENT DUE");
					//Do not prepare PDF. Prepare only Receipt. User is payment due, so he/she shouldn't get PDF.
					if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getOperationType().equalsIgnoreCase(TDDConstants.DOCUMENT_REQUEST)){
						result = true;
		            }
				}
				else {
					if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getOperationType().equalsIgnoreCase(TDDConstants.DOCUMENT_REQUEST)){
						result = true;
					}
				}
			}
		}
		else {
	        if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getOperationType().equalsIgnoreCase(TDDConstants.DOCUMENT_REQUEST)) {
				paymentInfo2 = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getPaymentInfo();				
        		if(paymentInfo2.getPayments() != null && paymentInfo2.getPayments().getPaymentSummary() != null){
	        		return true;
        		}
	        }
		}
	    LOG.debug("exiting isOriginalReceiptRequired(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

		return result;
	}
	
	/**
	 * Method to determine if this request requires a PDF Attachment
	 * @param formatSendPsgrNotificationRQ
	 * @return boolean
	 */
	public boolean isPDFAttachmentRequired(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ, String type) {
	    LOG.debug("entering isOriginalReceiptRequired(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

		boolean isPDFRequired = false;
		// No PDF required for eVoucher/CancelReceipt/DuplicateReceipt
		if (type.equals(TDDConstants.EVOUCHER_REQUEST) || type.equals(TDDConstants.CANCEL_REFUND) 
				|| type.equals(TDDConstants.DUPLICATE_RECEIPT_REQUEST)) {
			isPDFRequired =  false;
		}
		else {
			if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getPaymentInfo() != null){
				// Get the Payment Information
				paymentInfo2 = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getPaymentInfo();
				if(paymentInfo2.getPayments() != null && paymentInfo2.getPayments().getPaymentSummary() == null){
					isPDFRequired = true;
				}
				else {
					PaymentSummary2 paymentSummary = paymentInfo2.getPayments().getPaymentSummary();			
					if(paymentSummary.getPaymentDue() == null || paymentSummary.getPaymentDue().signum()!= 1){
						isPDFRequired = true;
					}
				}
			}
			else {
				isPDFRequired = true;
			}
		}
	    LOG.debug("exiting isPDFAttachmentRequired(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

		return isPDFRequired;
	}

	/**
	 * Method to determine the type of receipt required for the standard email
	 *  - Purchase Summary
	 *  - Even Exchange
	 *  - Cancel Refund
	 *  - Upgrade New Money
	 *  - Upgrade Amount Due
	 *  - Downgrade Refund
	 * @param formatSendPsgrNotificationRQ
	 * @return String
	 */
	public String identifyReceiptType(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){	

	    LOG.debug("entering identifyReceiptType(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

		// Get the Payment Information
		paymentInfo2 = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getPaymentInfo();
		PaymentSummary2 paymentSummary = paymentInfo2.getPayments().getPaymentSummary();
		// Initialize the receipt type
		String receiptType = "";
		
		//For UPGRADE_NEW_MONEY there might be a situation where there is no modified time but paymentDue is > 0.
		if( (paymentInfo2.getModifiedDateTime() == null || paymentInfo2.getModifiedDateTime().isEmpty()) && 
				!(paymentSummary.getPaymentDue() != null && paymentSummary.getPaymentDue().floatValue() > 0)){
	    	//Purchase Summary	    
	    	receiptType = TDDConstants.PURCHASE_SUMMARY;
	    }else{	    	
	    	if(paymentSummary.getAvailableTktAmt() != null &&
	    			paymentSummary.getNewTktAmt() != null && paymentSummary.getEVoucherAmt() != null &&
	    			(Float.floatToRawIntBits(paymentSummary.getAvailableTktAmt().floatValue()) == Float.floatToRawIntBits(paymentSummary.getEVoucherAmt().floatValue() + paymentSummary.getNewTktAmt().floatValue()))){
	    		//Even Exchange	    		
	    		receiptType = TDDConstants.EVEN_EXCHANGE;
	    	}else if(paymentSummary.getAvailableTktAmt() != null &&
	    			paymentSummary.getNewTktAmt() != null &&
	    			(Float.floatToRawIntBits(paymentSummary.getAvailableTktAmt().floatValue()) == Float.floatToRawIntBits(paymentSummary.getNewTktAmt().floatValue()))){
	    		//Even Exchange	    		
	    		receiptType = TDDConstants.EVEN_EXCHANGE;
	    	}else if((paymentSummary.getNewTktAmt() == null ||
	    			Float.floatToRawIntBits(paymentSummary.getNewTktAmt().floatValue()) == 0) 
	    			&& paymentSummary.getRefundAmt() != null){
	    		//Cancel Refund
	    		receiptType = TDDConstants.CANCEL_REFUND;
	    	}else if(paymentSummary.getNewTktAmt() != null && paymentSummary.getNewTktAmt().floatValue() > 0
	    			&& ((paymentSummary.getPaidAmt() != null && paymentSummary.getPaidAmt().floatValue() > 0) 
	    					&&(paymentSummary.getEVoucherAmt() != null && paymentSummary.getEVoucherAmt().floatValue() > 0))){
	    		//Downgrade with Refund
	    		receiptType = TDDConstants.UPGRADE_NEW_MONEY;
	    	}else if(paymentSummary.getNewTktAmt() != null && paymentSummary.getNewTktAmt().floatValue() > 0
	    			&& ((paymentSummary.getPaidAmt() != null && paymentSummary.getPaidAmt().floatValue() > 0) 
	    					&&(paymentSummary.getForfeitAmt() != null && paymentSummary.getForfeitAmt().floatValue() > 0))){
	    		//Downgrade with Refund
	    		receiptType = TDDConstants.UPGRADE_NEW_MONEY;	    		
	    	}else if(paymentSummary.getNewTktAmt() != null && paymentSummary.getNewTktAmt().floatValue() > 0
	    			&& ((paymentSummary.getRefundAmt() != null && paymentSummary.getRefundAmt().floatValue() > 0) 
	    					||(paymentSummary.getEVoucherAmt() != null && paymentSummary.getEVoucherAmt().floatValue() > 0))){
	    		//Downgrade with Refund
	    		receiptType = TDDConstants.DOWNGRADE_REFUND;
	    	}else if(paymentSummary.getAvailableTktAmt() != null &&
	    			paymentSummary.getNewTktAmt() != null && 
	    			paymentSummary.getNewTktAmt().floatValue() > paymentSummary.getAvailableTktAmt().floatValue()){
	    		if(paymentSummary.getPaymentDue() != null){
	    			//Upgrade with Amount Due
		    		receiptType = TDDConstants.UPGRADE_AMOUNT_DUE;
	    		}else{
	    			//Upgrade with New Money
		    		receiptType = TDDConstants.UPGRADE_NEW_MONEY;
	    		}
	    	}
	    }
	    LOG.debug("exiting identifyReceiptType(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ)");

		return receiptType;
	}

	/**
	 * Returns a Currency Instance for the US Locale
	 * @param fare
	 * @return String
	 */
	public String getCurrencyFormat(float fare){
		return java.text.NumberFormat.getCurrencyInstance(Locale.US).format(fare).replace(",", "");
	}

	/**
	 * Returns the fare amount formatted with Currency OR the BULK_TEXT_VALUE
	 * if this is a bulk fare reservation.
	 * @param fare float
	 * @param applyBulk boolean
	 * @return String
	 */
	public String getTotalAmountFormat(float fare, boolean applyBulk){
		if (applyBulk) {
			return TDDConstants.BULK_TEXT_VALUE;
		}
		return getCurrencyFormat(fare);
	}

	
    /**
     * Method to XML encode a String.  Calls XMLHelper.protectSpecialCharacters
     * @param message
     * @return String encoded String
     */
	public String getEncodedHtml(String msg) {
		// need to encode the message since it's in xml and xml special 
		// characters would wreck the html
		String message = msg;
		message = XMLHelper.protectSpecialCharacters(message);		
		return message;
	}

	/**
	 * Method to return the first letter of a string in upper case
	 * @param s
	 * @return String
	 */
	public String firstLetterUpperCase(String str){   
	    LOG.debug("entering firstLetterUpperCase(string)");
	    String s= str;
		s = s.trim().toLowerCase();
		StringBuilder result = new StringBuilder(s.length());
		String[] words = s.split("\\s");
		for(int i=0,l=words.length;i<l;++i) {
		  if(i>0) result.append(" ");      
		  result.append(Character.toUpperCase(words[i].charAt(0)))
		        .append(words[i].substring(1));	
		}
	    LOG.debug("exiting firstLetterUpperCase(string)");

		return result.toString();
	}

	/**
	 * Returns the Carrier Type based on the Equipment Code.  
	 * Possible values are TRAIN/BUS/FERRY/LIMO
	 * @param segment Train Segment
	 * @return Carrier Type
	 */
	public String getCarrierType(Segment4 segment){
        String carrierType=""; 
        if(segment.getTrainDetails().getEquipmentCode()!= null){
            String eqpCode = segment.getTrainDetails().getEquipmentCode();
              if(eqpCode.equalsIgnoreCase(TDDConstants.THS) ){ 
                    carrierType=TDDConstants.TRAIN; 
              }else if(eqpCode.equalsIgnoreCase(TDDConstants.TRN)){ 
                    carrierType=TDDConstants.TRAIN;   
              }else if(eqpCode.equalsIgnoreCase(TDDConstants.CTR)){  
                    carrierType=TDDConstants.TRAIN; 
              }else if(eqpCode.equalsIgnoreCase(TDDConstants.TSL)){ 
                    carrierType=TDDConstants.TRAIN;
              }else if(eqpCode.equalsIgnoreCase(TDDConstants.TAT)){ 
                    carrierType=TDDConstants.TRAIN; 
              }else if(eqpCode.equalsIgnoreCase(TDDConstants.BUS)){  
                    carrierType=TDDConstants.BUS;   
              }else if(eqpCode.equalsIgnoreCase(TDDConstants.LCH)){ 
                    carrierType=TDDConstants.FERRY;     
              }else if(eqpCode.equalsIgnoreCase(TDDConstants.LMO)){  
                    carrierType=TDDConstants.LIMO;     
              } 
        }
        return carrierType;  
	}
	
	/*
	 * Extracts the DepartureDate from the itinerary, picks the  date in 
	 * the first segment (if there are multiple segments) extracts date 
	 * in the format <code>mm/dd/YYYY e.g 06/20/2013 </code> and returns.
	 * 
	 * @return formatted date or empty string if itinerary or segments are not
	 * 							 available.
	 */
		
	 public String getTravelDateFormatted(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){
			FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = 
									formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();
			
			//Itinerary numbers can be empty for requests of type CR
			if(itineraryRQ == null){
				return SPACE;
			}
			
			List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
		    
		    for(java.util.Iterator<LogicalTrip> l=logicalTripListRQ.iterator();l.hasNext();){
		    	List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment> 
		    						segmentList = l.next().getSegments().getSegment();
		    	//Iterate through each segment
	    		for(Iterator<Segment> s = segmentList.iterator();s.hasNext(); ){	
	    			Segment segment = new Segment();
					segment = (Segment)s.next();
	    			XMLGregorianCalendar date  = segment.getDepartureDateTime();
	    			
	    			if(date != null){
	    				//MM/DD/YYYY format is expected.
	    				String dateStr = new SimpleDateFormat("MM/dd/yyyy").format(date.toGregorianCalendar().getTime());
						return dateStr;
					}
	    		}
			
		    }
		
		    return SPACE;
		}
	 
		public String getFirstTicketNumber(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){
			FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = 
									formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();
			List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
		    
		    for(java.util.Iterator<LogicalTrip> l=logicalTripListRQ.iterator();l.hasNext();){
		    	List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment> 
		    						segmentList = l.next().getSegments().getSegment();
		    	//Iterate through each segment
	    		for(Iterator<Segment> s = segmentList.iterator();s.hasNext(); ){	
	    			Segment segment = new Segment();
					segment = (Segment)s.next();
	    			if(segment.getTickets()!=null){
						if(segment.getTickets().getTicket()!=null && !(new FormatPrintCommonFunctions().serviceFee(segment))){					
							List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket> ticketList = segment.getTickets().getTicket();									
							for(Iterator<Ticket> t=ticketList.iterator();t.hasNext();) {						
								Ticket ticket = (Ticket)t.next();
								String ticketNumber = ticket.getTicketNumber();
								if(ticketNumber != null){
									return ticketNumber;
								}
							 }											
						 }	
					}	
		    	
	    		}
			
		    }
		
		    return "";
		}
	    

		public static String getWordForNumber(String maxNumberOfRides) {
			int value = Integer.parseInt(maxNumberOfRides);
			String wording = wordToNumberMapping[value - 1];
			return wording;
		}
		
		public static String getNonStandardMonthNameFromMonthNumber(String monthNumberStr){
			Integer monthNumber = Integer.valueOf(monthNumberStr);
			if(monthNumber > 12 || monthNumber <= 0){
				throw new IllegalArgumentException("Month is out of range " + monthNumberStr);
			}
			return monthToNumberMapping[monthNumber - 1];
		}
		
		
		String getPsgrInfoForSubject(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){
			 List<Passenger> passengersList = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getPassengers().getPassenger(); 
			//Passenger Name		
			String passengerName="";
			if (passengersList != null && !passengersList.isEmpty()) {    	
				if(passengersList.size() > 1)
					passengerName = " - "+ passengersList.get(0).getPassengerName().getLastName()+ " Party" ;
				else
					passengerName = " - "+ passengersList.get(0).getPassengerName().getFirstName() + " " + passengersList.get(0).getPassengerName().getLastName();	
	 	  	}
			return passengerName;
		 }

		 
		 public Set<String> getUniqueAdvisoryList(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){
			 	Set<String> advisorySet = new LinkedHashSet<String>(10);
				FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = 
										formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();
				
				Advisories advisories = null;
				
				//Itinerary numbers can be empty for requests of type CR
				if(itineraryRQ == null){
					return null;
				}
				
				List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
			    
			    for(java.util.Iterator<LogicalTrip> l=logicalTripListRQ.iterator();l.hasNext();){
			    	List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment> 
			    						segmentList = l.next().getSegments().getSegment();
			    	//Iterate through each segment
		    		for(Segment s: segmentList){	
		    			advisories = s.getAdvisories();
		    			if(advisories != null){
			    			List<Advisory> advisory = advisories.getAdvisory();
			    			
			    			for(Advisory a: advisory){
			    				advisorySet.add(a.getStationCode().toUpperCase().trim());
			    			}
		    			}
					}
				
			    }

			 
			 
			 
			 return advisorySet;
		 }
		 
		 
		 public boolean shouldDisplayAdvisory(String code, Segment s){
			 		Advisories advisories = s.getAdvisories();
	    			if(advisories != null){
		    			List<Advisory> advisory = advisories.getAdvisory();
		    			//If the segment
		    			for(Advisory a: advisory){
		    				if(a.getStationCode().equals(code)){
		    					return true;
		    				}
		    			}
	    			}
	    			
	    			return false;
		}
			 
		 
		
}
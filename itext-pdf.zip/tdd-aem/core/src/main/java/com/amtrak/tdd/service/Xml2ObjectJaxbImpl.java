package com.amtrak.tdd.service;

import java.io.ByteArrayInputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;




public class Xml2ObjectJaxbImpl implements Xml2Object {
	
	
@Override
public Object getMessageObject(String message, Class<?> clazz, String schemaName) {
		
		
		try {
				
			if (schemaName == null) {
				throw new IllegalArgumentException("schemaName must be specfied");
			}
			String packageName = clazz.getPackage().getName();
			// Get a context and unmarshaller
			JAXBContext context = JaxbUtils.getContext(packageName);			
			Unmarshaller unmarshaller = JaxbUtils.getUnmarshaller(schemaName, context);			
	        ByteArrayInputStream messageBytes = new ByteArrayInputStream(message.getBytes());
	        Object unmarshalledObject = unmarshaller.unmarshal(messageBytes);
	       
	        
			return unmarshalledObject;
	        
		} catch (JAXBException jaxbe) {			
			throw new Xml2ObjectException(jaxbe);
		}
	}

	@Override
	public JAXBContext getJAXBContext(String packageName){
		return JaxbUtils.getContext(packageName);
	}	
}

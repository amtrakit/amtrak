package com.amtrak.tdd.service;

import java.io.StringReader;
import java.net.URI;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ;

public abstract class JaxbUtils {

	// Define the Logger
	private static final Logger LOG = LoggerFactory.getLogger(JaxbUtils.class);

	
	/** Private c'tor so it does not get instantiated. */
	private JaxbUtils() {
	}
	
	// The JAXB docs state that JAXBContext's are expensive to create, but  
	// are tread safe, so make one per package and reuse 
	private static Map<String, JAXBContext> contextMap = 
		Collections.synchronizedMap(new HashMap<String, JAXBContext>());
	
	/**
	 * Gets a JAXBContext by package name - protected access so only used within the package.
	 * 
	 * @param packageName The package name.
	 * @return The JAXBContext.
	 */
	protected static JAXBContext getContext(String packageName) {
	
		JAXBContext context = contextMap.get(packageName);
		if (context == null) {
			
			synchronized(contextMap) {
				
				context = contextMap.get(packageName);
				if (context == null) {
					
					try {
	
						ElapsedTime elapsedTime = new ElapsedTime("Xml2ObjectJaxbImpl.getContext");
						context = JAXBContext.newInstance(packageName);
						elapsedTime.stop();
					    LOG.info("ElapsedTime : "+elapsedTime);
						
					} catch (JAXBException jaxbe) {
						
						throw new Xml2ObjectException(jaxbe);						
					} 
					
					contextMap.put(packageName, context);
				}
			}
		}
		
		return context;
	}
	
	/**
	 * Gets an Unmarshaller - protected access so only used within the package.
	 *
	 * @param schemaName the schema name.
	 * @param context The JAXBContext.
	 * @return The Unmarshaller.
	 */
	protected static Unmarshaller getUnmarshaller(String schemaName, JAXBContext context) {
		
		try {
			
//TODO: marshallers/unmarshallers are not thread safe, but may be able to improve 
//		performance with some type of cache/pool as opposed to creating every time, 
//		test in-container to see if it's necessary
			
			ElapsedTime elapsedTime = new ElapsedTime("Xml2ObjectJaxbImpl.getUnmarshaller-" + schemaName);
			Unmarshaller unmarshaller = context.createUnmarshaller();

			if (schemaName != null) {
				
				Schema schema = getSchema(schemaName);				
				if (schema != null) {
					
					unmarshaller.setSchema(schema);
					
				} else {
				
	            	throw new JAXBException("Could not get schema for schemaName=" + schemaName);
				}
			}

			elapsedTime.stop();
		    LOG.info("ElapsedTime : "+elapsedTime);
			
			return unmarshaller;
			
		} catch (Exception e) {

			throw new Xml2ObjectException(e);						
		}
	}

	// Taken from http://robaustin.wikidot.com/how-to-improve-perforamance-of-jaxb
	private static Schema getSchema(String schemaName) {
		
		String schemaLocation = TDDConstants.BASE_SCHEMA_LOCATION + schemaName;
		
        final SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        
        try {
        	
            URL url = Thread.currentThread().getContextClassLoader().getResource(schemaLocation);
		    LOG.info("schemaLocation=" + schemaLocation + " url=" + url);
           
            if (url == null) {
            	throw new JAXBException("Could not get url for schemaLocation=" + schemaLocation);
            }
            
            URI uri = url.toURI();
            Schema schema = schemaFactory.newSchema(toStreamSources(uri));
            
            return schema;
            
        } catch (Exception e) {
        	
			throw new Xml2ObjectException(e);						
        }
	}

    private static Source[] toStreamSources(final URI stream) {
    	
        return new Source[]{new StreamSource(stream.toString())};
    }

	public static FormatSendPsgrNotificationRQ createFormatSendPsgrNotificationRQ(StringReader reader) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(FormatSendPsgrNotificationRQ.class);

		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		
		FormatSendPsgrNotificationRQ sprq = (FormatSendPsgrNotificationRQ) unmarshaller.unmarshal(reader);
		return sprq;
	}

}
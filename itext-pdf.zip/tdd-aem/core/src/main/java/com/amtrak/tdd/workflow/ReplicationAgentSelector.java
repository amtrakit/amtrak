package com.amtrak.tdd.workflow;

/**
 * 
 * @author kganiga
 * 
 */
import java.util.HashMap;
import java.util.Map;
import javax.jcr.Session;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.replication.AgentIdFilter;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.ReplicationOptions;
import com.day.cq.replication.Replicator;

@Component

@Service

@Properties({ @Property(name = Constants.SERVICE_DESCRIPTION, value = "A custom workflow on replication Agent."),
		@Property(name = "process.label", value = "Custom Replication Agent Selector") })

public class ReplicationAgentSelector implements WorkflowProcess {

	@Reference
	private ResourceResolverFactory resolverFactory;

	@Reference
	private Replicator replicator;

	private static final Logger LOGGER = LoggerFactory.getLogger(ReplicationAgentSelector.class);
	private static final String TYPE_JCR_PATH = "JCR_PATH";

	@Override
	public void execute(WorkItem item, WorkflowSession workflowSession, MetaDataMap args) throws WorkflowException {
		LOGGER.info("ReplicationAgentSelector Workflow execution started");

		ResourceResolver resourceResolver = null;

		Map<String, Object> param = new HashMap<>();
		param.put(ResourceResolverFactory.SUBSERVICE, "workflowServiceRep");

		Session session = null;
		String payloadPath;
		String[] replicationAgent;
		String defaultReplicationAgent = "publish";

		WorkflowData workflowData = item.getWorkflowData();

		if (workflowData.getPayloadType().equals(TYPE_JCR_PATH)) {
			payloadPath = workflowData.getPayload().toString() + "/jcr:content";
			LOGGER.info("Payload Path:" + payloadPath);
			replicationAgent = buildProcessArguments(args.get("PROCESS_ARGS", defaultReplicationAgent));
			LOGGER.info("Replication Agents:" + replicationAgent);
			try {
				resourceResolver = resolverFactory.getServiceResourceResolver(param);
				session = resourceResolver.adaptTo(Session.class);
				ReplicationOptions replicationOptions = new ReplicationOptions();
				for (String repAgent : replicationAgent) {
					AgentIdFilter repAgentFilter = new AgentIdFilter(repAgent);
					LOGGER.info("Active Replication Agent " + repAgentFilter);
					replicationOptions.setFilter(repAgentFilter);
					replicator.replicate(session, ReplicationActionType.ACTIVATE, payloadPath, replicationOptions);
					LOGGER.info("ReplicationAgentSelector Workflow execution completed.");
				}

			} catch (ReplicationException | LoginException e) {
				LOGGER.error(e.getMessage(), e);
			}
		} else {
			LOGGER.error("Payload type is not a " + TYPE_JCR_PATH);
		}

	}

	private String[] buildProcessArguments(String args) {
		String processArgs = args;
		String[] processArgsArr = null;
		if (null != processArgs && !"".equals(processArgs)) {
			processArgsArr = processArgs.split(",");
		}
		return processArgsArr;
	}

}

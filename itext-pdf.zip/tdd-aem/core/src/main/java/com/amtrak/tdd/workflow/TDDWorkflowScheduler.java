package com.amtrak.tdd.workflow;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * 
 * @author kganiga
 * 
 */
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.adobe.granite.workflow.exec.HistoryItem;
import java.text.ParseException;

@Component

@Service

@Properties({ @Property(name = Constants.SERVICE_DESCRIPTION, value = "TDD Activation Scheduler"),
		@Property(name = "process.label", value = "TDD Activation Scheduler")

})

public class TDDWorkflowScheduler implements WorkflowProcess {
	private static final Logger LOGGER = LoggerFactory.getLogger(TDDWorkflowScheduler.class);

	@Override
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap args) throws WorkflowException {
		String sDate;
		HistoryItem historyItem;
		List<HistoryItem> history = workflowSession.getHistory(workItem.getWorkflow());
		Iterator<HistoryItem> historyIterator = history.iterator();
		Long absoluteTime = null;
		Date formattedDate = null;
		while (historyIterator.hasNext()) {
			historyItem = historyIterator.next();
			if (historyItem.getWorkItem().getMetaDataMap().containsKey("scheduleDate")) {
				sDate = historyItem.getWorkItem().getMetaDataMap().get("scheduleDate", String.class);
				if (null != sDate && !"".equals(sDate)) {
					SimpleDateFormat inputFormat;
					inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
					try {
						formattedDate = inputFormat.parse(sDate);
					} catch (ParseException e) {
						LOGGER.error(e.getMessage());
					}
					if(null != formattedDate){
						absoluteTime = formattedDate.getTime();
					}
					
				}
				if (null == formattedDate || !formattedDate.after(new Date())) {
					absoluteTime = new Date().getTime();
				}
				if (!workItem.getWorkflow().getWorkflowData().getMetaDataMap().containsKey("absoluteTime")) {
					workItem.getWorkflow().getWorkflowData().getMetaDataMap().put("absoluteTime", absoluteTime);
				}
			}

		}
	}

}

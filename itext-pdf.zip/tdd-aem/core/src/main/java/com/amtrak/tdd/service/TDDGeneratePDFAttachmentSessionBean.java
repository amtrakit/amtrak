/**
 * THIS PROGRAM IS CONFIDENTIAL AND PROPRIETARY TO AMTRAK AND 

 * MAY NOT BE REPRODUCED, PUBLISHED OR DISCLOSED TO OTHERS WITHOUT AUTHORIZATION.  

 * COPYRIGHT ï¿½ AMTRAK.  THIS WORK IS UNPUBLISHED.


 */
package com.amtrak.tdd.service;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;

import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip.Segments.Segment.Tickets.Ticket;
import com.amtrak.mulesoft.schema._2016._03._07.Membership;
import com.amtrak.mulesoft.schema._2016._03._07.Passenger;
import com.amtrak.mulesoft.schema._2016._03._07.Segment4;
import com.amtrak.tdd.servlets.JCRService;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.DottedLineSeparator;
import com.itextpdf.text.pdf.draw.LineSeparator;
import com.itextpdf.tool.xml.XMLWorkerHelper;

/**
 * PDF Attachment Session Bean
 * Will generate a PDFAttachment information in the TDDBookingInfo
 */

public class TDDGeneratePDFAttachmentSessionBean  {

	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(TDDGeneratePDFAttachmentSessionBean.class);
	private static final int PDF_MID_Y_POSITION_IN_PIXEL = 280;
	
	@Resource(name="PWD_PDF_MEET_ASSIST_TEXT")
	private String pwdPDFAdvisoryText;
	
	
	//TODO:Resource injection point for JUnit to work. Better manage this
	//when the number of configurable resources increase (now only one).
	public TDDGeneratePDFAttachmentSessionBean(String pwdPDFAdvisoryText) {
    	this.pwdPDFAdvisoryText  = pwdPDFAdvisoryText;
    }
	

	/**
     * Default constructor. 
     */
    public TDDGeneratePDFAttachmentSessionBean() {
		LOG.info("inside class TDDGeneratePDFAttachmentSessionBean");

    }

	/*
	 * This is a dynamic value that is computed at runtime
	 * based on the number of endorsements. The intial default
	 * value is set to 3.
	 */
	
	private int MAX_LIMIT_OF_ENDORSEMENTS_PER_COLUMN = 3;
	/*
	 * Stores, the number of endorsements that is received by this
	 * application for processing
	 */
	private int totalNumberOfEndorsements;
	private  MultiRideDataHolder multiRideType = null;

	
	// Holder for the TDD custom properties
	private Properties myProperties = new Properties();
	// PDF Shading Fonts
	BaseFont cyanShading, purpShading, grayShading, greenShading, blueShading, orangeShading;
	// Barcode4J class required to build the PDF barcode images.
	private static Barcode4j barcode4j = new Barcode4j();
	// PDF fields - will be populated.
	String[] orgStationCode = new String[60];
	String[] desStationCode = new String[60];
	String[] orgStationCity = new String[60];
	String[] desStationCity = new String[60];
	String[] orgStationState = new String[60];
	String[] desStationState = new String[60];
	String[] orgStationStreet = new String[60];
	String[] desStationStreet = new String[60];
	String tripStartDate = null;
	String tripStartDateFooter = null;
	String tktType = null;
	String orgSttCode = null;;
	String desSttCode = null;
	String orgCity = null;
	String desCity = null;
	String orgStreet = null;
	String desStreet = null;
	String PNRNumber = null;
	int bxForRoundTrip = 0;
	int endOfPage = 700;
	int bxFrmTop = 0;
	boolean newPageFlg = false;
	int pageNum = 1;
	boolean rndTripFlg = false;
	int rtnOnBox = 0;
	boolean autoTrain = false;
	int orgStreetLength = 14;
	int psgrNameLength = 23;
	int routeNameLength = 20;
	int trainOrgDesLength = 32;
	int desCityLength = 22;
	int orgCityLength = 22;
	int psgrTypeLen = 22;
	int rbdDescLength = 45;
	int endorsementLength = 54;
	List<String> tripSequence = new ArrayList<>();

	boolean feeElement = true;
	List<String> formOfPayment = new ArrayList<>();
	List<String> impInfoList = new ArrayList<>();
	int noOfLogicalTrips = 0;
	List<BigInteger> psgrToBeDisplayed = new ArrayList<>();
	List<BigInteger> psgrToBeDisplayedForEndorsements = new ArrayList<>();
	float expressDeliveryFee = 0;
	
	boolean errorFlg = false;
	
	boolean isCCJPA = false;
	
	String phoneNumber = "";

	// Utility Class
	TDDHelperFunctions tddCommonFunctions = new TDDHelperFunctions();
	
	public byte[] createPDF(TDDBookingInfo bookingInfo)  {
		return createPDF(null, bookingInfo);
	}

    /**
     * Public method to create a PDF Attachment using the iText library.  All the PDF 
     * details are stored in the TDDBookingInfo object.
     * @param context 
     */
    public byte[] createPDF(JCRService jcrService, TDDBookingInfo bookingInfo) {
    

		LOG.info("inside method createPDF(bookingInfo)");
		LOG.debug("createPDF(bookingInfo)" + bookingInfo.toString());

    	// Initialize all global variables
    	initializeGlobalVariables();
    	
    	// Retrieve the FormatRequest from the bookingInfo
    	FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ = bookingInfo.getBookingRequest();
    	this.multiRideType =  new MultiRideDataHolder(formatSendPsgrNotificationRQ);
    	this.isCCJPA =  TDDBookingUtils.isCCJPARequest(formatSendPsgrNotificationRQ);
    		
    	ElapsedTime elapsedTime = new ElapsedTime("TDD *** PreparePDFAttachment: PNR: " + bookingInfo.getBookingPNRNumber());
    	// Create the PDF Document
    	Document document = new Document(PageSize.LETTER, 30, 30, 45, 20);
    	ByteArrayOutputStream byteTemp=new ByteArrayOutputStream();  

    	try {
    		LOG.info("Starting preparation of PDF document**");
        	// Load the TDDCustom Properties
        	this.myProperties = PropertiesHandler.getProperties();
        	 
        	//When all the coding is finished use following two lines to get the bytes out of PDF document and send it to NUANCE
        	PdfWriter writer =  PdfWriter.getInstance(document, byteTemp); 
			writer.setFullCompression();
			purpShading = BaseFont.createFont ("FTL_____.PFM", BaseFont.CP1252, BaseFont.NOT_EMBEDDED, true, IOUtils.toByteArray(this.getClass().getResource("/Fonts/FTL_____.PFM").openConnection().getInputStream()), null);
         	grayShading = BaseFont.createFont ("FTB_____.PFM", BaseFont.CP1252, BaseFont.NOT_EMBEDDED, true, IOUtils.toByteArray(this.getClass().getResource("/Fonts/FTB_____.PFM").openConnection().getInputStream()), null);
         	greenShading = BaseFont.createFont ("FTBC____.PFM", BaseFont.CP1252, BaseFont.NOT_EMBEDDED, true, IOUtils.toByteArray(this.getClass().getResource("/Fonts/FTBC____.PFM").openConnection().getInputStream()), null);
         	blueShading = BaseFont.createFont ("FTLC____.PFM", BaseFont.CP1252, BaseFont.NOT_EMBEDDED, true, IOUtils.toByteArray(this.getClass().getResource("/Fonts/FTLC____.PFM").openConnection().getInputStream()), null);
         	orangeShading = BaseFont.createFont ("FTC_____.PFM", BaseFont.CP1252, BaseFont.NOT_EMBEDDED, true, IOUtils.toByteArray(this.getClass().getResource("/Fonts/FTC_____.PFM").openConnection().getInputStream()), null);
         	cyanShading = BaseFont.createFont ("FTR_____.PFM", BaseFont.CP1252, BaseFont.NOT_EMBEDDED, true, IOUtils.toByteArray(this.getClass().getResource("/Fonts/FTR_____.PFM").openConnection().getInputStream()), null);
        	
        	//Open PDF File
        	writer.setBoxSize("art", new Rectangle(30, 20, 582, 747));          	
        	TableHeader event = new TableHeader();        	 
            writer.setPageEvent(event);             
        	document.open();            
        	PdfContentByte cb = writer.getDirectContent();
        	Rectangle rect = writer.getBoxSize("art");
        	rect.setBorderColor(BaseColor.BLUE);        	

            //Add content to document            
            //*** 1)Add Barcode Image
            PNRNumber = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getBookingInfo().getPNRLocator();
            String pnrForBarCode = getPNRNumber(formatSendPsgrNotificationRQ);
    		com.itextpdf.text.Image img1 = com.itextpdf.text.Image.getInstance(barcode4j.qrBarCode(pnrForBarCode));
    		img1.scalePercent(24f);
    		img1.setCompressionLevel(9);
    		LOG.debug("DPI X: "+img1.getDpiX()+" DPI Y: "+img1.getDpiX()+" Compression level: "+img1.getCompressionLevel());

    		img1.setAlignment(com.itextpdf.text.Image.ALIGN_CENTER);
    		img1.setAbsolutePosition(document.left()+50, document.top()-80);
            img1.scaleAbsolute(80f, 80f);
    		document.add(img1);
    		
    		//*** 2)Add Amtrak Image
    		URL url = this.getClass().getResource("/images/Amtrak-Logo.png");
    		InputStream is = url.openConnection().getInputStream();
     		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
    		int nRead;
    		byte[] data = new byte[16384];
    		while ((nRead = is.read(data, 0, data.length)) != -1) {
    		  buffer.write(data, 0, nRead);
    		}    		
    		com.itextpdf.text.Image amtLogo = com.itextpdf.text.Image.getInstance(buffer.toByteArray());
    		amtLogo.setAbsolutePosition(310, document.top()-20);
    		amtLogo.setAlignment(Element.ALIGN_LEFT);
    		amtLogo.scaleAbsolute(130f, 15f);
    		document.add(amtLogo);
    		
    		Font tnr = new Font(cyanShading, 24, Font.NORMAL);		
    		//*** 3)Add eTicket Literal
    		ColumnText.showTextAligned(cb, Element.ALIGN_TOP, new Phrase("eTicket",tnr), 448, document.top()-20, 0);
    		
    		//*** 4)Add PRESENT THIS DOCUMENT FOR TRAVEL Literal
    		cb.rectangle(260,document.top()-55,330,24);
        	cb.stroke ();            
            tnr = new Font(cyanShading, 16, Font.NORMAL);		
            //TDD2
            ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase("PRESENT THIS DOCUMENT FOR BOARDING", tnr), 426,document.top()-49, 0);

            //*** 5)Add RESERVATION NUMBER Literal
            tnr = new Font(purpShading, 14, Font.NORMAL);		
            ColumnText.showTextAligned(cb,
                    Element.ALIGN_CENTER, new Phrase("RESERVATION NUMBER "+PNRNumber, tnr), 426,document.top()-80, 0);
            
            //*** 6)Add BarCode NUMBER
            tnr = new Font(purpShading, 10, Font.NORMAL);		
            ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, new Phrase("RES# "+pnrForBarCode, tnr),
                    document.left()+90, document.top()- 92, 0);            
            
            //This is identify the kind of trip (One-way, Round-trip, Multi-Cities)
            kindOfTrip(formatSendPsgrNotificationRQ);
            
            //*** 7)Add From to TO  
            createTicketType(writer ,document, formatSendPsgrNotificationRQ);
            
            //Call Important Information
            if(jcrService != null){
            	this.impInfoList = jcrService.getImportantInformation(tktType);
            }
        	int listSize = impInfoList.size();
        	if(listSize > 0){
        		int index = listSize - 1;
        		phoneNumber = impInfoList.get(index);
        		impInfoList.remove(index);
        	}
            
            //*** 8) Add Itinerary  
            bxFrmTop = createItinerary(writer ,document, formatSendPsgrNotificationRQ);
           
            //*** 9) Add Passengers
            int xyz = countPassengers(formatSendPsgrNotificationRQ);
            checkBxFromTop(document, xyz );
    		LOG.debug("checkBxFromTop for Passengers Done **** "+bxFrmTop);
            
            bxFrmTop = createPassengers(writer ,document, formatSendPsgrNotificationRQ);
            	
            
            if(formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getFees() != null && formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getFees().getFee() != null
	   				 && formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getFees().getFee().size() > 0) {	   		   		
	   		   	feeElement = true;
			}
            
            //*** 10) Add Important Info
            //Calculate the endorsement height required for all texts, since this a two column text
            //this needs to be also accomodated on the next column.
            int endorsementHeight = endorsementInfoHeight(document, formatSendPsgrNotificationRQ);
            //Divided by two since we are now dealing with two columns, this evaluates if we can accomodate
            //this content in the same page or a new page is requested.
            checkBxFromTop(document, endorsementHeight/2 + 12);
 
            bxFrmTop = createEndorsementInfo(writer ,document, formatSendPsgrNotificationRQ);
            bxFrmTop = createAdvisoryText(writer ,document, formatSendPsgrNotificationRQ);
            
    		 //*** 11) Add Important Info
             importantInfoHeight();
            //No need to move to the next page if this does not fit
            //fill the current page and move to next page
    		LOG.debug("checkBxFromTop for Important Info Done **** "+bxFrmTop);
            
            bxFrmTop = createNewImportantInfo(writer ,document);
    		LOG.info("Ending preparation of PDF document** ");
    		elapsedTime.stop();
		    LOG.debug("elapsedTime: "+elapsedTime.toString());

            
    		// Close the document
			document.close();

			// Exiting
		    LOG.debug("createPDF(bookingInfo)");

            
        } catch (DocumentException e) {
			LOG.error("DocumentException : DocumentException occured during PDF Document processing. PNRNumber: "+PNRNumber , e);
        	document.close();
        } catch (FileNotFoundException e) {
			LOG.error("FileNotFoundException : FileNotFoundException occured during PDF Document processing. PNRNumber: "+PNRNumber , e);
        	document.close();
        }catch (Exception e) {
			LOG.error("Exception : Error occured during PDF Document processing. PNRNumber: "+PNRNumber , e);
        	document.close();
        }
		// return the PDF as a byte Array
		return byteTemp.toByteArray();
    }
    
    /**
     * Method to generate a barcode PNG image from the Booking.  It will create the required string in the format
     * <PNRNumber>-<ddMMMyy>
     * @param bookingInfo
     * @return byte[] Byte Array of PNG image
     * @throws IOException
     * @throws BadElementException
     */
    public byte[] generateBarcode(TDDBookingInfo bookingInfo) throws IOException, BadElementException {

		LOG.debug("entering method generateBarcode(bookingInfo)");

    	String pnrForBarCode = getPNRNumber(bookingInfo);
		LOG.debug("Exiting method generateBarcode(bookingInfo)");

    	return barcode4j.qrBarCode(pnrForBarCode);
    }
    


	/**
	 * Method to initialize all the global variables in this SessionBean to ensure the values used
	 * in the previous request will not be re-used.
	 */
	private void initializeGlobalVariables() {

		LOG.debug("entering  initializeGlobalVariables()");


		// Barcode4J class required to build the PDF barcode images.
		barcode4j = new Barcode4j();
		// PDF fields - will be populated.
		orgStationCode = new String[60];
		desStationCode = new String[60];
		orgStationCity = new String[60];
		desStationCity = new String[60];
		orgStationState = new String[60];
		desStationState = new String[60];
		orgStationStreet = new String[60];
		desStationStreet = new String[60];
		tripStartDate = null;
		tripStartDateFooter = null;
		tktType = null;
		orgSttCode = null;;
		desSttCode = null;
		orgCity = null;
		desCity = null;
		orgStreet = null;
		desStreet = null;
		PNRNumber = null;
		bxForRoundTrip = 0;
		endOfPage = 700;
		bxFrmTop = 0;
		newPageFlg = false;
		pageNum = 1;
		rndTripFlg = false;
		rtnOnBox = 0;
		autoTrain = false;
		orgStreetLength = 14;
		psgrNameLength = 23;
		routeNameLength = 20;
		trainOrgDesLength = 32;
		desCityLength = 22;
		orgCityLength = 22;
		psgrTypeLen = 22;
		rbdDescLength = 45;
		endorsementLength = 54;
		tripSequence = new ArrayList<>();

		feeElement = true;
		formOfPayment = new ArrayList<>();
		noOfLogicalTrips = 0;
		psgrToBeDisplayed = new ArrayList<>();
		psgrToBeDisplayedForEndorsements = new ArrayList<>();
		expressDeliveryFee = 0;

		errorFlg = false;
		LOG.debug("exiting  initializeGlobalVariables()");

	}
	
	public void setImpInfoList(List<String> impInfoList){
		this.impInfoList = impInfoList;
	}
	
	private Paragraph createImportantInformationLine(String importantInfo) {
		
		String impInfo = importantInfo;
		Font boldFont = new Font(purpShading, 9, Font.BOLD);
		Font italicFont = new Font(purpShading, 9, Font.ITALIC);
		Font boldItalicFont = new Font(purpShading, 9, Font.BOLDITALIC);
		Font normalFont = new Font(purpShading, 9, Font.NORMAL);

		BaseColor urlColor  =  new BaseColor( 0, 0, 255);
		Font urlFont = new Font(purpShading, 9, Font.NORMAL, urlColor);	
		
		Paragraph paragraph = new Paragraph(); 
		paragraph.add(new Chunk("\u2022",FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)));
		paragraph.add(new Chunk(" ", normalFont));
		impInfo = impInfo.replaceAll("&quot;", "\"");
		impInfo = impInfo.replaceAll("&nbsp;", " ");
		impInfo = "<li style='font-family: Helvetica'>" + impInfo + "</li>";
		try {
			List<Element> elements = XMLWorkerHelper.getInstance().parseToElementList(impInfo, null);
			for(Element element : elements){
				for(Chunk chunk : element.getChunks()){
					Font font = chunk.getFont();
					BaseFont baseFont = font.getBaseFont();
					String [][] str = baseFont.getAllNameEntries();
					if(ArrayUtils.contains(str[0], "Helvetica Bold Oblique")){
						chunk.setFont(boldItalicFont);
					}else if(ArrayUtils.contains(str[0], "Helvetica Bold")){
						chunk.setFont(boldFont);
					}else if(ArrayUtils.contains(str[0], "Helvetica Oblique")){
						chunk.setFont(italicFont);
					}else if(chunk.getAccessibleAttributes() != null){
						chunk.setFont(urlFont);
					}else{
						chunk.setFont(normalFont);
					}
				}
				paragraph.addAll(element.getChunks());
			}
		} catch (IOException e) {
			LOG.error("createImportantInformationLine: Error while parsing the String impinfo text :"+impInfo , e);
		}
		return paragraph;
	}
	
	private int createNewImportantInfo(PdfWriter writer, Document document){
		for(String impInfo : impInfoList){
			checkLineOveflowsToNextPageAndSetPage(document, bxFrmTop + 24);

			ColumnText ct = new ColumnText(writer.getDirectContent());
			Rectangle rect = new Rectangle(30, document.top()- (bxFrmTop + 24), 580, document.top()- bxFrmTop, 0);
			ct.setSimpleColumn(rect);
			Paragraph paragraph = createImportantInformationLine(impInfo);
			ct.addElement(paragraph);
			try {
				int status = ct.go();
				while (ColumnText.hasMoreText(status)) {
					bxFrmTop += 12;
					checkLineOveflowsToNextPageAndSetPage(document, bxFrmTop + 24);
					rect = new Rectangle(37, document.top()- (bxFrmTop + 24), 580, document.top()- bxFrmTop, 0);
				    ct.setSimpleColumn(rect);
				    status = ct.go();
				}
			} catch (DocumentException e) {
				LOG.error("DocumentException: Error while creating important information in the PDF :" , e);
			}
			bxFrmTop += 12;
		}
		return bxFrmTop;
	}
	

	/**
	 * Calculates and returns the height of the important info section
	 * @param writer
	 * @param document
	 * @param formatSendPsgrNotificationRQ
	 * @return int 
	 */
	private int importantInfoHeight(){
		LOG.debug("entering  importantInfoHeight(writer,document,formatSendPsgrNotificationRQ)");
		
		int i =1;
		int impInfoHeight = 0;	
	   	 
		//aem call
		for (int p=0; p< impInfoList.size();++p )  {
			impInfoHeight = (i==1)? (impInfoHeight + 17):impInfoHeight + 12;
			++i;
    	}//End of Passengers for Loop	
		LOG.debug("impInfoHeight ******************"+impInfoHeight);
		
		//Requirement for one spacing to be add for the 
		//extra line in document
		return impInfoHeight + 12;
	}
	
	
    
	/**
	 * Method
	 * @param s
	 * @param strlength
	 * @return String
	 */
	private String getFrstLineChars(String s, int strlength){   

		LOG.debug("entering  getFrstLineChars(string,strlength)");

		s = s.trim().toUpperCase();
		StringBuilder result = new StringBuilder(strlength);
		String[] words = s.split("\\s");
		for(int i=0,l=words.length;i<l;++i) {
			LOG.debug("WORD **: "+words[i].toString()+" : "+words[i].toString().length());

			if(result.length() == 0){
				if(words[i].toString().length() < strlength){
					result.append(words[i].toString());
				}else{
					result.append(words[i].toString().substring(0, strlength));
					return result.toString();
				}
			}else if(result.length() > 0 && result.length() < strlength){
				if((result.length()+ 1 + words[i].toString().length()) <= strlength){
					result.append(" "+words[i].toString());
				}else{
					return result.toString();
				}
			}
		}

		LOG.debug("exiting  getFrstLineChars(string,strlength)");

		return result.toString();
	}
	
	/*
	 * This method is exactly similar to checkBoxFromTop but
	 * used to do a continuous look ahead of page overflows and
	 * resets the page to new one appropriately.
	 * 
	 * Primarily to be used for the use case where the important
	 * information text needs to continue in the first page and 
	 * then flow into the next pages if necessary, different
	 * from the earlier behavior where the text was displayed 
	 * in a new page by default if the first page was not able
	 * to accomodate it.
	 */
	void checkLineOveflowsToNextPageAndSetPage(Document document, int predictedLineWidth){
		if( (predictedLineWidth )> endOfPage){
			document.newPage();
			++pageNum;
			bxFrmTop = 0;
			newPageFlg = true;
		}
	}
	
	/*
	 * Returns the height in pixels for endorsement text
	 * 
	 */
	
	private int endorsementInfoHeight(Document document, FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){
		int endorsementHeight = 0;
		totalNumberOfEndorsements = 0;
		
		int i =1;
		FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements  endorsementsRQ = (FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements)formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getEndorsements();
		if(endorsementsRQ != null){
			List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement> endorsementListRQ = endorsementsRQ.getEndorsement();
			for (Iterator j= endorsementListRQ.iterator();j.hasNext();)  {
				FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement endorsement = (FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement)j.next();
				
				FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement.SegAssociations segAssns = endorsement.getSegAssociations();
				  List<BigInteger> segAssnList = segAssns.getSegAssociation();
				  boolean segWithZeroNumberOnly = false;
				  if(segAssnList.size() == 1 && ((BigInteger)segAssnList.get(0)).compareTo(BigInteger.valueOf(0)) == 0){
					  segWithZeroNumberOnly = true;
				  }
				  
				if(!endorsement.getEndorsementLine().getLineNbr().replaceFirst("^0*", "").equals("5") && !segWithZeroNumberOnly){//Do not display Endorsements if LineNumber=5					
					//Check for FEE element in FormatSendPsgrNotificationRQ. If exists then don't show endorsements with LineNbr 3 and 4.
					boolean feeDecisionFlg = true;
					if(feeElement){
						if(endorsement.getEndorsementLine().getLineNbr().replaceFirst("^0*", "").equals("3")					
							|| endorsement.getEndorsementLine().getLineNbr().replaceFirst("^0*", "").equals("4")){
							feeDecisionFlg = false;
						}						
					}
					if(endorsement.getPsgrAssociations() != null && feeDecisionFlg){
				    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement.PsgrAssociations psgrAssocns = endorsement.getPsgrAssociations();
				    	List<BigInteger> psgrNumbrs = psgrAssocns.getPsgrAssociation();
			  			boolean psgrFound = false;
				    	for (Iterator p = psgrNumbrs.iterator(); p.hasNext(); )  {	
				  			if(psgrFound){
				  				break;
				  			}
				  			BigInteger pNum = (BigInteger) p.next();
				      		if(psgrToBeDisplayed.contains(pNum)){
				      			String endText = endorsement.getEndorsementLine().getText();
				      			
				      			//Fix for SEV 2 - IN563628 (empty space in endorsement text issue)
				      			if(endText != null)
				      				endText = endText.trim();
				      			
				      			totalNumberOfEndorsements ++;
				      			if(endText != null && endText.length() < endorsementLength){
				      				endorsementHeight = (i==1)? (endorsementHeight + 17):endorsementHeight + 12;								    
				      			}else{
				      				while(endText.length() > endorsementLength){									    
									    String frstLine = getFrstLineChars(endText, endorsementLength);
									    endorsementHeight = (i==1)? (endorsementHeight + 17):endorsementHeight + 12;										   
									    endText = endText.substring(frstLine.length());					    				
				      				}
				      				if(endText.length() > 0 && endText.length() < endorsementLength){
				      					endorsementHeight = (i==1)? (endorsementHeight + 17):endorsementHeight + 12;										    	
				      				}
				      			}	
				      			psgrFound = true;
							    ++i;
							    break;
				      		}
				  		}//End of Passengers for Loop	
					 }//End of Passengers Associations
					
				 }//End of if LineNumber 5
			}//End of Endorsements Loop 
		}//End of endorsementsRQ
		
		//This is for multiride endorsements where the text TRANSFERRABLE or NON TRANSFERRABLE
		//is added to the list of endorsements.
		if(this.multiRideType.getRuleText() != null){
			endorsementHeight = (i==1)? (endorsementHeight + 17):endorsementHeight + 12;	
			totalNumberOfEndorsements ++;
		}
		LOG.debug("impInfoHeight ******************"+endorsementHeight);
		
		return endorsementHeight;
	}
	/*
	 * Creates the endorsement text as two columns
	 */

	private int createEndorsementInfo(PdfWriter writer, Document document, FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){
		
		  
		//Add 30 pixels to box from top if it is of type Multi-ride
		if(this.multiRideType.isValid()){
			bxFrmTop = bxFrmTop + 30;
		}
		
		Font tnr = new Font(purpShading, 9, Font.NORMAL);	
		int psgHeading = newPageFlg ? bxFrmTop : (bxFrmTop + 22 + 17);
		bxFrmTop = psgHeading;
		int i =1;
		int endorsementStrtPt = bxFrmTop;
		//Alignment of text from the margin
		int xAlignment = 0;
		int yOriginalAlignment = endorsementStrtPt + 17;
		boolean isFirstColumn = true;
		int lineCounts = 0;
		int yPixelCountOfLastEndorsementLine = 0;
		String textForMultirideEndorsement = this.multiRideType.getRuleText();
		if(StringUtils.isNotBlank(textForMultirideEndorsement)){
			textForMultirideEndorsement = textForMultirideEndorsement.toUpperCase();
		}
		
		//Recalculate the maximum number of endorsements for fitting evenly into both columns
		MAX_LIMIT_OF_ENDORSEMENTS_PER_COLUMN = this.totalNumberOfEndorsements/2 + this.totalNumberOfEndorsements % 2;
      	
		//The first text in the listing should be for multiride type endorsements if it exists.
		if(textForMultirideEndorsement != null){
			endorsementStrtPt = (i==1)? (endorsementStrtPt + 17):endorsementStrtPt + 12;
		    ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM,
		    							new Phrase(new Chunk("\u2022",FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)) + 
		    									" " + textForMultirideEndorsement,tnr),
		    									document.left() + xAlignment, document.top()- endorsementStrtPt, 0);
		    lineCounts++;
		    i++;
		}
		
		
	    //TDD2 this section only has endorsements
		FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements  endorsementsRQ = (FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements)formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getEndorsements();
		if(endorsementsRQ != null){
			List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement> endorsementListRQ = endorsementsRQ.getEndorsement();
			for (Iterator j= endorsementListRQ.iterator();j.hasNext();)  {
				//Check if the endorsements needs to overflow into the next column in such case we need to reset the x co-ordinate to the
				//middle of the page and the y co-ordinate to the original value 
				
				  FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement endorsement = (FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement)j.next();
				  
				  FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement.SegAssociations segAssns = endorsement.getSegAssociations();
				  List<BigInteger> segAssnList = segAssns.getSegAssociation();
				  boolean segWithZeroNumberOnly = false;
				  if(segAssnList.size() == 1 && ((BigInteger)segAssnList.get(0)).compareTo(BigInteger.valueOf(0)) == 0){
					  segWithZeroNumberOnly = true;
					  
				  }
			      if(!endorsement.getEndorsementLine().getLineNbr().replaceFirst("^0*", "").equals("5") && !segWithZeroNumberOnly){//Do not display Endorsements if LineNumber=5
			    	  //Check for FEE element in FormatSendPsgrNotificationRQ. If exists then don't show endorsements with LineNbr 3 and 4.
			    	  boolean feeDecisionFlg = true;
					  if(feeElement){
						if( endorsement.getEndorsementLine().getLineNbr().replaceFirst("^0*", "").equals("3")					
							|| endorsement.getEndorsementLine().getLineNbr().replaceFirst("^0*", "").equals("4")){
							feeDecisionFlg = false;
						}							
					  }
			    	  if(endorsement.getPsgrAssociations() != null && feeDecisionFlg){
				    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement.PsgrAssociations psgrAssocns = endorsement.getPsgrAssociations();
				    	List<BigInteger> psgrNumbrs = psgrAssocns.getPsgrAssociation();
				    	boolean psgrFound = false;
				    	for (Iterator p = psgrNumbrs.iterator(); p.hasNext(); )  {
				  			if(psgrFound){
				  				break;
				  			}
				  			
				    		BigInteger pNum = (BigInteger) p.next();
				    		if(psgrToBeDisplayed.contains(pNum)){
				      			String endText = endorsement.getEndorsementLine().getText();
				      			lineCounts++;
				      			//Reset the values to jump to the next column in case the endorsement 
				      			//overflows. This is a permanent change in this processing and should be done only once
				      			//so using the boolean flag isFirstColumn
				      			if(lineCounts > (this.MAX_LIMIT_OF_ENDORSEMENTS_PER_COLUMN) && isFirstColumn){
				      				xAlignment = PDF_MID_Y_POSITION_IN_PIXEL;
				      				endorsementStrtPt = yOriginalAlignment - 17; //Offset this since 12 is added 
				      				isFirstColumn = false;
				      				i = 1;
				      			}
				        			 
				      			if(endText.length() <= 54){
				      				endorsementStrtPt = (i==1)? (endorsementStrtPt + 17):endorsementStrtPt + 12;
								    ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(new Chunk("\u2022",FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)) + " " +endorsement.getEndorsementLine().getText(),tnr),
								    document.left() + xAlignment, document.top()- endorsementStrtPt, 0);
											    
								    //Mark the last line pixel count, before we wrap to the next column and render text
								    if(lineCounts == this.MAX_LIMIT_OF_ENDORSEMENTS_PER_COLUMN){
								    	yPixelCountOfLastEndorsementLine = endorsementStrtPt;
								    }
								   
				      			}else{
				      				//This is the line count inclusive of text wrappings due to excess width
				      				//A single line can be wrapped and written as two lines if the width exceeds
				      				//the limit
				      				int renderedLineCount = 0;
				      				while(endText.length() > endorsementLength){									    
									    String frstLine = getFrstLineChars(endText, endorsementLength);
									    endorsementStrtPt = (i==1)? (endorsementStrtPt + 17):endorsementStrtPt + 12;
									    if(renderedLineCount == 0){
									    	ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(new Chunk("\u2022",FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)) + " " +frstLine,tnr),
												    document.left() + xAlignment, document.top()- endorsementStrtPt, 0);
									    }else{
									    	ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("  "+frstLine,tnr),
												    document.left() + xAlignment, document.top()- endorsementStrtPt, 0);	
									    }
									    ++renderedLineCount;
									    i++;
									    endText = endText.trim();
									    endText = endText.substring(frstLine.length());					    				
				      				}
				      				if(endText.length() > 0 && endText.length() <= endorsementLength){
				      					endorsementStrtPt = endorsementStrtPt + 12;
									    ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("  "+endText,tnr),
									    document.left()+ xAlignment, document.top()- endorsementStrtPt, 0);		
			  
									    
									    ++renderedLineCount;
								        //Mark the last line pixel count, before we wrap to the next column and render text
									    if(lineCounts == this.MAX_LIMIT_OF_ENDORSEMENTS_PER_COLUMN){
									    	yPixelCountOfLastEndorsementLine = endorsementStrtPt;
									    }
				      				}
				      			}
				      		
							    ++i;
							    psgrFound = true;
							    break;
				      		}
				  		}//End of Passengers for Loop	
					 }//End of Passengers Associations
			    	  
			      }//End of if LineNumber 5
			}//End of Endorsements Loop 
		}//End of endorsementsRQ
		
		if(yPixelCountOfLastEndorsementLine < endorsementStrtPt){
			yPixelCountOfLastEndorsementLine = endorsementStrtPt;
		}
		
		//If the text wraps and moves to the next column then set the line count as the last line in the first column
		bxFrmTop = (lineCounts > this.MAX_LIMIT_OF_ENDORSEMENTS_PER_COLUMN)? yPixelCountOfLastEndorsementLine: endorsementStrtPt;
		
		//Retro render the important header now.
		tnr = new Font(cyanShading, 10, Font.NORMAL); 
		//Requirement to associate the important information with atleast one bulleted text
		//if not move to next line.
		if(lineCounts == 0){
			//If the last line can be accomodated after important info move to next page
			this.checkBxFromTop(document, 12*2);
			
			if(this.newPageFlg){
				psgHeading = 0;
			}
		}
		
		
		ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("IMPORTANT INFORMATION",tnr),
                document.left(), document.top()- psgHeading, 0);
		//Draw dotted line
		DottedLineSeparator lineSep = new DottedLineSeparator();
		lineSep.setGap((float) 2);
		lineSep.draw(writer.getDirectContent(), document.left(), document.top()- psgHeading - 5, document.right(), document.top()- psgHeading - 5, document.top()- psgHeading-5);

		return bxFrmTop;
	}
	
	
	 private int createAdvisoryText(PdfWriter writer, Document document,
				FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ) {
	  	  
			Font tnr = new Font(purpShading, 9, Font.NORMAL);
			Font tnrBold = new Font(purpShading, 9, Font.BOLD);
			int psgHeading = newPageFlg ? bxFrmTop : (bxFrmTop + 17);
			bxFrmTop = psgHeading;
			
			
			//Alignment of text from the margin
			int xAlignment = 0;
			int i = 1;
			
			Set<String> stationsForAdvisoryList = this.tddCommonFunctions.getUniqueAdvisoryList(formatSendPsgrNotificationRQ);
//			
			
			if(stationsForAdvisoryList.size() > 0){
				checkLineOveflowsToNextPageAndSetPage(document, bxFrmTop);
				//First render the advisory text in BOLD
			   	//Write the bulleted text and content.
		    	ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, 
		    								new Phrase(new Chunk("\u2022",FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD)) + TDDConstants.SPACE
		    																										+ pwdPDFAdvisoryText, tnrBold),
		    								document.left() + xAlignment, document.top()- bxFrmTop, 0);
		    	
				
				List<String> strList = splitWordsByDelimChar(stationsForAdvisoryList, ",", 60, 75);
				Iterator<String> it = strList.iterator();
				while(it.hasNext()){
					checkLineOveflowsToNextPageAndSetPage(document, bxFrmTop);
					
					//First line has the adivsoryText + stationText being rendered in combo hence the space for stationText is reduced 84 chars
					//next lines have only station text being rendered hence we have more space so it is 112.
					String textToRender = (String)it.next();
					int commaDelimPos = textToRender.lastIndexOf(",");
					//Remove the last comma delimiter
					if(commaDelimPos > 0){
						textToRender = textToRender.substring(0, textToRender.lastIndexOf(","));
					}

					bxFrmTop = (i==1)? bxFrmTop: bxFrmTop + 12;
					//The first line has advisoryText + stationText hence alignment is offset
					xAlignment = (i == 1)? 115: 0;
			
				   	ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("  " + textToRender, tnr),
						    document.left() + xAlignment, document.top()- bxFrmTop, 0);
			
				    i ++;
				}
			}
			return bxFrmTop;// TODO Auto-generated method stub
		}
	  
	  /*
	   * Splits list of words, based on line length and converts them to a comma + space delimited sentence.
	   * <p>
	   * @param strList -  list of words
	   * @param delimiterChar - delimiter that is appended to each word when a sentence is formed
	   * @param firstLinelength - the length of the first line of sentence (will be less the otherLinelengths due to indents etc)
	   * @param otherLineLengths - length of the second and subsequent lines.
	   * @return - List of sentences split based on line lengths provided.
	   */
	  
	   public List<String> splitWordsByDelimChar(Set<String> strSet, String delimiterChar, int firstLinelength, int otherLinelengths){
		   
		   	
		  	List<String> listOfStrs = new ArrayList<>(10);
		  	
			if(strSet == null){
		   		return listOfStrs;
		   	}
			
		   	int currentStrLength = 0;
			StringBuilder builder = new StringBuilder();
			int lineToLimit = firstLinelength;
			String token = "";
		  	Iterator<String> it = strSet.iterator();
			
		  	while(it.hasNext()){
		  	 		//Iterate till limit is reached.
		  		if(currentStrLength + token.length() <= lineToLimit){
		  			token = (String) it.next();
		  			builder.append(token).append(delimiterChar).append(TDDConstants.SPACE);
		  			currentStrLength = currentStrLength + token.length();
		  			//Takes care of case where string is less than limit
		  			if(it.hasNext()  == false){
				  		listOfStrs.add(builder.toString());
		  			}
		  		}else{
		  			listOfStrs.add(builder.toString());
		  			currentStrLength = 0;
		  			builder = new StringBuilder();
		  			lineToLimit = otherLinelengths;
		  		}
		 	}
	 	
		  				
			return listOfStrs;
	  }
	
	/**
	 * Add the passengers section to the document
	 * @param writer
	 * @param document
	 * @param formatSendPsgrNotificationRQ
	 * @return
	 */
	private int createPassengers(PdfWriter writer, Document document, FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){
		LOG.debug("entering createPassengers(writer,document,formatSendPsgrNotificationRQ)");

		List<Passenger> passengersList = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getPassengers().getPassenger(); 
		int psgHeading = newPageFlg ? bxFrmTop : bxFrmTop + 22;
		bxFrmTop = psgHeading;
		int i =1;
		Font tnr = new Font(purpShading, 10, Font.NORMAL);	
		for (Iterator p = passengersList.iterator(); p.hasNext(); )  {
    		Passenger passenger = new Passenger();
    		passenger = (Passenger) p.next();  		
    		String name = passenger.getPassengerName().getLastName()+", " + passenger.getPassengerName().getFirstName();
    		if(psgrToBeDisplayed.contains(passenger.getPassengerNumber())){
	    		bxFrmTop = (i==1)? (bxFrmTop + 17):bxFrmTop + 12;
	    		if(name.length() < psgrNameLength){
	    			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(name,tnr),
	                        document.left(), document.top()- bxFrmTop, 0);
	    		}else{
	    			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(name.substring(0, psgrNameLength),tnr),
	                    document.left(), document.top()- bxFrmTop, 0);
	    		}
				
				//This block is to display Adult/Child/AAA etc.
	    		boolean psgrFound = false;
				FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements  endorsementsRQ = (FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements)formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getEndorsements();
				if(endorsementsRQ != null){
					List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement> endorsementListRQ = endorsementsRQ.getEndorsement();
					for (Iterator j= endorsementListRQ.iterator();j.hasNext();)  {
						//If passenger is found in an endorsement, then we can ignore rest of the endorsements.
						if(psgrFound){
							break;
						}
						  FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement endorsement = (FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement)j.next();
						  if(endorsement.getEndorsementLine().getLineNbr() != null && endorsement.getEndorsementLine().getLineNbr().replaceFirst("^0*", "").equals("5")){
							  FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Endorsements.Endorsement.PsgrAssociations psgrAssociations;
							  psgrAssociations = endorsement.getPsgrAssociations();
							  List<BigInteger> psgrAssociationList = psgrAssociations.getPsgrAssociation();
							  for(int pList =0; pList < psgrAssociationList.size(); pList++){
								  if(passenger.getPassengerNumber()!=null){
									  if(psgrAssociationList.get(pList).compareTo(passenger.getPassengerNumber()) == 0){
										  if(endorsement.getEndorsementLine().getText() != null && !endorsement.getEndorsementLine().getText().equalsIgnoreCase("VEHICLE")
												  && !endorsement.getEndorsementLine().getText().equalsIgnoreCase("BIKE")){
											  if(endorsement.getEndorsementLine().getText().length() < psgrTypeLen ){										  
												  ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(endorsement.getEndorsementLine().getText(),tnr),
								                    document.left()+140, document.top()- bxFrmTop, 0);
											  }else{
												  ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(endorsement.getEndorsementLine().getText().substring(0,psgrTypeLen),tnr),
										                    document.left()+140, document.top()- bxFrmTop, 0);
											  }
											  psgrFound = true;
											  break;
										  }
									  }
								  }
							  }
						  }					  
					}//End of Endorsements Loop 
				}		
				
				int agrCount = 0;
				int tierCount = 0;
					if(passenger.getMemberships() != null && passenger.getMemberships().getMembership() != null){
						List<Membership> membershipList = passenger.getMemberships().getMembership();
						for(int j=0; j < membershipList.size();j++){
							if(membershipList.get(j).getType() != null && membershipList.get(j).getType().equals("FQTV") && membershipList.get(j).getCode() == null){		
								++agrCount;
								if(membershipList.get(j).getText() != null && !membershipList.get(j).getText().isEmpty()){
									++tierCount;
								}
							}
						}
					}
				
				boolean mdbFlg = false;
				if(passenger.getMemberships() != null && passenger.getMemberships().getMembership() != null){
					List<Membership> membershipList = passenger.getMemberships().getMembership();
					for(int j=0; j < membershipList.size();j++){
						if(membershipList.get(j).getType() != null && membershipList.get(j).getType().equals("FQTV") && membershipList.get(j).getCode() == null){		
							String mbrDtls = membershipList.get(j).getNumber() != null? membershipList.get(j).getNumber(): null;
							if(membershipList.get(j).getText() != null && !membershipList.get(j).getText().isEmpty()){
								mbrDtls = mbrDtls +" | "+membershipList.get(j).getText();
							}
							//TDD Multiride change allow this text to be aligned with second column of endorsement listing
							ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(mbrDtls,tnr),
				                    document.left()+ PDF_MID_Y_POSITION_IN_PIXEL, document.top()- bxFrmTop, 0);						
							mdbFlg = true;
							break;
						}
					}
				}	
				if(!mdbFlg){
					//TDD2
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("No member number provided. Join at Amtrak.com",tnr),
		                    document.left()+PDF_MID_Y_POSITION_IN_PIXEL, document.top()- bxFrmTop, 0);
				}			
				++i;
    		}//End of If Condition
    	}//End of Passengers for Loop			
		
		tnr = new Font(grayShading, 9, Font.BOLD);
		ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("Proper identification is required for all passengers.",tnr),
                document.left(), document.top()- bxFrmTop - 17, 0);
		tnr = new Font(purpShading, 9, Font.NORMAL);
		ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("This document is valid for only passengers listed. See www.amtrak.com/ID for details.",tnr),
                document.left()+218, document.top()- bxFrmTop - 17, 0);
		
		tnr = new Font(cyanShading, 10, Font.NORMAL); 
		ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("PASSENGERS ("+psgrToBeDisplayed.size()+")",tnr),
                document.left(), document.top()- psgHeading, 0);
		//This needs to be aligned with endorsement listing
		ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("AMTRAK GUEST REWARDS",tnr),
                document.left() + PDF_MID_Y_POSITION_IN_PIXEL, document.top()- psgHeading, 0);

		//Draw dotted line
		DottedLineSeparator lineSep = new DottedLineSeparator();
		lineSep.setGap((float) 2);
		lineSep.draw(writer.getDirectContent(), document.left(), document.top()- psgHeading - 5, document.right(), document.top()- psgHeading - 5, document.top()- psgHeading-5);
		LOG.debug("createPassengers End **");
	
		return bxFrmTop;
	}
    
	/**
	 * 
	 * @param document
	 * @param reqBoxHeight
	 */
	private void checkBxFromTop(Document document, int reqBoxHeight){

		LOG.debug("entering checkBxFromTop(document,reqBoxHeight)");

		newPageFlg = false;
		if( (bxFrmTop + reqBoxHeight )> endOfPage){
			document.newPage();
			++pageNum;
			bxFrmTop = 0;
			newPageFlg = true;
		}
		LOG.debug("exiting checkBxFromTop(document,reqBoxHeight)");

	}
    
	/**
	 * Returns the height of the passengers section
	 * @param formatSendPsgrNotificationRQ
	 * @return int heightForPassengers
	 */
	private int countPassengers(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){

		LOG.debug("entering countPassengers(formatSendPsgrNotificationRQ)");

		List<Passenger> passengersList = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getPassengers().getPassenger(); 
		int heightForPassengers = 0;
		int i =1;
		for (Iterator<Passenger> p = passengersList.iterator(); p.hasNext(); )  {
			Passenger passenger = new Passenger();
    		passenger = (Passenger) p.next();  	
    		if(psgrToBeDisplayed.contains(passenger.getPassengerNumber())){
    			heightForPassengers = (i==1)? (heightForPassengers + 17):heightForPassengers + 12;			
    			++i;
    		}
    	}//End of Passengers for Loop	
		LOG.debug("heightForPassengers ******************"+heightForPassengers);

		LOG.debug("exiting countPassengers(formatSendPsgrNotificationRQ)");

		return heightForPassengers;
	}
	
	/**
	 * Add the itinerary to the document
	 * @param writer
	 * @param document
	 * @param formatSendPsgrNotificationRQ
	 * @return int
	 */
	private int createItinerary(PdfWriter writer, Document document, FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){

		LOG.debug("entering createItinerary(writer,document,formatSendPsgrNotificationRQ)");

		int bxFrmTop = 225;
		Font tnr = new Font(blueShading, 10, Font.NORMAL); 
		try{
			//Format RQ
	    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();    	
	    	List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
	    	
			int logTripCount = 0;		
			int bxHght = 42;
			int frstSegRow = 196;
			int secdSegRow = 218;
			for (Iterator j = logicalTripListRQ.iterator(); j.hasNext(); )  { 
				List segmentsList  = ((FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip)j.next()).getSegments().getSegment();
				boolean expDelFeeFlg = false;
				boolean serviceFeeFlg = false;
				for (Iterator itr = segmentsList.iterator(); itr.hasNext(); )  {
					Segment segmentForEXDL = new Segment();
					segmentForEXDL = (Segment) itr.next();
					if(segmentForEXDL.getTickets() != null){
	    			List<Ticket> ticketList = segmentForEXDL.getTickets().getTicket();	
	    				for (Iterator tktItr = ticketList.iterator(); tktItr.hasNext(); )  {        			
	    		    		Ticket ticket = new Ticket();
	    		    		ticket = (Ticket) tktItr.next(); 		    		    		
	    		    		if(ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null &&
	    		    				ticket.getPricingItem().getFarePlans().getFarePlan().get(0) != null){	    		    			
	    		    			if(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().equalsIgnoreCase(TDDConstants.EXPRESS_DELIVERY_FEE)){
		    		    			expDelFeeFlg = true;		  
	    		    			}else if(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().substring(0, 3).equalsIgnoreCase(TDDConstants.SERVICE_FEE)){
		    		    			serviceFeeFlg = true;		  
	    		    			}
	    		    		}		    		    		
	    				}
	    			}
				}
			
				if(!expDelFeeFlg && !serviceFeeFlg){
					if(logTripCount > 0){
						if(logTripCount == 1){
							bxForRoundTrip = bxFrmTop + 18;
						}						
						if(bxFrmTop > endOfPage){
							document.newPage();
							bxFrmTop = 45;
							bxForRoundTrip = 0;
							frstSegRow = 16;
							secdSegRow = 38;
							bxHght = 42;
						}//To test for bxFrmTop
						else{
							//Set dynamic property to be increased so that gap exists between different logical boxes
							bxFrmTop = bxFrmTop + 21 + 42 + 2;
							frstSegRow = frstSegRow + 27 + 21 + 15 + 2;
							secdSegRow = secdSegRow + 5 + 21 + 15 + 22 + 2;
							bxHght = 42;
						}
					}
								
					int segCount=0;
					String trainNumber = null;
					String orgTrainCity = null;
					String desTrainCity = null;
					String trainDate = null;
					int dupSegment = 0;
					boolean newPgFlg = false;
					boolean multiLineFlg= false;
					boolean scdRowFlg = false;
					for (Iterator i = segmentsList.iterator(); i.hasNext(); )  {
						newPgFlg = false;
						multiLineFlg= false;
						boolean multiRBDDesc = false;
						boolean multiLineOrgDesCity = false;
						String rtName = "";
		    			Segment4 segment = new Segment4();
		    			segment = (Segment4) i.next();
		    			
		    			// To build PsgrAssociations from segments
		    			Segment4 .PsgrAssociations psgrAssociations = segment.getPsgrAssociations();	    			
		    			List<BigInteger> psgrAssociationsList= psgrAssociations.getPsgrAssociation();	    			
		    			for (Iterator pList = psgrAssociationsList.iterator(); pList.hasNext(); )  {	    				
		    				  BigInteger pNum = (BigInteger) pList.next();
							  if(!psgrToBeDisplayed.contains(pNum)){
								  psgrToBeDisplayed.add(pNum);
							  }								
						  }	
		    			
		    			if(this.multiRideType.isValid()){
		    				continue;
		    			}
						  
		    			//During preparation of PDF with in a Logical Trip if there are lot number of segments and we are going beyond
		    			//endOfPage=650 it means we need to continue on new page. End the existing box and start in a new page.
		    			if(bxFrmTop > endOfPage){
		    				//Draw Box around Logical Trip by providing dynamic coordinates
		    				writer.getDirectContent().rectangle(document.left(),document.top()-bxFrmTop,document.right()-document.left(),bxHght);
		    				writer.getDirectContent().stroke ();	
		    				document.newPage();
							bxFrmTop = 45;
							frstSegRow = 16;
							secdSegRow = 38;
							bxHght = 42;						
							if(logTripCount == 0){
								bxForRoundTrip = 0;
							}						
							newPgFlg = true;
							segCount = 0;
							dupSegment = 0;
		    			}
	
		    			//Test whether the earlier segment is same as the current one
		    			//If yes then we need to show only one, but with extra RBD Details
		    			LOG.info("orgTrainCity 3: "+segment.getOrigin().getName().toUpperCase()+" desTrainCity 3: "+segment.getDestination().getName().toUpperCase());

		    			//TDD3 - the date conversion method convertDateToMMMddyyyy below takes care of null values, but the check is provided below to make it explicit.
						XMLGregorianCalendar depDateTime = (!this.multiRideType.isValid())? segment.getDepartureDateTime(): null;
						String trainNumberDetailsStr = (!this.multiRideType.isValid())?segment.getTrainDetails().getTrainNumber().toString():"";					
   		
		    			if(trainNumber != null && trainNumberDetailsStr.equals(trainNumber)
		    				 && orgTrainCity != null && segment.getOrigin().getName().toUpperCase().equals(orgTrainCity) &&
		    				 desTrainCity != null && segment.getDestination().getName().toUpperCase().equals(desTrainCity) &&
		    				TDDDateUtils.convertDateToMMM_dd_yyyy(depDateTime).equals(trainDate)){
		    					++dupSegment;
		    					
		    					//Duplicate SEgment
		    					//Make a list of RBD and Car Details
		    					//If not duplicate check for List of RBD and CarDetails, if present display them
		    					
				    			LOG.debug("secdSegRow 1: "+secdSegRow);
		    					secdSegRow = secdSegRow + 12;
				    			LOG.debug("secdSegRow 2: "+secdSegRow);
		    					if(scdRowFlg){
		    						secdSegRow = secdSegRow + 10;
		    						frstSegRow = frstSegRow + 10;
			    					bxFrmTop = bxFrmTop + 10;
			    					bxHght = bxHght + 10;
			    					scdRowFlg = false;
		    					}
		    					if(dupSegment > 1){
			    					bxFrmTop = bxFrmTop + 12;
			    					bxHght = bxHght + 12;
		    					}
		    					if(newPgFlg)
		    						segCount = 1;
		    				
			    				tnr = new Font(purpShading, 8, Font.NORMAL);  
			    				String rbdDes = rbdDescription(segment);
			    				String carDtls = carDetails(segment);
			    				if(checkRBDAndCarDetails(rbdDes, carDtls, secdSegRow, writer, document, tnr)){
			    					++dupSegment;
									secdSegRow = secdSegRow + 12;
									bxFrmTop = bxFrmTop + 12;
			    					bxHght = bxHght + 12;
			    				}
		    			}else{
		    				scdRowFlg = false;
		    				if(dupSegment > 0){
		    					frstSegRow = frstSegRow + ((dupSegment -1) * 12);
		    					secdSegRow = secdSegRow - 12;
		    					dupSegment = 0;
		    				}
		    				if(segCount > 0){
		    					bxFrmTop = bxFrmTop +(42);
			    				bxHght = bxHght + (42);
		    					frstSegRow = frstSegRow + 42;
		        				secdSegRow = secdSegRow + 42;
		        				//Draw dotted line
		        				DottedLineSeparator lineSep = new DottedLineSeparator();
		        				lineSep.setGap((float) 2);
		        				lineSep.draw(writer.getDirectContent(), document.left()+5, document.top()- frstSegRow +13, document.right() - 5, document.top()- frstSegRow +13, document.top()- frstSegRow +13);
		        			} 
		    				if(segment.getTrainDetails().getRouteName() != null){
				    			rtName = segment.getTrainDetails().getRouteName();
				    		}
		    				
		    				tnr = new Font(purpShading, 9, Font.NORMAL);
			    			//Train/BUS    			
		    				if(!rtName.equals(myProperties.getProperty("routeName"))){
		    					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(tddCommonFunctions.getCarrierType(segment),tnr),
			                        document.left()+5, document.top()- frstSegRow, 0);
		    				}
			    			LOG.debug("frstSegRow 1: "+frstSegRow+" secdSegRow 1: "+secdSegRow);

		    				//CARDINAL / SOUTHWEST CHEF /THRUWAY CONNECTING SERVICE		    			
			    			if(rtName != null){
				    			if(rtName.length() <= routeNameLength){
				    				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(rtName.toUpperCase(),tnr),
					                        document.left()+60, document.top()- frstSegRow, 0);
				    			}else{
				    				String frstLine = getFrstLineChars(rtName.toUpperCase(), routeNameLength);
				    				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(frstLine,tnr),
					                        document.left()+60, document.top()- frstSegRow, 0);
				    				String secdLine = getFrstLineChars(rtName.substring(frstLine.length()), routeNameLength);
				    				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(secdLine,tnr),
					                        document.left()+60, document.top()- frstSegRow - 10, 0);
				    				if(!rtName.equals(myProperties.getProperty("routeName"))){
					    				secdSegRow = secdSegRow + 10;
					    				multiLineFlg= true;
				    				}
				    			}	
			    			}
			    			LOG.debug("frstSegRow 2: "+frstSegRow+" secdSegRow 2: "+secdSegRow);

			    			//From - TO
			    			if(segment.getOrigin() != null && segment.getOrigin().getName() != null){
			    				orgTrainCity = segment.getOrigin().getName().toUpperCase();		    				
			    			}else{
			    				orgTrainCity = null;
			    			}
			    			if(segment.getDestination() != null && segment.getDestination().getName() != null){
				    			desTrainCity = segment.getDestination().getName().toUpperCase();			    			
			    			}else{
			    				desTrainCity = null;
			    			}
			    			
			    			if(checkOrgAndDesCityDetails(orgTrainCity, desTrainCity, frstSegRow, writer, document, tnr)){
		    					multiLineOrgDesCity = true;
		    				}		    			
			    			
			    			if(!rtName.equals(myProperties.getProperty("routeName")))	{
				    			//DEPARTS - Static Name
				    			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("DEPARTS",tnr),
				                        document.left()+380, document.top()- frstSegRow, 0);
				    			
				    			//ARRIVES(Thu Dec 2)
				    			//TDD3 - ArrivalDateTime can be null for Multiride, date conversion method convertDateEEEMMMd takes care of null values.
				    			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("ARRIVES ("+TDDDateUtils.convertDateEEEMMMd(segment.getArrivalDateTime())+")",tnr),
				                        document.left()+460, document.top()- frstSegRow, 0);
				    			
				    			tnr = new Font(orangeShading, 24, Font.NORMAL);  
				    			//TDD3 for multiride train number will be null
				    			trainNumber = (!this.multiRideType.isValid())?segment.getTrainDetails().getTrainNumber().toString():"";
				    			
				    			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(trainNumber,tnr),
				                        document.left()+5, document.top()- secdSegRow, 0);		    			
				    			
				    			tnr = new Font(blueShading, 18, Font.NORMAL); 
				    			//TDD3: for multiride DepartureTime is empty in this case the convertDateToMMMddyyyy method returns an empty string
				    			//instead of erroring out with an exception,
				    			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(TDDDateUtils.convertDateToMMM_dd_yyyy(segment.getDepartureDateTime()),tnr),
				                        document.left()+60, document.top()- secdSegRow, 0);
				    			//TDD3: for multiride DepartureTime is empty in this case the below method returns an empty string
				    			//instead of erroring out with an exception,
				    			trainDate = TDDDateUtils.convertDateToMMM_dd_yyyy(segment.getDepartureDateTime());
				    			
				    			//TDD3 For Multiride the Departure and Arrival times will be empty in case this block is processed, getTime will return an empty string
				    			//instead of erroring out with an exception.
				    			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(TDDDateUtils.getTime(segment.getDepartureDateTime()),tnr),
				                        document.left()+380, document.top()- secdSegRow, 0);
				    			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(TDDDateUtils.getTime(segment.getArrivalDateTime()),tnr),
				                        document.left()+460, document.top()- secdSegRow, 0);
				    			
				    			//If RouteName is MultiLine then no need to increase second Row coordinates. Because we already did so.
				    			if(multiLineOrgDesCity && !multiLineFlg && !rtName.equals(myProperties.getProperty("routeName"))){
		    						secdSegRow = secdSegRow + 10;
		    					}
				    			
				    			tnr = new Font(purpShading, 8, Font.NORMAL);   
				    			String rbdDes = rbdDescription(segment);
			    				String carDtls = carDetails(segment);
			    				if(checkRBDAndCarDetails(rbdDes, carDtls, secdSegRow, writer, document, tnr)){
			    					multiRBDDesc = true;
			    				}
			    				//Following block is for MultiLine Org_Des City. To keep everything look perfect in alignment
			    				//this block is coded.
			    				//If we are not going to reduce second row co-ordinates, extra gaps will occur in each segment.
			    				//If there is a duplicate segment, then we need to keep track of the second row coordinates,
			    				//so boolean scdRowFlg is introduced.
			    				if(multiLineOrgDesCity && !multiLineFlg && !rtName.equals(myProperties.getProperty("routeName"))){
		    						secdSegRow = secdSegRow - 10;
		    						scdRowFlg = true;
		    					}else{
		    						scdRowFlg = false;
		    					}
			    			}else{
			    				//Display Self Transfer Informational Note
			    				tnr = new Font(grayShading, 9, Font.NORMAL);   
			    				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("Amtrak does not provide service",tnr),
				                        document.left()+380, document.top()- frstSegRow, 0);
			    				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("between these stations. You must",tnr),
				                        document.left()+380, document.top()- frstSegRow -11, 0);
			    				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("make your own travel arrangements.",tnr),
				                        document.left()+380, document.top()- frstSegRow - 22, 0);
			    			}
		    				++segCount;	 
			    			LOG.debug("frstSegRow 3: "+frstSegRow+" secdSegRow 3: "+secdSegRow);

		    				if(multiRBDDesc){
		    					frstSegRow = frstSegRow + 12;
								secdSegRow = secdSegRow + 12;
								bxFrmTop = bxFrmTop + 12;
		    					bxHght = bxHght + 12;	    					
		    				}
			    			LOG.debug("frstSegRow 4: "+frstSegRow+" secdSegRow 4: "+secdSegRow);

		    				multiRBDDesc = false;
		    				multiLineOrgDesCity = false;
		    				if(multiLineFlg && !rtName.equals(myProperties.getProperty("routeName"))){
		    					frstSegRow = frstSegRow + 10;
		    					bxFrmTop = bxFrmTop + 10;
		    					bxHght = bxHght + 10;
		    				}
			    			LOG.debug("frstSegRow 5: "+frstSegRow+" secdSegRow 5: "+secdSegRow);

		    			}   			
					}
					if(dupSegment > 0){
						frstSegRow = frstSegRow + ((dupSegment -1) * 12);
						secdSegRow = secdSegRow - 12;
					}
				}//End of 
				
				if(!expDelFeeFlg)
					++logTripCount;
				
				if(rtnOnBox == (logTripCount+1)){
					bxForRoundTrip = bxFrmTop + 18;
					roundTripTicketType(writer ,document);
				}
				
    			LOG.debug("frstSegRow 6: "+frstSegRow+" secdSegRow 6: "+secdSegRow);

				//Draw Box around Logical Trip by providing dynamic coordinates
				if(!this.multiRideType.isValid()){
					writer.getDirectContent().rectangle(document.left(),document.top()-bxFrmTop,document.right()-document.left(),bxHght);
					writer.getDirectContent().stroke ();
				}
		     }
		} catch (Exception e) {
			errorFlg = true;
			LOG.error("Error occured in createItinerary" , e);

		}
		
		//Hack again, the itinenary and passenger information is mixed up in this code
		//and cannot be commented out to accomodate Multiride requirement of removing the
		//itinenary, so portions of the above code needs to be processed selectively based on Multiride type.
		
		if(this.multiRideType.isValid()){
			bxFrmTop = 160;
			//Draw dotted line
			LineSeparator lineSep = new LineSeparator();
			lineSep.drawLine(writer.getDirectContent(), document.left(), document.right(), document.top() - 155);
		}
		

		return bxFrmTop;
	}

	/**
	 * Add the round trip ticket type to the document
	 * @param writer
	 * @param document
	 */
	private void roundTripTicketType(PdfWriter writer, Document document){

		LOG.debug("entering roundTripTicketType(writer,document) ");

		try {
			LOG.debug("Inside roundTripTicketType **"+rndTripFlg);

			Font tnr = new Font(purpShading, 10, Font.NORMAL);			
			if(tktType.equals("Round-Trip") && !rndTripFlg){				
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("Return",tnr),
	                    document.left()+5, document.top()-bxForRoundTrip, 0);				
			}			
		}catch(Exception e){
			errorFlg = true;
			LOG.error("Error occured in roundTripTicketType. This prepares Return message in PDF for Round-Trip tickets.**" , e);
		}

		LOG.debug("exiting roundTripTicketType(writer,document) ");

	}
	
	/**
	 * Create the ticket type section and add to document
	 * @param writer
	 * @param document
	 * @param formatSendPsgrNotificationRQ
	 */
	private void createTicketType(PdfWriter writer, Document document, FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){

		LOG.debug("entering createTicketType(writer,document,formatSendPsgrNotificationRQ) ");

		//Extracts the kind of Multiride Weekly, Monthly or Multiride type
	

		try {
			orgSttCode = orgStationCode[0];
			orgCity = orgStationCity[0]+", "+orgStationState[0];
			orgStreet = orgStationStreet[0];
				for(int i=0; i< orgStationCode.length; i++){
						if(orgStationCode[i]!= null && orgStationCode[i+1]!= null){
							if(desStationCode[i].equals(orgStationCode[i+1])){
								if(orgStationCode[i+2]== null){
									if(desStationCode[i+1].equals(orgStationCode[0])){
										//Round-Trip
										tktType = "Round-Trip";
										desSttCode = desStationCode[0];
										desCity = desStationCity[0]+", "+desStationState[0];
										desStreet = desStationStreet[0];
										rtnOnBox = i+2;
										break;
									}else{
										//Multi-City
										tktType = "Multi-City Trip";
										desSttCode ="MULTIPLE CITIES";
										break;
									}
								}
							}else{
								//Multi-City
								tktType = "Multi-City Trip";
								desSttCode ="MULTIPLE CITIES";
								break;
							}
						}else{
							if(i==0 && orgStationCode[i].equals(desStationCode[i])){						
								//Round-Trip
								rndTripFlg = true;
								tktType = "Round-Trip";
								desSttCode = desStationCode[i];
								desCity = desStationCity[i]+", "+desStationState[i];
								desStreet = desStationStreet[i];
								break;
							}else{
								//One-Way
								tktType = "One-Way";
								desSttCode = desStationCode[i];
								desCity = desStationCity[i]+", "+desStationState[i];
								desStreet = desStationStreet[i];
								break;
							}
						}
				}
		
			
			Font tnr = new Font(greenShading, 26, Font.NORMAL);
			//Check if this is a multiride trip
			if(this.multiRideType.isValid()){
				//Ticket type text is in camel case.
				tktType = this.multiRideType.getRideTypeTextPDF();
				tripStartDate = this.multiRideType.isMonthly()? "": this.multiRideType.getDateHeaderText().toUpperCase();
			}
			
			if(tktType != null && "Multi-City Trip".equals(tktType)){
				orgSttCode = orgSttCode +"-"+desSttCode;
				desSttCode="";
				orgCityLength = 44;
			}
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(orgSttCode,tnr),
                    document.left(), document.top()- 125, 0);
			if(tktType != null && "Round-Trip".equals(tktType) && noOfLogicalTrips == 1){
				for (Iterator trip = tripSequence.iterator(); trip.hasNext(); )  {
		    		String stnCode = trip.next().toString();		    		 		
					int frstIndex = tripSequence.indexOf(stnCode);
					int lastIndex = tripSequence.lastIndexOf(stnCode);
					if(frstIndex == lastIndex){						
						//Format RQ
				    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();    	
				    	List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
						for (Iterator j = logicalTripListRQ.iterator(); j.hasNext(); )  { 
							List segmentsList  = ((FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip)j.next()).getSegments().getSegment();
							for (Iterator i = segmentsList.iterator(); i.hasNext(); )  {        			
				    			Segment4 segment = new Segment4();
				    			segment = (Segment4) i.next();				    			
				    			if(segment.getDestination().getCode().equals(stnCode)){
				    				desSttCode = segment.getDestination().getCode();
					    			desCity = segment.getDestination().getAddress().getCity()+", "+ segment.getDestination().getAddress().getState();
					    			desStreet = segment.getDestination().getAddress().getStreet2();
					    			break;
				    			}
							}//End of Segment Iterator
					     }//End of LogicalTrip Iterator
					}
				}
			}
			if(tktType != null && !"Multi-City Trip".equals(tktType)){
				//*** 2)Add Arrow Image in between cities
	    		URL url = this.getClass().getResource("/images/City-Arrow.png");
	    		InputStream is = url.openConnection().getInputStream();
	     		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
	    		int nRead;
	    		byte[] data = new byte[16384];
	    		while ((nRead = is.read(data, 0, data.length)) != -1) {
	    		  buffer.write(data, 0, nRead);
	    		}    		
	    		com.itextpdf.text.Image amtLogo = com.itextpdf.text.Image.getInstance(buffer.toByteArray());
	    		amtLogo.setAbsolutePosition(document.left()+90, document.top()-125);
	    		amtLogo.setAlignment(Element.ALIGN_LEFT);
	    		amtLogo.scaleAbsolute(15f, 13f);
	    		document.add(amtLogo);
				
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(desSttCode,tnr),
	                    document.left()+140, document.top()- 125, 0);
			}
			
			
			
			tnr = new Font(purpShading, 26, Font.NORMAL);	
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(tktType,tnr),
                    document.left()+275, document.top()- 125, 0);
			
			tnr = new Font(purpShading, 10, Font.NORMAL);			
			
			if(orgCity.length() > orgCityLength){
				LOG.info("orgCity.substring(0, orgCityLength)3 ** "+orgCity.substring(0, orgCityLength));
			
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(orgCity.substring(0, orgCityLength),tnr),
	                    document.left(), document.top()- 145, 0);
			}else{
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(orgCity,tnr),
	                    document.left(), document.top()- 145, 0);
			}
			//Street is commented for time being. Uncomment this after getting confirmation from Richard.
			//Format orgStreet if it's greater than 14 characters.
		
			
			
			if(desCity != null){
				if(desCity.length() > desCityLength){
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(desCity.substring(0, desCityLength),tnr),
	                    document.left()+140, document.top()- 145, 0);
				}else{
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(desCity,tnr),
		                    document.left()+140, document.top()- 145, 0);
				}
			}
			//Street is commented for time being. Uncomment this after getting confirmation from Richard.
			
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(tripStartDate,tnr),
                    document.left()+275, document.top()- 145, 0);
			
			if(tktType != null && "Round-Trip".equals(tktType) && noOfLogicalTrips > 1){
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase("Depart",tnr),
                    document.left()+5, document.top()- 177, 0);
			}			
		}catch(Exception e){
			errorFlg = true;
			LOG.error("Error occured in createTicketType. This checks for Kind of Trip(One way/Multi-City/Round Trip)and prepares heading.**" , e);

		}
		    LOG.debug("exiting createTicketType(writer,document,formatSendPsgrNotificationRQ)");

	}
	
	
	
	

	/**
     * Method to retrieve the PNRNumber-Date string required to generate the barcode
     * @param formatSendPsgrNotificationRQ
     * @return
     */
	private String getPNRNumber(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ) {

	    LOG.debug("entering getPNRNumber(formatSendPsgrNotificationRQ)");

		String PNRNumber = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getBookingInfo().getPNRLocator();
		SimpleDateFormat sdf = new SimpleDateFormat ( "ddMMMyy" ) ;
		SimpleDateFormat sdfAct = new SimpleDateFormat("yyyy-MM-dd");
		String sDate = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getBookingInfo().getPNRCreationDate().toString(); 
		try {
			java.util.Date dtDate = new Date();
			dtDate = sdfAct.parse(sDate);
			PNRNumber = PNRNumber +"-"+sdf.format(dtDate).toUpperCase();
		} catch (ParseException e) {
			LOG.error("ParseException occured in getPNRNumber" , e);

		}  

	    LOG.debug("exiting getPNRNumber(formatSendPsgrNotificationRQ)");

		return PNRNumber;
	}
	
    /**
     * Method to retrieve the PNRNumber-Date string required to generate the barcode
     * @param formatSendPsgrNotificationRQ
     * @return
     */
	private String getPNRNumber(TDDBookingInfo bookingInfo) {

	    LOG.debug("entering getPNRNumber(bookingInfo)");

		String PNRNumber = bookingInfo.getBookingPNRNumber();
		SimpleDateFormat sdf = new SimpleDateFormat ( "ddMMMyy" ) ;
		SimpleDateFormat sdfAct = new SimpleDateFormat("yyyy-MM-dd");
		String sDate = bookingInfo.getBookingCreationDate(); 
		try {
			java.util.Date dtDate = new Date();
			dtDate = sdfAct.parse(sDate);
			PNRNumber = PNRNumber +"-"+sdf.format(dtDate).toUpperCase();
		} catch (ParseException e) {
			LOG.error("ParseException occured in getPNRNumber(bookingInfo)" , e);

		}  
	    LOG.debug("exiting getPNRNumber(bookingInfo)");

		return PNRNumber;
	}
	
	
	/**
	 * Method to add the end of page details to the document
	 * @param writer
	 * @param document
	 */
	public void onPageEnd (PdfWriter writer, Document document) {
	    LOG.debug("entering onPageEnd(writer,document)");

		Rectangle rect = writer.getBoxSize("art");
        Font tnr = new Font(purpShading, 10, Font.NORMAL);	
        
        
        if(this.multiRideType.isValid()){
        	if(this.multiRideType.isMonthly()){
        		//If this is Weekly or Monthly type then formatting follows normally, it not spacing adjustments
        		//needs to be done.
        		
        	
        		ColumnText.showTextAligned(writer.getDirectContent(),
    	                Element.ALIGN_LEFT, new Phrase("RES# "+PNRNumber+"     "+orgSttCode+"-"+desSttCode+" | " + "Monthly",tnr),
    	                document.left(), rect.getBottom(), 0);
        		/*  New chunk to position the phone numbers to the left of the page, since iText collapses white spaces we need to resort to creating
        		 * a new chunk and setting postions for text.
        		 */
        		
        		ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(this.multiRideType.getDateFooterText(), tnr),
                        document.left() + 200, rect.getBottom(), 0);
        		
        		if(isCCJPA){
        			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(phoneNumber,tnr),
                            document.left() + 295, rect.getBottom(), 0);
        		}else{
	        		ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(phoneNumber,tnr),
	                        document.left() + 295, rect.getBottom(), 0);
        		}
        	
        	}else if(this.multiRideType.isMultiride()){
        		if(isCCJPA){
        			ColumnText.showTextAligned(writer.getDirectContent(),
	                        Element.ALIGN_LEFT, new Phrase("RES# " + PNRNumber + " " + orgSttCode+"-"+desSttCode+" | " + multiRideType.getRideTypeTextPDF() + " " + this.multiRideType.getDateFooterText() + "   "+ phoneNumber+"  ",tnr),
	                        document.left(), rect.getBottom(), 0);
        		}else{
	        		ColumnText.showTextAligned(writer.getDirectContent(),
	                        Element.ALIGN_LEFT, new Phrase("RES# " + PNRNumber + " " + orgSttCode+"-"+desSttCode+" | " + multiRideType.getRideTypeTextPDF() + " " + this.multiRideType.getDateFooterText() + "   "+ phoneNumber+" ",tnr),
	                        document.left(), rect.getBottom(), 0);
	        	}
         	}
        }else{
	        if(tktType != null && !"Multi-City Trip".equals(tktType)){  
	        	if(isCCJPA){
	        		ColumnText.showTextAligned(writer.getDirectContent(),
			                Element.ALIGN_LEFT, new Phrase("RES# "+PNRNumber+"     "+orgSttCode+"-"+desSttCode+" | "+tktType+"     Travel Date: "+tripStartDateFooter+"     " + phoneNumber +"  ",tnr),
			                document.left(), rect.getBottom(), 0);
	        	}else{
		        	ColumnText.showTextAligned(writer.getDirectContent(),
		                Element.ALIGN_LEFT, new Phrase("RES# "+PNRNumber+"     "+orgSttCode+"-"+desSttCode+" | "+tktType+"     Travel Date: "+tripStartDateFooter+"     " + phoneNumber+" ",tnr),
		                document.left(), rect.getBottom(), 0);
	        	}
	        }else{
	        	if(isCCJPA){
	        		ColumnText.showTextAligned(writer.getDirectContent(),
		                    Element.ALIGN_LEFT, new Phrase("RES# "+PNRNumber+"     "+orgSttCode+"     Travel Date: "+tripStartDateFooter+"     " + phoneNumber +"  ",tnr),
		                    document.left(), rect.getBottom(), 0);
	        	}else{
		        	ColumnText.showTextAligned(writer.getDirectContent(),
		                    Element.ALIGN_LEFT, new Phrase("RES# "+PNRNumber+"     "+orgSttCode+"     Travel Date: "+tripStartDateFooter+"     " + phoneNumber +"  ",tnr),
		                    document.left(), rect.getBottom(), 0);
	        	}
	        }
        }
	    LOG.debug("exiting onPageEnd(writer,document)");
       
    }
	
	/**
	 * Populates trip details required for the PDF
	 * @param formatSendPsgrNotificationRQ
	 */
	private void kindOfTrip(FormatSendPsgrNotificationRQ formatSendPsgrNotificationRQ){

	    LOG.debug("entering kindOfTrip(formatSendPsgrNotificationRQ)");

		try{
			//Format RQ
	    	FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary itineraryRQ = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getItinerary();    	
	    	List<FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip> logicalTripListRQ = itineraryRQ.getLogicalTrip();
			List<Passenger> passengersList = formatSendPsgrNotificationRQ.getFormatSendPsgrNotification().getPassengers().getPassenger(); 
			int logTripCount = 0;
			int segCount=0;
			String trainNumber = null;
			String orgTrainCity = null;
			String desTrainCity = null;
			String trainDate = null;
			for (Iterator j = logicalTripListRQ.iterator(); j.hasNext(); )  { 
			    LOG.debug("kindOfTrip logicalTripListRQ Start **");

				boolean expDelFeeFlg = false;
				boolean serviceFeeFlg = false;
				List segmentsList  = ((FormatSendPsgrNotificationRQ.FormatSendPsgrNotification.Itinerary.LogicalTrip)j.next()).getSegments().getSegment();
				for (Iterator i = segmentsList.iterator(); i.hasNext(); )  {        			
	    			Segment segment = new Segment();
	    			segment = (Segment) i.next();
    				if(segment.getTickets() != null){
    				    LOG.debug("kindOfTrip Tickets  **");

    					List<Ticket> ticketList = segment.getTickets().getTicket();	
	    				for (Iterator itr = ticketList.iterator(); itr.hasNext(); )  {        			
	    		    		Ticket ticket = new Ticket();
	    		    		ticket = (Ticket) itr.next(); 		    		    		
	    		    		if(ticket.getPricingItem() != null && ticket.getPricingItem().getFarePlans() != null &&
	    		    				ticket.getPricingItem().getFarePlans().getFarePlan().get(0) != null){	    		    			
	    		    			if(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().equalsIgnoreCase(TDDConstants.EXPRESS_DELIVERY_FEE)){
		    		    			//Store Express Delivery Fee Amount
		    		    			expressDeliveryFee = ticket.getPricingItem().getTariff().getRailFare().floatValue();
		    		    			expDelFeeFlg = true;		  
	    		    			}else if(ticket.getPricingItem().getFarePlans().getFarePlan().get(0).getCode().substring(0, 3).equalsIgnoreCase(TDDConstants.SERVICE_FEE)){
		    		    			//Store Service Fee Amount
		    		    			serviceFeeFlg = true;		  
	    		    			}
	    		    		}
	    				}
    				}
		    		if(!expDelFeeFlg && !serviceFeeFlg){
	   				    LOG.debug("expDelFeeFlg FALSE*********");

		    			if(logTripCount == 0 && segCount == 0){
		    				//TDD3
		    				tripStartDate = (this.multiRideType.isValid() == false)?TDDDateUtils.convertDateToMMMMMddyyyy(segment.getDepartureDateTime()): "";
		    				tripStartDateFooter = (this.multiRideType.isValid() == false)?TDDDateUtils.convertDateToMMM_dd_yyyy(segment.getDepartureDateTime()): "";
		    			}
		    			
		    			//TDD3 - the date conversion method convertDateToMMMddyyyy below takes care of null values, but the check is provided below to make it explicit.
						XMLGregorianCalendar depDateTime = (!this.multiRideType.isValid())? segment.getDepartureDateTime(): null;
						String trainNumberDetailsStr = (!this.multiRideType.isValid())?segment.getTrainDetails().getTrainNumber().toString():"";					
   		
		    			
		    			if(trainNumber != null && trainNumberDetailsStr.equals(trainNumber)
			    				 && segment.getOrigin().getAddress().getCity().toUpperCase().equals(orgTrainCity) &&
			    				segment.getDestination().getAddress().getCity().toUpperCase().equals(desTrainCity) &&
			    				TDDDateUtils.convertDateToMMM_dd_yyyy(depDateTime).equals(trainDate)){
		    				//Duplicate segment - Do nothing
		    			}else{	
		    				//TDD3
			    			trainNumber = (!this.multiRideType.isValid())?segment.getTrainDetails().getTrainNumber().toString():"";
			    			trainDate = (!this.multiRideType.isValid())? TDDDateUtils.convertDateToMMM_dd_yyyy(segment.getDepartureDateTime()):"";
			    			if(segment.getOrigin().getAddress() != null)
			    				orgTrainCity = segment.getOrigin().getAddress().getCity().toUpperCase();
			    			else
			    				orgTrainCity = null;
			    			if(segment.getDestination().getAddress() != null)
			    				desTrainCity = segment.getDestination().getAddress().getCity().toUpperCase();
			    			else
			    				desTrainCity = null;
			    			
			    			if(orgStationCode[logTripCount] == null && desStationCode[logTripCount] == null){
			    				tripSequence.add(segment.getOrigin().getCode());
			    				tripSequence.add(segment.getDestination().getCode());
			    				orgStationCode[logTripCount] = segment.getOrigin().getCode();
			    				desStationCode[logTripCount] = segment.getDestination().getCode();
			    				if(segment.getOrigin().getAddress() != null){
				    				orgStationCity[logTripCount] = segment.getOrigin().getAddress().getCity();
				    				orgStationState[logTripCount] = segment.getOrigin().getAddress().getState();
				    				orgStationStreet[logTripCount] = segment.getOrigin().getAddress().getStreet2();
			    				}else{
			    					orgStationCity[logTripCount] = null;
				    				orgStationState[logTripCount] = null;
				    				orgStationStreet[logTripCount] = null;
			    				}
			    				if(segment.getDestination().getAddress() != null){
				    				desStationCity[logTripCount] = segment.getDestination().getAddress().getCity();				    				
				    				desStationState[logTripCount] = segment.getDestination().getAddress().getState();			    				
				    				desStationStreet[logTripCount] = segment.getDestination().getAddress().getStreet2();
			    				}else{
			    					desStationCity[logTripCount] = null;
			    					desStationState[logTripCount] = null;
			    					desStationStreet[logTripCount] = null;
			    				}	    				
			    			}else{
			    				if(desStationCode[logTripCount].equals(segment.getOrigin().getCode())){
			    					tripSequence.add(segment.getDestination().getCode());
			    					desStationCode[logTripCount] = segment.getDestination().getCode();
			    					if(segment.getDestination().getAddress() != null){
					    				desStationCity[logTripCount] = segment.getDestination().getAddress().getCity();				    				
					    				desStationState[logTripCount] = segment.getDestination().getAddress().getState();			    				
					    				desStationStreet[logTripCount] = segment.getDestination().getAddress().getStreet2();
				    				}else{
				    					desStationCity[logTripCount] = null;
				    					desStationState[logTripCount] = null;
				    					desStationStreet[logTripCount] = null;
				    				}
			    				}else{
			    					//If there is dis-continuation in Cities, it means Multi-Cities 
			    					++logTripCount;	
			    					orgStationCode[logTripCount] = segment.getOrigin().getCode();
				    				desStationCode[logTripCount] = segment.getDestination().getCode();
				    				if(segment.getOrigin().getAddress() != null){
					    				orgStationCity[logTripCount] = segment.getOrigin().getAddress().getCity();
					    				orgStationState[logTripCount] = segment.getOrigin().getAddress().getState();
					    				orgStationStreet[logTripCount] = segment.getOrigin().getAddress().getStreet2();
				    				}else{
				    					orgStationCity[logTripCount] = null;
					    				orgStationState[logTripCount] = null;
					    				orgStationStreet[logTripCount] = null;
				    				}
				    				if(segment.getDestination().getAddress() != null){
					    				desStationCity[logTripCount] = segment.getDestination().getAddress().getCity();				    				
					    				desStationState[logTripCount] = segment.getDestination().getAddress().getState();			    				
					    				desStationStreet[logTripCount] = segment.getDestination().getAddress().getStreet2();
				    				}else{
				    					desStationCity[logTripCount] = null;
				    					desStationState[logTripCount] = null;
				    					desStationStreet[logTripCount] = null;
				    				}
			    				}
			    			}
			    			if(segment.getTrainDetails().getRouteName() != null && "AUTO TRAIN".equalsIgnoreCase(segment.getTrainDetails().getRouteName())){
			    				autoTrain = true;
			    			}
			    			++segCount;
		    			}//End of Else
		    		}//End of 		    			
				}//End of Segment Iterator				
				if(!expDelFeeFlg){	    	
					++logTripCount;
					++noOfLogicalTrips;
				}
		     }//End of Logical Iterator		
		} catch (Exception e) {
			errorFlg = true;
			LOG.error("Error occured in kindOfTrip block **" , e);

		}
	    LOG.debug("exiting kindOfTrip(formatSendPsgrNotificationRQ)");

	}

	/**
	 * Returns the RBDDescription for a segment
	 * @param segment
	 * @return
	 */
	private String rbdDescription(Segment4 segment){

	    LOG.debug("entering rbdDescription(segment)");

		String rbdDescription=null;
	    if(segment.getClassOfService() != null){
	       if(segment.getClassOfService().getNumberOfUnits().longValue() > 01){
	          rbdDescription = segment.getClassOfService().getNumberOfUnits().longValue() +" " +tddCommonFunctions.firstLetterUpperCase(segment.getClassOfService().getRBDDescription())+"s";
	        }else if(segment.getClassOfService().getNumberOfUnits().longValue() == 01){
	          rbdDescription = segment.getClassOfService().getNumberOfUnits().longValue() +" " +tddCommonFunctions.firstLetterUpperCase(segment.getClassOfService().getRBDDescription());
	        }
	    }
	    LOG.debug("exiting rbdDescription(segment)");

	    return rbdDescription;
	}
	
	/**
	 * Return the car details for a segment
	 * @param segment
	 * @return String
	 */
	private String carDetails(Segment4 segment){
		
	    LOG.debug("entering carDetails(segment)");

		String carNum = null;
		if(segment.getSeatingAssignment() != null){	    	
	    	//Car Number should always be displayed in 4 digits. If there are only 2 digits add '0's' in front to make it 4 digits.
	    	if(segment.getSeatingAssignment().getCarNumber()!= null){
	    		carNum = segment.getSeatingAssignment().getCarNumber().toString();
	    		if(carNum.length() < 4){
	    			for(int i=carNum.length(); i < 4; i++){
	    				carNum = "0"+carNum;
	    			}
	    		}
	    	}
	    	carNum = carNum != null ? "Car "+carNum: carNum;
	    	carNum = segment.getSeatingAssignment().getRoomNumber()!= null ? carNum + " - Room "+segment.getSeatingAssignment().getRoomNumber().toString():carNum;
        }
	    LOG.debug("exiting carDetails(segment)");

		return carNum;
	}

	/**
	 * 
	 * @param rbdDes
	 * @param carDtls
	 * @param secdSegRow
	 * @param writer
	 * @param document
	 * @param tnr
	 * @return boolean
	 */
	private boolean checkRBDAndCarDetails(String rbdDes, String carDtls, int  secdSegRow, PdfWriter writer, Document document, Font tnr){

		
	    LOG.debug("entering checkRBDAndCarDetails(rbdDes,carDtls,secdSegRow,secdSegRow,writer,document,tnr)");

		boolean multiLineFlg = false;
		if(rbdDes != null){
			if(carDtls != null){
				if((rbdDes + " | " +carDtls).length() <= rbdDescLength){
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(rbdDes + " | " +carDtls,tnr),
	                        document.left()+210, document.top()- secdSegRow + 10, 0);
				}else{
					if((rbdDes).length() <= rbdDescLength){
						ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(rbdDes,tnr),
		                        document.left()+210, document.top()- secdSegRow + 10, 0);
					}else{
						ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase((rbdDes).substring(0, rbdDescLength),tnr),
		                        document.left()+210, document.top()- secdSegRow + 10, 0);
					}
					multiLineFlg = true;
					if((carDtls).length() <= rbdDescLength){
						ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(carDtls,tnr),
		                        document.left()+210, document.top()- secdSegRow -12 + 10, 0);
					}else{
						ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase((carDtls).substring(0, rbdDescLength),tnr),
		                        document.left()+210, document.top()- secdSegRow -12 + 10, 0);
					}
				}
			}else{
				if((rbdDes).length() <= rbdDescLength){
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(rbdDes,tnr),
	                        document.left()+210, document.top()- secdSegRow + 10, 0);
				}else{
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase((rbdDes).substring(0, rbdDescLength),tnr),
	                        document.left()+210, document.top()- secdSegRow + 10, 0);
				}
			}
		}else if(carDtls != null){
				if((carDtls).length() <= rbdDescLength){
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(carDtls,tnr),
	                        document.left()+210, document.top()- secdSegRow + 10, 0);
				}else{
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase((carDtls).substring(0, rbdDescLength),tnr),
	                        document.left()+210, document.top()- secdSegRow + 10, 0);
				}
		}
		
	    LOG.debug("exiting checkRBDAndCarDetails(rbdDes,carDtls,secdSegRow,secdSegRow,writer,document,tnr)");

		return multiLineFlg;
	}
	
			
	/**
	 * 
	 * @param orgTrainCity
	 * @param desTrainCity
	 * @param frstSegRow
	 * @param writer
	 * @param document
	 * @param tnr
	 * @return
	 */
	private boolean checkOrgAndDesCityDetails(String orgTrainCity, String desTrainCity, int  frstSegRow, PdfWriter writer, Document document, Font tnr){

	    LOG.debug("entering checkOrgAndDesCityDetails(orgTrainCity,desTrainCity,frstSegRow,writer,document,tnr)");

		boolean multiLineFlg = false;
		if(orgTrainCity != null){
			int commaIndex = orgTrainCity.indexOf(",");
			if(commaIndex != -1){
				orgTrainCity = orgTrainCity.substring(0,commaIndex);
			}
		}
		if(desTrainCity != null){
			int commaIndex = desTrainCity.indexOf(",");
			if(commaIndex != -1){
				desTrainCity = desTrainCity.substring(0,commaIndex);
			}
		}
		
		if(orgTrainCity != null){
			if(desTrainCity != null){
				if((orgTrainCity + " - " +desTrainCity).length() <= trainOrgDesLength){						
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(orgTrainCity + " - " +desTrainCity,tnr),
	                        document.left()+210, document.top()- frstSegRow, 0);
				}else{
					multiLineFlg = true;
					String frstLine = getFrstLineChars(orgTrainCity + " - " +desTrainCity, trainOrgDesLength);
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(frstLine,tnr),
	                        document.left()+210, document.top()- frstSegRow, 0);
    				String secdLine = getFrstLineChars((orgTrainCity + " - " +desTrainCity).substring(frstLine.length()), trainOrgDesLength);
    				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(secdLine,tnr),
	                        document.left()+210, document.top()- frstSegRow -12, 0);
				}
			}else{
				
				if(orgTrainCity.length() <= trainOrgDesLength){						
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(orgTrainCity,tnr),
	                        document.left()+210, document.top()- frstSegRow, 0);
				}else{
					String frstLine = getFrstLineChars(orgTrainCity, trainOrgDesLength);
					ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(frstLine,tnr),
	                        document.left()+210, document.top()- frstSegRow, 0);
    				String secdLine = getFrstLineChars((orgTrainCity).substring(frstLine.length()), trainOrgDesLength);
    				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(secdLine,tnr),
	                        document.left()+210, document.top()- frstSegRow -12, 0);
				}
			}
		}else if(desTrainCity != null){
			if(desTrainCity.length() <= trainOrgDesLength){						
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(desTrainCity,tnr),
                        document.left()+210, document.top()- frstSegRow, 0);
			}else{
				String frstLine = getFrstLineChars(desTrainCity, trainOrgDesLength);
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(frstLine,tnr),
                        document.left()+210, document.top()- frstSegRow, 0);
				String secdLine = getFrstLineChars((desTrainCity).substring(frstLine.length()), trainOrgDesLength);
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_BOTTOM, new Phrase(secdLine,tnr),
                        document.left()+210, document.top()- frstSegRow -12, 0);
			}
		}
	    LOG.debug("exiting checkOrgAndDesCityDetails(orgTrainCity,desTrainCity,frstSegRow,writer,document,tnr)");

		return multiLineFlg;
	}
	
    /**
     * Inner class used to construct a footer template on each page
     * @author 90000781
     *
     */
	class TableHeader extends PdfPageEventHelper {
        /** The header text. */
        String header;
        /** The template with the total number of pages. */
        PdfTemplate total;
        
        /**
         * Allows us to change the content of the header.
         * @param header The new header String
         */
        public void setHeader(String header) {
            this.header = header;
        }

        /**
         * Creates the PdfTemplate that will hold the total number of pages.
         * @see com.itextpdf.text.pdf.PdfPageEventHelper#onOpenDocument(
         *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
         */
        public void onOpenDocument(PdfWriter writer, Document document) {
    	    LOG.debug("entering onOpenDocument(writer,document)");

    		total = writer.getDirectContent().createTemplate(30, 16);
    	    LOG.debug("exiting onOpenDocument(writer,document)");

        }
        
        /**
         * Adds a header to every page
         * @see com.itextpdf.text.pdf.PdfPageEventHelper#onEndPage(
         *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
         */
        public void onEndPage(PdfWriter writer, Document document) {
    	    LOG.debug("entering onEndPage(writer,document)");

    		Font tnr = new Font(purpShading, 10, Font.NORMAL);       	
            PdfPTable table = new PdfPTable(3);           
            try {
                table.setWidths(new int[]{24, 24, 2});
                table.setTotalWidth(527);
                table.setLockedWidth(true);
                table.getDefaultCell().setFixedHeight(20);
                table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
                table.addCell(header);
                table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);                               
                table.addCell(new Phrase("Page " + writer.getPageNumber()+" of",tnr));               
                PdfPCell cell = new PdfPCell(com.itextpdf.text.Image.getInstance(total));
                cell.setBorder(Rectangle.NO_BORDER);
                table.addCell(cell);
                table.writeSelectedRows(0, -1, document.left()+15, document.bottom()+12, writer.getDirectContent()); 
                table.setHorizontalAlignment(254);                
                // to Call Footer Data
                onPageEnd(writer,document);                
            }            
            catch(DocumentException de) {
                throw new ExceptionConverter(de);
            }  
    	    LOG.debug("exiting onEndPage(writer,document)");

        }
        
        /**
         * Fills out the total number of pages before the document is closed.
         * @see com.itextpdf.text.pdf.PdfPageEventHelper#onCloseDocument(
         *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
         */
        public void onCloseDocument(PdfWriter writer, Document document) {  
    	    LOG.debug("entering onCloseDocument(writer,document)");

    		Font tnr = new Font(purpShading, 10, Font.NORMAL);
            ColumnText.showTextAligned(total, Element.ALIGN_LEFT,new Phrase(String.valueOf(writer.getPageNumber()),tnr),2, 4, 0);
    	    LOG.debug("exiting onCloseDocument(writer,document)");

        }
    }
	
}
package com.amtrak.tdd.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.rmi.ServerException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ;
import com.amtrak.tdd.helper.ImportantInformationHelper;
import com.amtrak.tdd.service.JaxbUtils;
import com.amtrak.tdd.service.TDDBookingInfo;
import com.amtrak.tdd.service.TDDConstants;
import com.amtrak.tdd.service.TDDGeneratePDFAttachmentSessionBean;
import com.amtrak.tdd.service.TDDGenerateReceiptHTMLSessionBean;
import com.day.cq.search.QueryBuilder;

@SlingServlet(paths = "/services/geteticket", methods = "POST", metatype = true)
@Property(name = "sling.auth.requirements", value = "-/services/geteticket")
public class GeneratePDFService extends
		org.apache.sling.api.servlets.SlingAllMethodsServlet {

	private static final long serialVersionUID = 2598426539166789515L;
	private static final Logger LOG = LoggerFactory
			.getLogger(GeneratePDFService.class);

	@Reference
	private transient QueryBuilder builder;

	@Reference
	private transient ResourceResolverFactory resolverFactory;

	@Override
	protected void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServerException,
			IOException {

		ResourceResolver resourceResolver = null;
		byte[] byteTemp = null;
		String pnrnum = null;
		FormatSendPsgrNotificationRQ sprq = null;
		int responsecode = 200;
		String responseMsg = "success";
		String tddhtml = null;
		String receiptType = null;

		try {

			if (request.getHeader("pnr_id") != null) {
				LOG.info("REQUESR RECEIVED FOR PNR:"+request.getHeader("pnr_id"));
			
			}

//			 resourceResolver =
//			 resolverFactory.getAdministrativeResourceResolver(null);
			// need to revert above line of code.
			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, "dataread");
			resourceResolver = resolverFactory
					.getServiceResourceResolver(param);

			if (request != null) {

				StringBuffer sb = new StringBuffer();
				try {

					// read the request(XML) from MuelSoft and convert it string
					// reader object

					String line = null;
					BufferedReader br = request.getReader();
					while ((line = br.readLine()) != null) {
						sb.append(line);
					}
					if ((sb != null) && (sb.length() > 0)) {

						String sdata = sb.toString();
						StringReader reader = new StringReader(sdata);

						// parse the XML using JAXB
						try {
							sprq = JaxbUtils
									.createFormatSendPsgrNotificationRQ(reader);
						} catch (Exception e) {
							responsecode = 400;
							responseMsg = "Internal error AEM not able parse XML from Muel" + "*"
									+ e.getLocalizedMessage() + "*";
							LOG.error("AEM not able parse XML from Muel:", e);
						}
						// AEM able to successfully parse the XML from MuelSoft

						// read the booking info

						if (sprq != null) {

							try {

								TDDBookingInfo bookingInfo = new TDDBookingInfo(sprq);
								if (bookingInfo != null) {
									receiptType = bookingInfo.getReceiptType();
									pnrnum = bookingInfo.getBookingPNRNumber();
									LOG.info("REQUEST RECEIVED FOR PNR:"+pnrnum); 
									pnrnum = pnrnum + ".pdf";
									TDDGeneratePDFAttachmentSessionBean tddpdf = new TDDGeneratePDFAttachmentSessionBean();
									TDDGenerateReceiptHTMLSessionBean tddemail = new TDDGenerateReceiptHTMLSessionBean();
									JCRService jcrService = new JCRService(
											resourceResolver, builder,
											bookingInfo);

									if (!receiptType
											.equals(TDDConstants.CANCEL_REFUND)) {

										byteTemp = tddpdf.createPDF(jcrService,
												bookingInfo);

									}
									tddhtml = tddemail.generateHTML(jcrService,
											bookingInfo);
									if (!receiptType
											.equals(TDDConstants.CANCEL_REFUND)) {

										if ((byteTemp == null)
												|| (byteTemp.length <= 0)) {
											responsecode = 400;
											responseMsg = "Internal error"
													+ "* AEM not able to Generate PDF *";
										}
									}
									if (tddhtml == null
											|| tddhtml.length() <= 0) {
										responsecode = 400;
										responseMsg = "Internal error"
												+ "* AEM not able to Generate HTML *";
									}

								}

							} catch (Exception ex) {
								LOG.error(
										"AEM able parse XML but AEM data process failed:",
										ex);
								responsecode = 400;
								responseMsg = "Internal error" + "*"
										+ "AEM able parse XML but AEM data process failed:"+ex.getLocalizedMessage() + "*";
							}

						} else {
							LOG.error("AEM not able parse XML ");
							responsecode = 400;
							responseMsg = "Internal error"
									+ "* AEM not able parse XML *";
						}
					} else {
						LOG.error("AEM not able read XML from Muel ");
						responsecode = 400;
						responseMsg = "Internal error"
								+ "* AEM not able to read XML from Muel *";
					}

				} catch (Exception e) {
					LOG.error(
							"AEM Service Post, Error while generation PDF and HTML:",
							e.getLocalizedMessage());
					responsecode = 400;
					responseMsg = "Internal error" + "*"
							+ e.getLocalizedMessage() + "*";

				}

			} else {
				// send response code
				responsecode = 400;
				responseMsg = "Bad request";
			}
		} catch (Exception e) {
			LOG.error("Error getting AEM Resource Resolver:", e);
			responsecode = 400;
			responseMsg = "Internal error in getting AEM Resource Resolver " + "*" + e.getLocalizedMessage() + "*";
		} finally {
			// close resolver
			if (resourceResolver != null) {
				resourceResolver.close();
			}

		}

		// Send Response as Json.
		JSONObject mainJSONObj = new JSONObject();
		if (responseMsg.equalsIgnoreCase("success"))

		{
			JSONArray contentsMainArray = new JSONArray();

			// html
			JSONObject contentsArrayHTMLObject = new JSONObject();
			JSONObject contentsArrayHTMLHeaderObject = new JSONObject();

			contentsArrayHTMLHeaderObject.put("PNRNO", pnrnum);

			contentsArrayHTMLObject.put("headers",
					contentsArrayHTMLHeaderObject);
			contentsArrayHTMLObject.put("mimeType", "text/html");
			contentsArrayHTMLObject.put("value", tddhtml);
			if (!receiptType.equals(TDDConstants.CANCEL_REFUND)) {
				// pdf
				JSONObject contentsArrayPDFObject = new JSONObject();
				JSONObject contentsArrayPDFHeaderObject = new JSONObject();

				contentsArrayPDFHeaderObject.put("PNRNO", pnrnum);
				contentsArrayPDFObject.put("headers",
						contentsArrayPDFHeaderObject);
				contentsArrayPDFObject.put("mimeType", "application/pdf");
				contentsArrayPDFObject.put("value",
						Base64.encodeBase64String(byteTemp));
				contentsMainArray.put(contentsArrayPDFObject);
			}

			contentsMainArray.put(contentsArrayHTMLObject);
			mainJSONObj.put("contents", contentsMainArray);
		} else {
			mainJSONObj.put("message", responseMsg);
		}
		response.setContentType("application/json");
		response.setStatus(responsecode);
		response.getWriter().write(mainJSONObj.toJSONString());

	}

}
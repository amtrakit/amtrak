package com.amtrak.tdd.jcr;

public class FarePlanCriteria extends BaseCriteria{

	private RBDCriteria rbdCriteria;
	private String farePlanCode;
	private boolean fareRule75;
	
	public FarePlanCriteria() {
        // nothing to do.
	}
	public FarePlanCriteria(RBDCriteria rbdCriteria, String farePlanCode, boolean fareRule75) {
		super();
		this.rbdCriteria = rbdCriteria;
		this.farePlanCode = farePlanCode;
		this.fareRule75 = fareRule75;
	}

	public RBDCriteria getRbdCriteria() {
		return rbdCriteria;
	}
	public void setRbdCriteria(RBDCriteria rbdCriteria) {
		this.rbdCriteria = rbdCriteria;
	}
	public String getFarePlanCode() {
		return farePlanCode;
	}
	public void setFarePlanCode(String farePlanCode) {
		this.farePlanCode = farePlanCode;
	}
	public boolean isFareRule75() {
		return fareRule75;
	}
	public void setFareRule75(boolean fareRule75) {
		this.fareRule75 = fareRule75;
	}
	public ServiceCriteria getServiceCriteria() {
		return rbdCriteria.getServiceCriteria();
	}
	public String getOriginStation(){
		return getServiceCriteria().getOriginStationCriteria().getStationName();
	}
	public String getOriginDate(){
		return getServiceCriteria().getOriginStationCriteria().getDate();
	}
	public String getDestinationStation(){
		return getServiceCriteria().getDestinationStationCriteria().getStationName();
	}
	public String getDestinationDate(){
		return getServiceCriteria().getDestinationStationCriteria().getDate();
	}
	
}

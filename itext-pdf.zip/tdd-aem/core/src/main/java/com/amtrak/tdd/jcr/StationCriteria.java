package com.amtrak.tdd.jcr;

public class StationCriteria extends BaseCriteria{

	private String stationName;
	private StationType stationType;
	
	public StationCriteria() {
        // nothing to do.
	}
	public StationCriteria(String stationName, StationType stationType) {
		super();
		this.stationName = stationName;
		this.stationType = stationType;
	}
	
	public StationCriteria(String stationName, StationType stationType, String date, int order) {
		super(date, order);
		this.stationName = stationName;
		this.stationType = stationType;
	}
	public String getStationName() {
		return stationName;
	}
	public void setStationName(String stationName) {
		this.stationName = stationName;
	}
	public StationType getStationType() {
		return stationType;
	}
	public void setStationType(StationType stationType) {
		this.stationType = stationType;
	}	
}

package com.amtrak.tdd.service.test;

import java.io.File;
import java.io.StringReader;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amtrak.mulesoft.schema._2016._03._07.FormatSendPsgrNotificationRQ;
import com.amtrak.tdd.service.JaxbUtils;
import com.amtrak.tdd.service.TDDBookingInfo;
import com.amtrak.tdd.service.TDDGeneratePDFAttachmentSessionBean;

public class TDDGeneratePDFAttachmentSessionBeanTest {

	private static final Logger LOG = LoggerFactory.getLogger(TDDGeneratePDFAttachmentSessionBeanTest.class);

//	@Test
	public void testCreatePDF(){
		StringReader reader = null;
		try {
			reader = new StringReader(IOUtils.toString(this.getClass().getResourceAsStream("CCJPAFormatSendPsgrNotificationMultiMonthly.xml")));
			FormatSendPsgrNotificationRQ sprq = JaxbUtils.createFormatSendPsgrNotificationRQ(reader);
			TDDBookingInfo bookingInfo = new TDDBookingInfo(sprq);
			TDDGeneratePDFAttachmentSessionBean bean = new TDDGeneratePDFAttachmentSessionBean();
			byte[] bytes = bean.createPDF(bookingInfo);
			FileUtils.writeByteArrayToFile(new File("C://AEMImportantInfo//AEMImportantInfo.pdf"), bytes);
		} catch (Exception e) {
			LOG.error("Exception" , e);
		}
	}
	
}

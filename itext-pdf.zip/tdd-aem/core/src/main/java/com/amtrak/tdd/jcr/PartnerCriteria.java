package com.amtrak.tdd.jcr;

public class PartnerCriteria extends FarePlanCriteria{

	private FarePlanCriteria farePlanCriteria;
	private String partnerName;

	public PartnerCriteria() {
        // nothing to do.
	}
	public PartnerCriteria(FarePlanCriteria farePlanCriteria, String partnerName) {
		super();
		this.farePlanCriteria = farePlanCriteria;
		this.partnerName = partnerName;
	}

	public FarePlanCriteria getFarePlanCriteria() {
		return farePlanCriteria;
	}
	public void setFarePlanCriteria(FarePlanCriteria farePlanCriteria) {
		this.farePlanCriteria = farePlanCriteria;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	
	@Override
	public RBDCriteria getRbdCriteria() {
		return farePlanCriteria.getRbdCriteria();
	}

	@Override
	public ServiceCriteria getServiceCriteria() {
		return farePlanCriteria.getServiceCriteria();
	}

	@Override
	public String getOriginStation(){
		return getServiceCriteria().getOriginStationCriteria().getStationName();
	}

	@Override
	public String getOriginDate(){
		return getServiceCriteria().getOriginStationCriteria().getDate();
	}

	@Override
	public String getDestinationStation(){
		return getServiceCriteria().getDestinationStationCriteria().getStationName();
	}

	@Override
	public String getDestinationDate(){
		return getServiceCriteria().getDestinationStationCriteria().getDate();
	}
	
}

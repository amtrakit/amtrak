$(document).ready(function() {
	var selectorTxt = $(".selector-val").val().trim();
	$("#search-text").keyup(function() {
		var queryParam = $(this).val();
		if (queryParam.length > 0) {
			$("." + selectorTxt).each(function() {
				if ($(this).text().search(new RegExp(queryParam, "i")) < 0) {
					$(this).fadeOut();
					$(".imp-info-hdr").show();
					$(".advisory-imp-info").show();
				} else {
					$(".imp-info-hdr").show();
					$(".advisory-imp-info").show();
					$(this).show();

				}
			});
		} else {
			$(".imp-info-hdr").show();
			$(".advisory-imp-info").show();
			$("." + selectorTxt).show();
		}

	});

});
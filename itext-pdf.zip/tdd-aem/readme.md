Code repository for customer channel, primarily serving dot com channel experience.

# Amtrak.com

This repo used for both AEM and FED code under one roof, but still separated within different branches.
We will tryout this approach to minimize/avoid code sync issues between FED/AEM code bases.

AEM branches:
 - aem-stable  > features ready for release will be merged


FED branches:
 - fed-stable  > new branches(feature/bugfix/hotfix) will be created from here and when AEM team ready to start integration, same will be merged here.

 - fed-develop > (feature/bugfix/hotfix) once development completed, should be merged here to deploy on ddhive for testing.


Building
--------
## Requirements
    Node.js
    gulp

## Install
    - goto `web-app/shared/generators`
    - run `npm install`

This project uses Maven for building. Common commands:

From the root directory, run:

Hostname and port number to be mentioned command line as below:

  	mvn clean install -Daem.host=localhost -Daem.port=4502

This will build the bundle content package and install to a CQ instance.


Using with VLT
--------------
To use vlt with this project, first build and install the package to your local CQ instance as described above. Then:

    cd `content/src/main/content/jcr_root`

and run

    vlt --credentials admin:admin checkout -f ../META-INF/vault/filter.xml --force http://localhost:4502/crx

Once the working copy is created, you can use the normal ``vlt up`` and ``vlt ci`` commands.

Specifying CRX Host/Port
------------------------

The CRX host and port can be specified on the command line with:
mvn -Dcrx.host=otherhost -Dcrx.port=5502 <goals>
